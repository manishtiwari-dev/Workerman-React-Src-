import React, { useState } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { Faqupdate, Faqedit } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import MyEditor from "component/MyEditor";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Label,
  Input,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import { useEffect } from "react";

const EditOption = (props) => {
  const { editId } = props;

 
  const { apiToken, language } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
    getValues,
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(Faqupdate, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
             const { status, data, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });
          props.RefreshList();
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
        SetformloadingStatus(false);
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [editorData, SeteditorData] = useState("");




  useEffect(() => {
    let abortController = new AbortController();

    const setValueToField = async () => {
      const editInfo = {
        api_token: apiToken,
        id:editId,
      };
      POST(Faqedit, editInfo)
        .then((response) => {
          SetloadingStatus(false);
          const { data } = response.data;
          const fieldList = getValues();
          for (const key in fieldList) {
            setValue(key, data[key]);
          }

          SeteditorData(data["answer"]);


        })
        .catch((error) => {
            SetloadingStatus(false);
          alert(error.message);
        });
    };
    setValueToField();

  //   return () => {
  //     // setValueToField();
  //     // getModuleList();
  //     abortController.abort();
  //   };
  // }, [apiToken]);

    return () => abortController.abort();
  }, [apiToken]);

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
      <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        <input type="hidden" value="" {...register("id")} />
        <Row>
          <Col col={12}>
            <FormGroup mb="20px">
              <Input
                id={Trans("QUESTION", language)}
                label={Trans("QUESTION", language)}
                placeholder={Trans("QUESTION", language)}
                className="form-control"
                {...register("question", {
                  required: Trans("QUESTION_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="question" />
              </span>
            </FormGroup>
            </Col>

            <Col col={12}>
            <FormGroup>
                  <Label>{Trans("ANSWER", language)}</Label>
                  <MyEditor
                    setKey={`answer`}
                    setVal={
                      editorData
                    }
                    updateFun={(Key, Value) => {
                      setValue(Key, Value);
                    }}
                  />

                  <textarea
                    {...register(`answer`)}
                    style={{ display: "none" }}
                  ></textarea>


                  {/* <MyEditor
                    setKey={`answer`}
                    setVal={
                      getValues(`answer`) === undefined
                        ? "<p></p>"
                        : getValues(`answer`)
                    }
                    updateFun={(Key, Value) => {
                      setValue(Key, Value);
                    }}
                  />
                 
                  <textarea
                   {...register("answer", {
                    required: Trans("ANSWER_REQUIRED", language),
                  })}
                    style={{ display: "none" }}
                  ></textarea> */}
                </FormGroup>
           
          </Col>


          <Col col={2}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("UPDATE", language)}
              className="btn btn-sm btn-bg btn-block"
            />
          </Col>
        </Row>
      </form>
    </>
  );
};

export default EditOption;
