import React from "react";
import Currency from "hooks/currency";
import { Trans } from "lang";
import { BadgeShow } from "component/UIElement/UIElement";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { useState } from "react";



function CustomerDashboardModel({ dashboardcontent }) {
  const [transaction, setTransaction] = useState([]);
  const { apiToken, language } = useSelector((state) => state.login);
  useEffect(() => {
    let abortController = new AbortController();

    setTransaction(JSON.parse(dashboardcontent));
    return () => abortController.abort();
  }, [dashboardcontent]);



  return (
    <div className="row">
      <div className="col-md-12">
        <div className="">
          <div className="d-flex">
            <h6>{Trans("COMPANY_NAME", language)}  &nbsp; </h6>
            :<p>{transaction.company_name}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("CONTACT", language)} &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;</h6>
            :<p>{transaction.contact}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("Email", language)} &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp;</h6>
            :<p>{transaction.email}</p>
          </div>

          <div className="d-flex">
            <h6>{Trans("STATUS", language)} &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; </h6>
            :<p>{transaction.status === 1 ? 'Active' : 'Blocked'}</p>
          </div>
        
        </div>
      </div>
    </div>
  );
}

export default CustomerDashboardModel;
