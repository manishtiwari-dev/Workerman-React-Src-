import React from "react";
import POST from "axios/post";
import Chart from "react-apexcharts";
// import ReactFlot from 'react-flot';
import { useSelector } from "react-redux";
import Content from "layouts/content";
import { Trans } from "lang";
import PageHeader from "component/PageHeader";
import { useState } from "react";
import { DashboardUrl } from "config/index";
import Notify from "component/Notify";
import { BadgeShow, Anchor, IconButton } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { Modal, Button } from "react-bootstrap";
import SalesDashboardModel from "./SalesDashboardModel";
import CustomerModal from "./CustomerModal";
import { DashUrl } from "config";
import Moment from "react-moment";
import FeatherIcon from "feather-icons-react";
import {
  PageOrder,
  PageEnquiry,
  PageCustomer,
  PreAdd,
  PreView,
  PreExport,
  SuperPagesSetting,
} from "config/PermissionName";
import CheckPermission from "helper";

function SalesDashboard() {
  const { role, apiToken, userType, language, industry } = useSelector(
    (state) => state.login
  );

  const [dashboardData, SetdashboardData] = useState([]);
  const [dashboardcontent, Setdashboardcontent] = useState("");
  const [customercontent, Setcustomercontent] = useState("");

  React.useEffect(() => {
    document.title = "Sales Dashboard | WorkerMan";
    const formData = {
      api_token: apiToken,
      language: language,
      userType: userType,
      industry_id: industry,
    };
    POST(DashboardUrl, formData)
      .then((response) => {
        const { status, data } = response.data;
        if (status) {
          SetdashboardData(data);
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, error.message);
        console.error("There was an error!", error);
      });
  }, []);

  const state = {
    options: {
      //  labels: `${dashboardData?.sales?.label}`
      labels: ["Profit", "Product Cost", "Shipping Cost", "Tax"],
    },
    series: [44, 55, 41, 17, 15],
    //  labels: ['Apple', 'Mango', 'Orange', 'Watermelon','test']
  };
  // transacationmodal
  const [showTransactionModal, SetshowTransactionModal] = useState(false);
  const handleShowTransactionModal = () => {
    SetshowTransactionModal(showTransactionModal ? false : true);
  };

  const [showCustomerModal, SetshowCustomerModal] = useState(false);
  const handleShowCustomerModal = () => {
    SetshowCustomerModal(showCustomerModal ? false : true);
  };

  return (
    <React.Fragment>
      <Content>
        <div className="d-sm-flex align-items-center justify-content-between ">
          <div>
            <h4 className=" tx-spacing--1">Welcome to Dashboard</h4>
          </div>
        </div>

        <div className="row row-xs   ">
          <div className="col-6 col-lg-2">
            <div className="card card-body bg-green">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("TOTAL_ORDER", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end ">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.total_orders}
                </h3>
              </div>
            </div>
          </div>
          <div className="col-6 col-lg-2">
            <div className="card card-body bg-gray">
              <h6 className="tx-10 tx-spacing-1 tx-color-02 tx-semibold ">
                {Trans("TOTAL_QUOTATIONS", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.total_quatations}
                </h3>
              </div>
            </div>
          </div>
          <div className="col-6 col-lg-2">
            <div className="card card-body  bg-purple">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("TOTAL_USERS", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.total_users}
                </h3>
              </div>
            </div>
          </div>

          <div className="col-6 col-lg-2">
            <div className="card card-body bg-pink">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("TOTAL_ENQUIRY", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.total_enquiry}
                </h3>
              </div>
            </div>
          </div>

          <div className="col-6 col-lg-2">
            <div className="card card-body bg-brown">
              <h6 className=" tx-10  tx-spacing-1 tx-color-02 tx-semibold ">
                {Trans("NUMBER_OF_CATEGORY", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.No_of_categories}
                </h3>
              </div>
            </div>
          </div>

          <div className="col-6 col-lg-2">
            <div className="card card-body bg-peach">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("NUMBER_OF_PRODUCT", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.No_of_products}
                </h3>
              </div>
            </div>
          </div>

          <div className="col-lg-6 col-xl-6 mg-t-10">
            <CheckPermission
              PageAccess={PageOrder}
              PageAction={PreView}>
              <div className="card">
                <div className="card-header pd-y-10 tx-16 d-md-flex align-items-center justify-content-between">
                  <h6 className="mg-b-0">{Trans("LATEST_ORDERS", language)}</h6>
                  <a
                    href={`${DashUrl}/sales/orders?token=${apiToken}`}
                    className="tx-13">
                    {Trans("VIEW_ALL_ORDERS", language)}{" "}
                  </a>
                </div>
                <div className="card-body pos-relative pd-0">
                  <div className="table-responsive">
                    <table className="table table-dashboard  mg-b-0 border-0">
                      <thead>
                        <tr>
                          <th>{Trans("ORDER_NUMBER", language)}</th>
                          <th className="text-center">
                            {Trans("TOTAL", language)}
                          </th>
                          <th className="text-center">
                            {Trans("ORDER_STATUS", language)}
                          </th>
                          <th className="text-center">
                            {Trans("PAYMENT_STATUS", language)}
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {dashboardData?.total_orders_list &&
                          dashboardData?.total_orders_list.map(
                            (order, idxx) => {
                              return (
                                <tr key={idxx}>
                                  <td>
                                    <Moment format="YYYY-MM-DD">
                                      {order?.created_at}
                                    </Moment>{" "}
                                    <br />
                                    <a
                                      href={`${DashUrl}/sales/orders/details/${order?.order_number}?token=${apiToken}`}>
                                      {order?.order_number}
                                    </a>
                                    {/* <Anchor
                                path={WebsiteLink(
                                  "/order/" + order?.order_number
                                )}
                              >
                                {order?.order_number}
                              </Anchor> */}
                                  </td>
                                  <td className="text-center">
                                    {order?.grand_total}
                                  </td>

                                  <td
                                    className={`text-center ${
                                      order?.order_status === "Deliverd"
                                        ? " tx-success"
                                        : " tx-pink"
                                    }`}>
                                    {order?.order_status}
                                  </td>
                                  <td
                                    className={`text-center ${
                                      order?.payment_status === "Paid"
                                        ? " tx-success"
                                        : " tx-pink"
                                    }`}>
                                    {order?.payment_status}
                                  </td>
                                </tr>
                              );
                            }
                          )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </CheckPermission>
          </div>
          <div className="col-lg-6 col-xl-6 mg-t-10">
            <div className="card">
              <div className="card-header py-0">
                <h6 className="mg-b-5 tx-13">
                  {Trans("ORDERS_STATISTICS", language)}
                </h6>
                <p className="tx-12 tx-color-03 mg-b-0">
                  {Trans("LAST_12_MONTHS_ORDERS_STATISTICS", language)}
                </p>
              </div>
              <div className="card-body pd-0 chartBody">
                <div className="chart-two mb-2 ">
                  <div
                    id="className2"
                    className="flot-chart">
                    {dashboardData?.chartItem10Year?.series && (
                      <Chart
                        options={dashboardData.chartItem10Year.options}
                        series={dashboardData.chartItem10Year.series}
                        type="bar"
                        width="98%"
                        height="325px"
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-6 col-xl-4 mg-t-10">
            <div className="card ht-100p">
              <div className="card-header d-flex align-items-center justify-content-between">
                <h6 className="mg-b-0 tx-16">Sales</h6>
              </div>

              {dashboardData?.sales?.values && (
                <Chart
                  options={state.options}
                  series={dashboardData?.sales?.values}
                  type="donut"
                  width="350"
                />
              )}
            </div>
          </div>
          <div className="col-md-6 col-xl-4 mg-t-10">
            <CheckPermission
              PageAccess={PageEnquiry}
              PageAction={PreView}>
              <div className="card ht-100p">
                <div className="card-header d-flex align-items-center justify-content-between">
                  <h6 className="mg-b-0 tx-16">Latest Enquiry</h6>
                </div>

                {dashboardData?.total_enquiry_list && (
                  <ul className="list-group list-group-flush tx-13">
                    {dashboardData.total_enquiry_list.map((enquiry, indx) => {
                      const {
                        No_of_categories,
                        No_of_products,
                        No_of_reviews,
                        total_customer_list,
                        total_enquiry_list,
                        total_order_list,
                        total_quatations,
                        total_users,
                      } = enquiry;

                      return (
                        <li className="list-group-item d-flex pd-sm-x-20">
                          {/* <div className="avatar d-none d-sm-block">
                          <span className="avatar-initial rounded-circle bg-teal">
                            <i className="icon ion-md-checkmark"></i>
                          </span>
                        </div> */}
                          <div className="pd-sm-l-10">
                            <p className="tx-medium mg-b-0">
                              {enquiry.customers_name} #{enquiry.enquiry_no}
                            </p>
                            <small className="tx-12 tx-color-03 mg-b-0">
                              <Moment format="YYYY-MM-DD">
                                {enquiry?.created_at}
                              </Moment>{" "}
                              <br />
                            </small>
                          </div>
                          <div className="mg-l-auto text-right">
                            {/* <IconButton
                              color="primary"
                              onClick={() => {
                                Setdashboardcontent(JSON.stringify(enquiry));
                                handleShowTransactionModal();
                              }}
                            >
                      
                       <FeatherIcon
                       //   icon="link"
                                icon="eye"                                      
                               
                                onClick={() => {
                                  Setdashboardcontent(JSON.stringify(enquiry));
                                  handleShowTransactionModal();
                                }}
                              />
                            </IconButton> */}

                            <Button
                              variant="primary"
                              onClick={() => {
                                Setdashboardcontent(JSON.stringify(enquiry));
                                handleShowTransactionModal();
                              }}>
                              <FeatherIcon
                                icon="eye"
                                fill="white"
                                className="wd-10 mg-r-5 "
                              />
                            </Button>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
                <div className="card-footer text-center tx-13">
                  <a href={`${DashUrl}/sales/enquiry?token=${apiToken}`}>
                    <i className="icon ion-md-arrow-down mg-l-5">
                      {Trans("VIEW_ALL_ENQUIRY", language)}
                    </i>
                  </a>
                </div>
              </div>
            </CheckPermission>
          </div>

          <div className="col-md-6 col-xl-4 mg-t-10">
            <CheckPermission
              PageAccess={PageCustomer}
              PageAction={PreView}>
              <div className="card ht-100p">
                <div className="card-header d-flex align-items-center justify-content-between">
                  <h6 className="mg-b-0 tx-16">New Customers</h6>
                </div>

                {dashboardData?.total_customer_list && (
                  <ul className="list-group list-group-flush tx-13">
                    {dashboardData?.total_customer_list.map(
                      (customer, indx) => {
                        return (
                          <li className="list-group-item d-flex pd-sm-x-20">
                            <div className="avatar">
                              <span className="avatar-initial rounded-circle bg-gray-600">
                                {customer.first_name.charAt(0)}
                              </span>
                            </div>
                            <div className="pd-l-10">
                              <p className="tx-medium mg-b-0">
                                {customer.first_name} {customer.last_name}
                              </p>
                              <small className="tx-12 tx-color-03 mg-b-0">
                                {customer.email}
                              </small>
                            </div>

                            <div className="mg-l-auto d-flex align-self-center">
                              <nav className="nav nav-icon-only">
                                <a
                                  href=""
                                  className="nav-link d-none d-sm-block">
                                  <i data-feather="mail"></i>
                                </a>
                                <a
                                  href=""
                                  className="nav-link d-none d-sm-block">
                                  <i data-feather="slash"></i>
                                </a>
                                <a
                                  href=""
                                  className="nav-link d-none d-sm-block">
                                  <i data-feather="user"></i>
                                </a>
                                <a
                                  href=""
                                  className="nav-link d-sm-none">
                                  <i data-feather="more-vertical"></i>
                                </a>
                              </nav>
                            </div>
                          </li>
                        );
                      }
                    )}
                  </ul>
                )}
                <div className="card-footer text-center tx-13">
                  <a href={`${DashUrl}/sales/customer?token=${apiToken}`}>
                    <i className="icon ion-md-arrow-down mg-l-5">
                      {Trans(" View More Customers", language)}
                    </i>
                  </a>
                </div>
              </div>
            </CheckPermission>
          </div>
        </div>
        {/* transactionlog */}
        <Modal
          show={showTransactionModal}
          onHide={handleShowTransactionModal}
          size="md">
          <Modal.Header>
            <Modal.Title>{Trans("Enquiry Data", language)}</Modal.Title>
            <Button
              variant="danger"
              onClick={handleShowTransactionModal}>
              X
            </Button>
          </Modal.Header>
          <Modal.Body>
            <SalesDashboardModel dashboardcontent={dashboardcontent} />
          </Modal.Body>
        </Modal>
        {/* transaction_log */}
        <Modal
          show={showCustomerModal}
          onHide={handleShowCustomerModal}
          size="md">
          <Modal.Header>
            <Modal.Title>{Trans("Customer Data", language)}</Modal.Title>
            <Button
              variant="danger"
              onClick={handleShowCustomerModal}>
              X
            </Button>
          </Modal.Header>
          <Modal.Body>
            <CustomerModal customercontent={customercontent} />
          </Modal.Body>
        </Modal>
      </Content>
    </React.Fragment>
  );
}

export default SalesDashboard;
