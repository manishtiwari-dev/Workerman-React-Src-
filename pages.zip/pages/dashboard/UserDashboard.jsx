import React from "react";
import { useSelector } from "react-redux";
import Content from "layouts/content";
import { useState } from "react";
import { DashboardUrl } from "config/index";
import POST from "axios/post";
import Notify from "component/Notify";
import { Trans } from "lang";


function Index() {
  const { role, apiToken, userType, language, industry,userInfo } = useSelector(
    (state) => state.login
  );


  const userDetails = JSON.parse(userInfo);

  const [dashboardData, SetdashboardData] = useState([]);

 React.useEffect(() => {
  const formData = {
    api_token: apiToken,
    // language: language,
    // userType: userType,
    // industry_id: industry,
  };
  POST(DashboardUrl, formData)
    .then((response) => {
      const { status, data } = response.data;
      if (status) {
        SetdashboardData(data);
      } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
    })
    .catch((error) => {
      Notify(false, error.message);
      console.error("There was an error!", error);
    });
}, []);


  return (
    <React.Fragment>
      <Content>
      <div>

            <h4 className="mg-b-0 tx-spacing--1">Welcome to {userDetails.first_name}</h4>

          </div>
        
      </Content>
    </React.Fragment>
  );
}

export default Index;




