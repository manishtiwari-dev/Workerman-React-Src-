import React, { useState } from "react";
import { LoaderButton, FormGroup, Label, Col, Input, Row } from "component/UIElement/UIElement";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import { useForm, FormProvider } from "react-hook-form";
import POST from "axios/post";
import { updateRoleUrl, editRoleUrl, roleSectionList } from "config";
import Alert from "component/UIElement/Alert";
import Notify from "component/Notify";
import { useEffect } from "react";

function Edit(props) {
  const { editData } = props;
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const { language, apiToken, userType } = useSelector((state) => state.login);
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const capitalizeFirst = str => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  };
  const [permissionList, setPermissionList] = useState([]);
  const [setEdit, SetsetEdit] = useState("");
  const [sectionList, SetSectionList] = useState([]);
  const [moduleList, SetModuleList] = useState([]);

  const methods = useForm();
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    formState: { errors },
  } = methods;

  const [msgType, setMsgType] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const [editPermission, SetEditPermission] = useState();
  const setPerSelectItem = () => {
    if (editPermission !== undefined) {
      if (editPermission !== "" && editPermission.length > 0) {
        for (let index = 0; index < editPermission.length; index++) {
          const fieldName = `permission.${editPermission[index]["section_id"]}.${editPermission[index]["permissions_ids"]}`;
          setValue(fieldName, editPermission[index]["permission_types_id"]);
        }
      }
    }
  };


  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(updateRoleUrl, saveFormData)
      .then((response) => {
        const { status, message } = response.data;
        if (status) {
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          setMsgType("success");
          setErrorMsg(Trans(message, language));
          Notify(true, Trans(message, language));
        } else {
          setMsgType("danger");
          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            setErrorMsg(errMsg);
          } else {
            setErrorMsg(Trans(message, language));
          }
        }
        SetformloadingStatus(false);
      })
      .catch((error) => {
        Notify(false, error.message);
        setMsgType("danger");
        setErrorMsg("Something went wrong !");
        SetformloadingStatus(false);
      });
  };

  
  useEffect(() => {
    let abortController = new AbortController();
    const formData = {
      api_token: apiToken,
      language: language,
      userType: userType,
    };
    POST(roleSectionList, formData)
      .then((response) => {
        const { status, data } = response.data;
        if (status) {
          setPermissionList(data.permission_list);
          SetSectionList(data.section_list);
          SetModuleList(data.module_list);
          SetsetEdit("set");
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      });
    return () => abortController.abort();
  }, []);



  const setValueToField = () => {
    POST(editRoleUrl, {
      api_token: apiToken,
      updateId: editData,
      language: language,
    })
      .then((response) => {
        SetloadingStatus(false);
        const { data } = response.data;
        SetEditPermission(data.permissions_type_list);

        const fieldList = getValues();
        // for (const key in fieldList) {
        //   setValue(key, data.data_list[key]);
        // }
        setValue("updatedId", data.roles_id);
        setValue("role_name", data.roles_name);
        setValue("sort_order", data.sort_order);

      })
      .catch((error) => {
        SetloadingStatus(false);
        alert(error.message);
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    setValueToField();
    return () => abortController.abort();
  }, []);


  // set a variable
  useEffect(() => {
    setPerSelectItem();
    return () => setPerSelectItem();
  }, [setEdit]);


  return (
    <React.Fragment>
      {msgType.length > 2 &&
        (msgType === "success" ? (
          <Alert type="success">{errorMsg}</Alert>
        ) : (
          <Alert type="danger">{errorMsg}</Alert>
        ))}
      <FormProvider {...methods}>
        <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
          <input {...register("updatedId")} type="hidden" />
          <Row>
            <Col col={6}>
              <FormGroup mb="20px">
                <Label display="block" mb="5px" htmlFor="name">
                  <b>{Trans("NAME", language)}:</b>
                </Label>
                <input
                  id="name"
                  type="text"
                  className="form-control"
                  placeholder="Enter your name"
                  {...register("role_name", {
                    required: "Role Name is required",
                  })}
                />
                {errors.role_name && <span>This field is required</span>}
              </FormGroup>
            </Col>


          </Row>
          <FormGroup mb="20px">
            <Label display="block" mb="5px" htmlFor="permissionList">
              <b>{Trans("PERMISSION", language)}:</b>
            </Label>


            <React.Fragment>
              <div className="row">
                <div className="col-md-3"></div>
                <div className="col-md-9">
                  <div className="row">
                    {permissionList &&
                      permissionList.map((ch, chid) => {
                        return (
                          <React.Fragment key={chid}>
                            <div className="col-md-2 text-center text-uppercase">
                              <b>{ch.permissions_name}</b>
                            </div>
                          </React.Fragment>
                        );
                      })}
                  </div>
                </div>
              </div>

              <div className="row">
                {moduleList &&
                  moduleList.map((section, secindex) => {
                    const { module_name, module_id, section_id, section_name } = section;

                    let SecChecked = false;
                    const checkedPermission = props.checkedPermission;

                    if (checkedPermission !== undefined) {
                      if (checkedPermission.length > 0) {
                        for (
                          let index = 0;
                          index < checkedPermission.length;
                          index += 1
                        ) {
                          if (section_id === checkedPermission[index].section_id) {
                            SecChecked = true;
                          }
                        }
                      }
                    }



                    return (
                      <React.Fragment key={secindex}>
                        <div className="col-md-12">
                          <fieldset className="form-fieldset">
                            <legend>
                              {Trans(module_name, language)}
                            </legend>


                            {section.section_list &&
                              <>
                                {section.section_list.map(
                                  (subsection, idxx) => {
                                    const {
                                      section_id,
                                      section_name,

                                    } = subsection;
                                    return (
                                      <React.Fragment key={idxx}>
                                        <div className="row">
                                          <div className="col-md-3">

                                            <label className="">

                                              <h6>{Trans(section_name, language)}</h6>

                                            </label>


                                          </div>
                                          <div className="col-md-9">
                                            <div className="row">
                                              {permissionList &&
                                                permissionList.map((ch, chid) => {
                                                  return (
                                                    <div key={chid} className="col-md-2">
                                                      <select
                                                        {...register(
                                                          `permission.${section_id}.${ch.permissions_id}`
                                                        )}
                                                        className=""
                                                      >
                                                        <option value="">
                                                          {Trans("SELECT", language)}
                                                        </option>
                                                        {ch.allow_permission &&
                                                          Object.entries(JSON.parse(ch.allow_permission)).map(
                                                            (allow, idxallow) => {
                                                              if (allow[1] !== "") {
                                                                return (
                                                                  <option
                                                                    value={`${allow[1]}`}
                                                                    key={idxallow}
                                                                  >
                                                                    {capitalizeFirst(allow[0])}
                                                                  </option>
                                                                );
                                                              }
                                                            }
                                                          )}
                                                      </select>
                                                    </div>
                                                  );
                                                })}
                                            </div>
                                          </div>

                                        </div>
                                      </React.Fragment>
                                    );
                                  })}
                              </>}

                          </fieldset>
                        </div>
                      </React.Fragment>
                    );
                  })}
              </div>
            </React.Fragment>
          </FormGroup>
          <Col col={4}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("UPDATE", language)}
              className="btn btn-sm btn-bg btn-block"
            />
          </Col>

        </form>
      </FormProvider>
    </React.Fragment>
  );
}

export default Edit;
