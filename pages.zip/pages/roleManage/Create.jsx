import React, { useState ,useEffect} from "react";
import { LoaderButton, FormGroup, Label,Col,Input ,Row} from "component/UIElement/UIElement";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import { useForm, FormProvider } from "react-hook-form";
import POST from "axios/post";
import { createRoleUrl,roleSectionList } from "config";
import Alert from "component/UIElement/Alert";
import Notify from "component/Notify";

function Create(props) {
  const { language, apiToken,userType } = useSelector((state) => state.login);
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const methods = useForm();

  const capitalizeFirst = str => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  };
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = methods;

  const [msgType, setMsgType] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const onSubmit = (formData) => {
    SetformloadingStatus(true);

    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(createRoleUrl, saveFormData)
      .then((response) => {
        const { status, message } = response.data;
        if (status) {
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          setMsgType("success");
          setErrorMsg(Trans(message, language));
          Notify(true, Trans(message, language));
        } else {
          setMsgType("danger");
          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            setErrorMsg(errMsg);
          } else {
            setErrorMsg(Trans(message, language));
            Notify(false, Trans(message, language));
          }
        }
        SetformloadingStatus(false);
      })
      .catch((error) => {
        Notify(false, error.message);
        SetformloadingStatus(false);
      });
  };

  const [permissionList, setPermissionList] = useState([]);
  const [sectionList, SetSectionList] = useState([]);
  const [moduleList, SetModuleList] = useState([]);

  useEffect(() => {
    let abortController = new AbortController();
    const formData = {
      api_token: apiToken,
      language: language,
      userType: userType,
    };
    POST(roleSectionList, formData)
      .then((response) => {
        const { status, data } = response.data;
        if (status) {
          setPermissionList(data.permission_list);
          SetSectionList(data.section_list);
          SetModuleList(data.module_list);
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      });
    return () => abortController.abort();
  }, []);




  return (
    <React.Fragment>
      {msgType.length > 2 &&
        (msgType === "success" ? (
          <Alert type="success">{errorMsg}</Alert>
        ) : (
          <Alert type="danger">{errorMsg}</Alert>
        ))}
      <FormProvider {...methods}>
        <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        <Row>
        <Col col={6}>
          <FormGroup mb="20px">
            <Label display="block" mb="5px" htmlFor="name">
              <b>{Trans("NAME", language)}:</b>
            </Label>
            <input
              id="name"
              type="text"
              className="form-control"
              placeholder="Enter your name"
              {...register("role_name", {
                required: "Role Name is required",
              })}
            />
            {errors.role_name && <span>This field is required</span>}
          </FormGroup>
          </Col>
          {/* <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("SORT_ORDER", language)}
                type="number"
                label={Trans("SORT_ORDER", language)}
                placeholder={Trans("SORT_ORDER", language)}
                className="form-control"
                {...register("sort_order")}
              />
            
            </FormGroup>
        
        </Col> */}
        </Row>
        
          <FormGroup mb="20px">
            <Label display="block" mb="5px" htmlFor="permissionList">
              <b>{Trans("PERMISSION", language)}:</b>
            </Label>        
            <React.Fragment>
          <div className="row">
            <div className="col-md-3"></div>
            <div className="col-md-9">
              <div className="row">
                {permissionList &&
                  permissionList.map((ch, chid) => {
                    return (
                      <React.Fragment key={chid}>
                        <div className="col-md-2 text-center text-uppercase">
                          <b>
                          {Trans(ch.permissions_name, language)}</b>
                        </div>
                      </React.Fragment>
                    );
                  })}
              </div>
            </div>
          </div>
          <div className="row">
            {moduleList &&
              moduleList.map((section, secindex) => {
                const { module_name, module_id ,section_id,section_name} = section;

                let SecChecked = false;
                const checkedPermission = props.checkedPermission;

                if (checkedPermission !== undefined) {
                  if (checkedPermission.length > 0) {
                    for (
                      let index = 0;
                      index < checkedPermission.length;
                      index += 1
                    ) {
                      if (section_id === checkedPermission[index].section_id) {
                        SecChecked = true;
                      }
                    }
                  }
                }



                return (
                  <React.Fragment key={secindex}>
                    <div className="col-md-12">
                    <fieldset className="form-fieldset">
                          <legend>
                          {Trans(module_name, language)}
                          </legend>
                    {section.section_list &&
                    <>
                      {section.section_list.map(
                        (subsection, idxx) => {
                          const {
                            section_id,
                            
                            section_name,
                            
                          } = subsection;
                          return(
                      <div className="row">
                      <div className="col-md-3">
                     
                      <label className="">
                     
                      <h6>{Trans(section_name, language)}</h6>
                      </label>
             
                        </div>    
                    <div className="col-md-9">
                      <div className="row">
                        {permissionList &&
                          permissionList.map((ch, chid) => {
                            return (
                              <div key={chid} className="col-md-2">
                                <select
                                  {...register(
                                    `permission.${section_id}.${ch.permissions_id}`
                                  )}
                                  className=""
                                >
                                  <option value="">
                                    {Trans("SELECT", language)}
                                  </option>
                                 

                                  {ch.allow_permission &&
                                    Object.entries(JSON.parse(ch.allow_permission)).map(
                                      (allow, idxallow) => {
                                        if (allow[1] !== "") {
                                          return (
                                            <option
                                              value={`${allow[1]}`}
                                              key={idxallow}
                                            >
                                              {capitalizeFirst(allow[0])}
                                            </option>
                                          );
                                        }
                                      }
                                    )}
                                </select>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                    </div>  
                 );
                })}
                 </> }   
                    </fieldset>
                    </div>
                  </React.Fragment>
                );
              })}
          </div>
        </React.Fragment>
          </FormGroup>

          <Col col={4}>
          <LoaderButton
            formLoadStatus={formloadingStatus}
            btnName={Trans("SUBMIT", language)}
            className="btn btn-sm btn-bg btn-block"
          />
           
           </Col>
        </form>
      </FormProvider>
    </React.Fragment>
  );
}

export default Create;
