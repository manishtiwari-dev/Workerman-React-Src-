import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useParams } from "react-router-dom";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useForm, FormProvider } from "react-hook-form";
import {
  ListingUpdateUrl,
  tempUploadFileUrl,
  ListingEditUrl,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Anchor,
  Label,
  GalleryImagePreviewWithUploadWithItem,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import Select from "react-select";
import WebsiteLink from "config/WebsiteLink";
import { useNavigate } from "react-router-dom";
import LangProductInfo from "./component/Edit/LangProductInfo";
import Feature from "./component/Edit/Feature";
import ProductAttribute from "./component/Edit/ProductAttribute";
import FeatherIcon from "feather-icons-react";

const Edit = () => {
  const { prId } = useParams();
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });

  const [value, setsValue] = useState("");
  const getValue = (value) => {
    setsValue(value);
  };
  const navigate = useNavigate();

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const [editProAttribute, SetEditProAttribute] = useState();
  const [editLoad, SeteditLoad] = useState(false);

  const methods = useForm();

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    getValues,
  } = methods;

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    if (MultiSelectCategoryItem.length == 0) {
      Notify(false, "CHOOSE ATLEAST ONE CATEGORY");
      return "";
    }

    let data = {
      listing_description: value,
    };

    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    saveFormData.categories_id = MultiSelectCategoryItem;
    saveFormData.gallery_ids = multipleImageIds;

    POST(ListingUpdateUrl, saveFormData)
      .then((response) => {
        // console.log("response", response);
        SetformloadingStatus(false);
        const { status, message, data } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });

          Notify(true, Trans(message, language));
          navigate(`/business-listing/show/${data.listing_id}`);
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };

  const [langList, SetlangList] = useState([]);
  const [categoryList, SetCategoryList] = useState([]);

  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return;

    var readers = new FileReader();
    readers.onload = function (e) {
      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="50" />`;
    };
    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);
    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        setValue(StoreID, response.data.data);
      })
      .catch((error) => {
        Notify(false, error.message);
      });
  };

  const [priceType, SetPriceType] = useState(" ");

  const [baseRates, setBaseRate] = useState(" ");

  const [productTypeFields, SetProductTypeFields] = useState("");
  const ModuleChange = (e) => {
    let value = e.target.value;
    if (value !== undefined || value !== "") {
      const sectionlistData =
        e.target.selectedOptions[0].attributes[1].nodeValue;
      SetProductTypeFields(JSON.parse(sectionlistData));
    }
  };

  const [MultiSelectCategoryItem, SetMultiSelectCategoryItem] = useState([]);
  const handleMultiSelectChange = (newValue, actionMeta) => {
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    SetMultiSelectCategoryItem(listArr);
  };

  const [selectedCategory, SetSelectedCategory] = useState();
  const [selectedSupplier, SetSelectedSupplier] = useState("");
  const [selectedProductType, SetSelectedProductType] = useState();
  const [productAttribute, SetProductAttribute] = useState();
  const [tempEditorValue, SettempEditorValue] = useState("");

  const [MultiSelectSupplierItem, SetMultiSelectSupplierItem] = useState("");
  const handleMultiSelectSupplierChange = (newValue, actionMeta) => {
    // alert("sdf");
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    SetMultiSelectSupplierItem(listArr);
  };

  const [multipleImageIds, SetMultipleImageIds] = useState([]);
  const [showMulImage, SetShowMulImage] = useState([]);

  const imageHandleComp = (type, operation, data) => {
    if (operation === "add") SetMultipleImageIds([...multipleImageIds, data]);
    else {
      const NewList = multipleImageIds.filter((image, key) => {
        return key !== data;
      });
      SetMultipleImageIds(NewList);
    }
    return true;
  };
  // console.log("multipleImage", multipleImageIds);
  const [editInfo, SeteditInfo] = useState("");
  // edit info

  const saveValueToField = () => {
    const formData = {
      api_token: apiToken,
      language: language,
      listing_id: prId,
    };
    POST(ListingEditUrl, formData)
      .then((response) => {
        const { status, data } = response.data;
        if (status) {
          SetloadingStatus(false);
          const { data } = response.data;
          SeteditInfo(data.data_list);
          SetCategoryList(data.category);
          SetProductAttribute(data.listing_attribute);
          SetlangList(data.language);

          const fieldList = getValues();
          delete fieldList.product_condition;
          // set SetPriceType
          SetPriceType(data?.data_list.product_price);
          // add product array tags
          if (data?.data_list.listing_tag !== null)
            setproductTags(data?.data_list.listing_tag.split(","));

          for (const key in fieldList) {
            setValue(key, data.data_list[key]);
          }
          SetSelectedCategory(data.data_list.selected_category);

          SetMultipleImageIds(data?.data_list.gallery_ids);
          SetShowMulImage(data?.data_list.gallery_image);

          let listArr = [];
          if (data?.data_list.selected_category?.length > 0) {
            for (
              let index = 0;
              index < data?.data_list.selected_category.length;
              index++
            ) {
              listArr[index] = data?.data_list.selected_category[index].value;
            }
          }
          SetMultiSelectCategoryItem(listArr);

          SetEditProAttribute(data?.data_list.product_attribute);

          SetProductTypeFields(data?.data_list.product_type);

          // display product_name value
          if (data?.data_list.productdescription.length > 0) {
            const lang_with_pro = data?.data_list.productdescription;
            for (let index = 0; index < lang_with_pro.length; index++) {
              const pro_name = lang_with_pro[index].listing_name;
              const pro_desc = lang_with_pro[index].listing_description;

              setValue(
                "listing_name_" + lang_with_pro[index].languages_id,
                pro_name
              );
              SettempEditorValue(pro_desc);
              setValue(
                "listing_description_" + lang_with_pro[index].languages_id,
                pro_desc
              );

              setValue(
                "seometa_title_" + lang_with_pro[index]["languages_id"],
                lang_with_pro[index].seo.seometa_title
              );
              setValue(
                "seometa_desc_" + lang_with_pro[index]["languages_id"],
                lang_with_pro[index].seo.seometa_desc
              );
            }
          }
          if (data?.data_list.product_price.length > 0) {
            const lang_with_pro = data?.data_list.product_price;
            for (let index = 0; index < lang_with_pro.length; index++) {
              const baseRate = lang_with_pro[index].base_rate;
              const rateType = lang_with_pro[index].rate_type;
              setBaseRate(baseRate);

              setValue("base_rate", baseRate);

              setValue("rate_type", rateType);
            }
          }
          SeteditLoad(true);
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, error.message);
        console.error("There was an error!", error);
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    saveValueToField();
    return () => abortController.abort();
  }, []);

  const [productTags, setproductTags] = useState([]);

  const addTag = (value) => {
    setproductTags([...productTags, value]);
    // setValue("product_tags", productTags.join(","));
  };

  const removeTag = (pos) => {
    let newTags = productTags.filter((data, idx) => {
      return idx !== pos ? true : false;
    });
    setproductTags(newTags);
  };

  const [manStock, SetManStock] = useState(true);
  const calculateSellprice = () => {
    const price = parseFloat(getValues("product_stock_price"));
    const percentage = getValues("product_profit_margin");
    if (price === NaN || percentage === NaN) return false;

    let per = (percentage / 100) * price;
    let sellPrice = price + per;
    setValue("product_sale_price", sellPrice);
  };

  // const createSelectLabel = () => {};

  const createSelectLabel = (data, selData = "") => {
    return data;

    let labelData = [];

    return labelData;
  };

  return (
    <Content>
      <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
          <div
            className="card"
            id="custom-user-list">
            <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
              <h6 className="tx-uppercase tx-semibold mg-b-0">
                {Trans("UPDATE_LISTING", language)}
              </h6>
              <div className="d-none d-md-flex">
                <Anchor
                  className="btn btn-sm btn-bg pd-3"
                  path={WebsiteLink("/business-listing")}>
                  <FeatherIcon
                    //  icon="corner-down-left"
                    className="wd-10 mg-r-5"
                  />
                  {Trans("GO_BACK", language)}
                </Anchor>
              </div>
            </div>
            <div className="card-body">
              <>
                {error.status && (
                  <Alert
                    variant={error.type}
                    onClose={() =>
                      setError({ status: false, msg: "", type: "" })
                    }
                    dismissible>
                    {error.msg}
                  </Alert>
                )}
                <FormProvider {...methods}>
                  <form
                    action="#"
                    onSubmit={handleSubmit(onSubmit)}
                    noValidate>
                    <input
                      type="hidden"
                      {...register("listing_id")}
                    />
                    <Row>
                      <Col col={12}>
                        <FormGroup mb="20px">
                          <Label
                            display="block"
                            mb="5px"
                            htmlFor={Trans("CATEGORY", language)}>
                            {Trans("CATEGORY", language)}
                          </Label>
                          {selectedCategory && (
                            <Select
                              isMulti
                              defaultValue={selectedCategory}
                              name={Trans("CATEGORY", language)}
                              options={categoryList}
                              className="basic-multi-select"
                              classNamePrefix="select"
                              onChange={handleMultiSelectChange}
                            />
                          )}
                        </FormGroup>
                      </Col>
                      {/* <Col col={12}>
                        <FormGroup mb="20px">
                          <Label
                            display="block"
                            mb="5px"
                            htmlFor={Trans("CATEGORY", language)}
                          >
                            {Trans("CATEGORY", language)}
                          </Label>

                          <Select
                            isMulti
                            name={Trans("CATEGORY", language)}
                            options={categoryList}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            onChange={handleMultiSelectChange}
                          />
                        </FormGroup>
                      </Col> */}

                      <Col col={12}>
                        <fieldset className="form-fieldset">
                          <legend>
                            {Trans("LISTING_INFORMATION", language)}
                          </legend>
                          <Row>
                            <LangProductInfo
                              langList={langList}
                              tempEditorValue={tempEditorValue}
                            />

                            <Col col={12}>
                              <label htmlFor="">
                                <b>{Trans("LISTING_VIDEO_URL", language)}</b>
                              </label>
                              <div className="input-group">
                                <div className="input-group-prepend">
                                  <select
                                    {...register("video_provider")}
                                    className="btn btn-outline-light"
                                    defaultValue={editInfo?.video_provider}>
                                    <option value={1}>
                                      {Trans("YOUTUBE", language)}
                                    </option>
                                    <option value={2}>
                                      {Trans("DailyMotion", language)}
                                    </option>
                                    <option value={3}>
                                      {Trans("Custom", language)}
                                    </option>
                                  </select>
                                </div>
                                <input
                                  id={Trans("PRODUCT_VIDEO_URL", language)}
                                  type="text"
                                  label={Trans("PRODUCT_VIDEO_URL", language)}
                                  placeholder={Trans(
                                    "PRODUCT_VIDEO_URL",
                                    language
                                  )}
                                  className="form-control"
                                  {...register("video_url")}
                                />
                              </div>
                            </Col>

                            <Col
                              col={4}
                              className="mt-3">
                              <FormGroup mb="20px">
                                <Label htmlFor="status">
                                  {Trans("RATE_TYPE", language)} :{" "}
                                </Label>
                                <select
                                  {...register("rate_type")}
                                  className="form-control"
                                  value={editInfo.product_price?.rate_type}>
                                  <option value={0}>
                                    {Trans("OneTime", language)}
                                  </option>
                                  <option value={1}>
                                    {Trans("Hour", language)}
                                  </option>
                                  <option value={2}>
                                    {Trans("Day", language)}
                                  </option>
                                  <option value={3}>
                                    {Trans("Weekly", language)}
                                  </option>
                                  <option value={4}>
                                    {Trans("Monthly", language)}
                                  </option>
                                  <option value={5}>
                                    {Trans("Yearly", language)}
                                  </option>
                                </select>
                              </FormGroup>
                            </Col>

                            <Col
                              col={3}
                              className="mt-3">
                              <FormGroup mb="20px">
                                <Input
                                  id="BASE_PRICE"
                                  type="number"
                                  label={Trans("BASE_PRICE", language)}
                                  placeholder={Trans("BASE_PRICE", language)}
                                  className="form-control"
                                  {...register("base_rate", {})}
                                  //  defaultValue={baseRates}
                                />
                              </FormGroup>
                            </Col>
                          </Row>
                        </fieldset>
                      </Col>

                      <ProductAttribute
                        editProductAttribute={editInfo?.product_attribute}
                        productAttribute={productAttribute}
                        editLoad={editLoad}
                      />

                      <Feature
                        editFeature={editInfo?.product_feature}
                        editLoad={editLoad}
                      />
                      {/* gallery */}
                      <Col col={12}>
                        <fieldset className="form-fieldset">
                          <legend>{Trans("LISTING_IMAGES", language)}</legend>
                          <Row>
                            <Col col={3}>
                              <FormGroup>
                                <Label
                                  display="block"
                                  mb="5px"
                                  htmlFor={"fileupload"}>
                                  {Trans("LISTING_IMAGES", language)}
                                </Label>
                                <div className="custom-file">
                                  <input
                                    type="hidden"
                                    {...register("listing_image", {
                                      required: Trans(
                                        "LISTING_IMAGES_REQUIRED",
                                        language
                                      ),
                                    })}
                                  />
                                  <input
                                    type="file"
                                    className="custom-file-input"
                                    id="customFile"
                                    onChange={(event) =>
                                      HandleDocumentUpload(
                                        event,
                                        "fileupload",
                                        "listing_image"
                                      )
                                    }
                                  />
                                  <label
                                    className="custom-file-label"
                                    htmlFor="customFile">
                                    {Trans("IMAGE", language)}
                                  </label>
                                  <span className="required">
                                    <ErrorMessage
                                      errors={errors}
                                      name="listing_image"
                                    />
                                  </span>
                                  <div id={"fileupload"}>
                                    <img
                                      src={editInfo.Image}
                                      height="50"
                                    />
                                  </div>
                                </div>
                              </FormGroup>
                            </Col>
                            <Col
                              col={12}
                              className="mt-3">
                              <Label
                                display="block"
                                mb="5px"
                                htmlFor="role_name">
                                {Trans("GALLERY_IMAGES", language)}
                              </Label>
                              <FormGroup mb="20px">
                                {showMulImage === undefined ? (
                                  <GalleryImagePreviewWithUploadWithItem
                                    label="multipleImage"
                                    className="form-control"
                                    imageHandleComp={imageHandleComp}
                                    onDrop={imageHandleComp}
                                    selectedImageList={showMulImage}
                                  />
                                ) : (
                                  <GalleryImagePreviewWithUploadWithItem
                                    label="multipleImage"
                                    className="form-control"
                                    imageHandleComp={imageHandleComp}
                                    onDrop={imageHandleComp}
                                    selectedImageList={showMulImage}
                                  />
                                )}
                              </FormGroup>
                            </Col>
                          </Row>
                        </fieldset>
                      </Col>
                      {/* end gallery */}

                      <br />
                      {/* product tags */}
                      <Col
                        col={7}
                        className="mt-3">
                        <Input
                          id={Trans("LISTING_TAGS", language)}
                          type="text"
                          label={Trans("LISTING_TAGS", language)}
                          placeholder="Use Insert Button To Add"
                          className="form-control"
                          onKeyUp={(e) => {
                            e.preventDefault();
                            if (e.keyCode === 45) {
                              addTag(e.target.value);
                              e.target.value = "";
                            }
                          }}
                        />

                        <input
                          type="hidden"
                          {...register("listing_tag")}
                        />

                        <div className="All_Tags">
                          {productTags &&
                            productTags.map((tag, idx) => {
                              return (
                                <React.Fragment>
                                  <span className="tags btn btn-info">
                                    {tag}{" "}
                                    <FeatherIcon
                                      icon="x"
                                      className="wd-10 mg-r-5"
                                      onClick={() => {
                                        removeTag(idx);
                                      }}
                                    />
                                  </span>
                                </React.Fragment>
                              );
                            })}
                        </div>
                      </Col>

                      {/* // stts */}
                      <Col
                        col={5}
                        className="mt-3">
                        <FormGroup mb="20px">
                          <Label htmlFor="status">
                            {Trans("STATUS", language)} :{" "}
                          </Label>
                          <select
                            {...register("status")}
                            className="form-control"
                            defaultValue={editInfo?.status}>
                            <option value="0">
                              {Trans("DRAFT", language)}
                            </option>
                            <option value="1">
                              {Trans("PUBLISH", language)}
                            </option>
                            <option value="2">
                              {Trans("INACTIVE", language)}
                            </option>
                          </select>
                        </FormGroup>
                      </Col>

                      <Col
                        col={4}
                        className="mt-2">
                        <LoaderButton
                          formLoadStatus={formloadingStatus}
                          btnName={Trans("UPDATE", language)}
                          className="btn btn-sm btn-bg btn-block"
                        />
                      </Col>
                      <br />
                    </Row>
                  </form>
                </FormProvider>
              </>
            </div>
          </div>
        </div>
      </div>
    </Content>
  );
};

export default Edit;
