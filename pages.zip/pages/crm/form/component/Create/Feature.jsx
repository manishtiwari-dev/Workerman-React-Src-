import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useFormContext } from "react-hook-form";
import { Card, Button } from "react-bootstrap";
import { useFieldArray } from "react-hook-form";
import { Trans } from "lang";
import { Row, Col, FormGroup, Label } from "component/UIElement/UIElement";
import FeatherIcon from "feather-icons-react";
import { ErrorMessage } from "@hookform/error-message";

function Field({ productAttribute }) {
  const { language } = useSelector((state) => state.login);

  const methods = useFormContext();

  const {
    register,
    control,
    formState: { errors },
  } = methods;

  const productFeature = useFieldArray({
    control,
    name: "form_field",
  });

  console.log("productAttribute", productAttribute);
  return (
    <Col col={12}>
      <Card className="mb-3">
        <Card.Header as="h6">
          {Trans("FORM_FIELD", language)}
          <span style={{ float: "right" }}>
            <button
              type="button"
              className="btn btn-xs btn-info"
              onClick={() => {
                productFeature.prepend({});
              }}
            >
              <FeatherIcon icon="plus" fill="white" />
              {Trans("ADD_MORE_FIELD", language)}
            </button>
          </span>
        </Card.Header>
        {productFeature.fields && (
          <Card.Body>
            {productFeature.fields.map((item, index) => {
              return (
                <Row key={item.id}>
                  <Col col={4}>
                    <FormGroup>
                      <input
                        {...register(`form_field.${index}.field_label`)}
                        className="form-control"
                        id={`proFeature.${index}.field_label`}
                        placeholder={Trans("FIELD_LABEL", language)}
                      />
                      <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`form_field.${index}.field_label`}
                        />
                      </span>
                    </FormGroup>
                  </Col>
                  <Col col={4}>
                    <FormGroup>
                      <input
                        {...register(`form_field.${index}.field_name`)}
                        className="form-control"
                        id={`form_field.${index}.field_name`}
                        placeholder={Trans("FIELD_NAME", language)}
                      />
                      <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`form_field.${index}.field_name`}
                        />
                      </span>
                    </FormGroup>
                  </Col>

                  <Col col={4}>
                    <FormGroup>
                    <select
                id="Status"
                label={Trans("STATUS", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register(`form_field.${index}.field_type`)}
                placeholder={Trans("FIELD_TYPE", language)}
              >
               <option value="">SELECT_FIELD_TYPE</option>
               <option value="text">text</option>
               <option value="checkbox">checkbox</option>
               <option value="dropdown">dropdown</option>
               <option value="radio">radio</option>
               <option value="email">email</option>
               <option value="submit">submit</option>
 
             </select>
                      
               </FormGroup>
                  </Col>
                  <Col col={4}>
                    <FormGroup>
                      <input
                        {...register(`form_field.${index}.field_values`)}
                        className="form-control"
                        id={`proFeature.${index}.field_values`}
                        placeholder={Trans("FIELD_OPTIONS", language)}
                      />
                      <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`form_field.${index}.field_values`}
                        />
                      </span>
                    </FormGroup>
                  </Col>
                  <Col col={4}>
                    <FormGroup>
                      <input
                        {...register(`form_field.${index}.field_class`)}
                        className="form-control"
                        id={`proFeature.${index}.field_values`}
                        placeholder={Trans("FIELD_CLASS", language)}
                      />
                     
                    </FormGroup>
                  </Col>
                  <Col col={4}>
                    <FormGroup>
                    <select
                id="REQUIRED"
                label={Trans("REQUIRED", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register(`form_field.${index}.required`)}
                placeholder={Trans("REQUIRED", language)}
              >
               <option value="">REQUIRED</option>
               <option value={1}>Yes</option>
               <option value={0}>NO</option>
             </select>
                      
               </FormGroup>
                  </Col>
                
                  <Col col={1}>
                    <span style={{ lineHeight: "42px" }}>
                      <FeatherIcon
                        icon="x-square"
                        color="red"
                        onClick={() => productFeature.remove(index)}
                        size={20}
                      />
                    </span>
                  </Col>
                </Row>
              );
            })}
          </Card.Body>
        )}
      </Card>
    </Col>
  );
}

export default Field;
