import React, { useState, useEffect,useRef } from "react";

import { useSelector } from "react-redux";
import { useFormContext } from "react-hook-form";
import { Card, Button } from "react-bootstrap";
import { useFieldArray } from "react-hook-form";
import { Trans } from "lang";
import { Row, Col, FormGroup, Label } from "component/UIElement/UIElement";
import FeatherIcon from "feather-icons-react";
import { ErrorMessage } from "@hookform/error-message";

function Feature({ editFeature, editLoad,props }) {
  const { language } = useSelector((state) => state.login);

  const a = useRef(null);

  const methods = useFormContext();

  const {
    register,
    control,
    formState: { errors },
  } = methods;

  const productFeature = useFieldArray({
    control,
    name: "form_field",
  });
  const [selectType, SetSelectType] = useState("submit");
  const [selectlabel, SetSelectLabel] = useState("field_label");


  // useEffect(() => {
  //   if (editFeature !== undefined) {
  //     let feature = [];
  //     for (let index = 0; index < editFeature.length; index++) {
  //       const elem = editFeature[index];
  //       feature.push({
  //           field_label: elem.field_label,
  //           field_name: elem.field_name,
  //           field_type: elem.field_type,
  //           field_values: elem.field_values,
  //           required: elem.required,

            
  //       });
  //     }
  //     productFeature.append(feature);
  //   }
  // }, [editLoad]);

  // useEffect(() => {
  //   if (editFeature !== undefined) {
  //     let feature = [];
  //     for (let index = 0; index < editFeature.length; index++) {
  //       const elem = editFeature[index];
  //       feature.push({
  //         field_label: elem.field_label,
  //         field_name: elem.field_name,
  //         field_type: elem.field_type,
  //         field_values: elem.field_values,
  //         field_class: elem.field_class,
  //         required: elem.required,
  //         field_width: elem.field_width,
  //         placeholder: elem.placeholder,
  //         validation_msg: elem.validation_msg,
  //         sort_order: elem.sort_order,

  //       });
  //     }
  //     productFeature.replace(feature);
  //   }
  // }, []);





  
  const myfun =()=>  {
 
    var a = document.getElementById("slug-source").value;

    var b = a.toLowerCase().replace(/ /g, '-')
        .replace(/[^\w-]+/g, '');

    document.getElementById("slug-target").value = b;

};




  return (
    <Col col={12}>
      <Card className="mb-3">
        <Card.Header as="h6">
          {Trans("FORM_FIELD", language)}
          <span style={{ float: "right" }}>
            <button
              type="button"
              className="btn btn-sm btn-bg"
              onClick={() => {
                productFeature.append({});
              }}
            >
              <FeatherIcon icon="plus" fill="white" />
              {Trans("ADD_MORE_FIELD", language)}
            </button>
          </span>
        </Card.Header>

       <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th> {Trans("LABEL", language)}</th>
                <th>{Trans("NAME", language)}</th>
                 <th>{Trans("TYPE", language)}</th>
                 <th> {Trans("VALUES", language)}</th>
                <th>{Trans("CLASS", language)}</th>
                <th> {Trans("WIDTH", language)}</th>
                <th>{Trans("PLACEHOLDER", language)}</th>
              
                <th> {Trans("SORT_ORDER", language)}</th>
                <th>{Trans("REQUIRED", language)}</th>
                <th>{Trans("VALIDATION_MSG", language)}</th>
              </tr>
            </thead>
            {productFeature?.fields && (
               
            <tbody>
            
                  {productFeature?.fields.map((item, index) => {
                    return (
                    <React.Fragment >
                      <tr>
                        <td>   
                      <input
                        {...register(`form_field.${index}.field_label`,
                        
                        {
                          required: Trans("FIELD_LABEL_REQUIRED", language),
                        }
                        
                        
                        )}
                        className="form-control  form-control-sm"
                        id={`slug-source`}
                        placeholder={Trans("FIELD_LABEL", language)}
                        onKeyUp={() => {
                          myfun();
                        }} 
                      />
                      <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`form_field.${index}.field_label`}
                        />
                      </span>
                 
                    </td>
                        <td> <input
                        {...register(`form_field.${index}.field_name`,
                        
                        )}
                        className="form-control  form-control-sm"
                        id={`slug-target`}
                        placeholder={Trans("FIELD_NAME", language)}
                        readOnly={true}
                      /></td>
                  <td>   <select
                id="FIELD_TYPE"
                label={Trans("FIELD_TYPE", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm px-1"
                {...register(`form_field.${index}.field_type`,

                {
                  required: Trans("FIELD_TYPE_REQUIRED", language),
                }
                
                
                )}
                placeholder={Trans("FIELD_TYPE", language)}
              
                onChange={(event) => {
                  SetSelectType(event.target.value);
                }}
              >
               <option value="">{Trans("SELECT", language)}</option>
               <option value="text">Text</option>
               <option value="checkbox" defaultValue="checkbox">Checkbox</option>
               <option value="dropdown" defaultValue="dropdown">Dropdown</option>
               <option value="radio">Radio</option>
               <option value="email">Email</option>
               <option value="textarea">Textarea</option>
               <option value="submit">Submit</option>

                   </select>

                <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`form_field.${index}.field_type`}
                        />
                      </span></td>
                
               
                 <td>
                 <input
                      {...register(`form_field.${index}.field_values`)}
                      className="form-control form-control-sm px-1"
                      id={`proFeature.${index}.field_values`}
                      placeholder="Multiple use comma seperate"
                      readOnly={selectType === "checkbox" || selectType === "dropdown" ? false : true}

                    />
                 </td>
                 

               
                 <td>
                 <input
                      {...register(`form_field.${index}.field_class`)}
                      className="form-control form-control-sm px-1"
                      id={`proFeature.${index}.field_values`}
                      placeholder={Trans("FIELD_CLASS", language)}
                    />
                 </td>
                 
                 <td>
                 <select
                id="FIELD_WIDTH"
                label={Trans("FIELD_WIDTH", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm px-1"
                {...register(`form_field.${index}.field_width`,
                
              
                
                )}
                placeholder={Trans("FIELD_WIDTH", language)}
              
              >
               <option value=""> {Trans("SELECT", language)}</option>
               <option value="100">100</option>
               <option value="75">75</option>
               <option value="50">50</option>
               <option value="33">33</option>
               <option value="25">25</option>
               <option value="20">20</option>
            
 
             </select>
                 </td>
                 
                 <td>
                 <input
                        {...register(`form_field.${index}.placeholder`)}
                        className="form-control form-control-sm px-1"
                        id={`proFeature.${index}.placeholder`}
                        placeholder={Trans("FIELD_PLACEHOLDER", language)}
                      />
                     
                 </td>

                  <td><input
                       type="number"
                        {...register(`form_field.${index}.sort_order`)}
                        className="form-control  form-control-sm"
                        id={`proFeature.${index}.sort_order`}
                        placeholder={Trans("SORT_ORDER", language)}
                      /></td>
                        <td>        <select
                id="REQUIRED"
                label={Trans("REQUIRED", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register(`form_field.${index}.required`)}
                placeholder={Trans("REQUIRED", language)}
              >
               <option value="">{Trans("REQUIRED", language)} </option>
               <option value={1}>Yes</option>
               <option value={0}>No</option>
             </select></td>

             <td>
                 <input
                        {...register(`form_field.${index}.validation_msg`)}
                        className="form-control form-control-sm px-1"
                        id={`proFeature.${index}.validation_msg`}
                        placeholder={Trans("VALIDATION_MSG", language)}
                      />
                     
                 </td>

                        
             <td>  <Col col={1} className="px-1">
                    <span style={{ lineHeight: "42px" }}>
                      <FeatherIcon
                        icon="x-square"
                        color="red"
                        onClick={() => productFeature.remove(index)}
                        size={20}
                      />
                    </span>
                  </Col></td>
                      </tr>
                    </React.Fragment>
                   );
                  })}
            </tbody>
              )}
          </table>
        </div>

      </Card>
    </Col>
  );
}

export default Feature;
