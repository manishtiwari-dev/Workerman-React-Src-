import React from "react";

function PaymentSetting() {
  return <></>;
}

export default PaymentSetting;
