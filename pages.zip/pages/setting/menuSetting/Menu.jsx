import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import {
  MenuListUrl,
  BannerUpdateSettingUrl,
  MenuGroupUrl,
  MenuChangeStatusUrl,
  MenuDestroyUrl,
  MenuSortOrderUrl,
} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Create from "./Create";
import { Col, BadgeShow, IconButton } from "component/UIElement/UIElement";
import { useForm } from "react-hook-form";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { useParams } from "react-router-dom";
import { MenuSetting } from "config/WebsiteUrl";
import ModalAlert from "component/ModalAlert";
import {
  MenusSetting,
  SuperMenusSetting,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";

import Edit from "./Edit";
import WebsiteLink from "config/WebsiteLink";

function Menu() {
  const { menuGroupId } = useParams();

  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");

  const methods = useForm({
    defaultValues: {
      settingdata: [
        {
          banner_setting_id: 1,
          template_id: 1,
          refrence_id: "asdsad",
          banner_position_id: "",
          images_id: "",
          comment: 1,
        },
      ],
    },
  });

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  // handle change group name
  const [sectionListing, SetSectionListing] = useState([]);

  const [bannerList, SetBannerList] = useState([]);

  const [catName, SetCatName] = useState("");

  const [typeName, SetTypeName] = useState("");

  const findListBanner = (id, sortBys, orderByS) => {
    const filterData = {
      api_token: apiToken,
      language: language,
      group_id: id,
      sortBy: sortBys,
      orderBY: orderByS,
    };
    POST(MenuListUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        console.log("Banner list", data);
        if (status) {
          SetloadingStatus(false);
          SetBannerList(data.data_list);
          SetCatName(data.group_name);
          SetTypeName(data.menu_type);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();

    findListBanner(menuGroupId, sortByS, orderByS);
    return () => abortController.abort();
  }, []);

  const destroyItem = (id) => {
    const filterData = {
      api_token: apiToken,
      menu_id: id,
    };
    POST(MenuDestroyUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(menuGroupId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const changeStatus = (id, type) => {
    const filterData = {
      api_token: apiToken,
      update_id: id,
      type: "menu",
      // menu_id: id,
    };

    POST(MenuChangeStatusUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(menuGroupId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };

  const filterItem = () => {
    findListBanner(menuGroupId);
  };
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: destroyItem,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  // change Status function
  const ChangeStatusfun = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: changeStatus,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const UpdateOrderStatus = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      menu_id: update_id,
      sort_order: sortOrder,
    };
    POST(MenuSortOrderUrl, editData)
      .then((response) => {
        const { message } = response.data;
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };

  const page_access =
    userType == "subscriber" ? MenusSetting : SuperMenusSetting;

  return (
    <Content>
      <CheckPermission
        PageAccess={page_access}
        PageAction={PreView}>
        <>
          <div
            className="card"
            id="custom-user-list">
            <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
              <h6 className=" tx-semibold mg-b-0">{catName}</h6>
              <div className=" d-md-flex">
                <CheckPermission
                  PageAccess={page_access}
                  PageAction={PreAdd}>
                  <Button
                    // variant="primary"
                    className=" btn-sm btn-bg"
                    onClick={handleModalShow}>
                    <FeatherIcon
                      icon="plus"
                      fill="white"
                      className="wd-10 mg-r-5 "
                    />
                    {Trans("ADD_MENU", language)}
                  </Button>
                </CheckPermission>
              </div>
            </div>

            {/* END CARD HEADER */}

            <div className="card-body">
              <div className="table-responsive menu_list ">
                <table
                  className="table table-center   mb-0 "
                  >
                  <thead>
                    <tr>
                      <th className="text-center">
                        {Trans("SL_NO", language)}
                      </th>
                      <th className="text-center">
                        {Trans("MENU_NAME", language)}
                      </th>
                      <th className="text-center">
                        {Trans("MENU_TYPE", language)}
                      </th>
                      <th className="text-center">
                        {Trans("MENU_LINK", language)}
                      </th>
                      <th className="text-center">
                        {Trans("SORT_ORDER", language)}
                      </th>
                      <th className="text-center">
                        {Trans("STATUS", language)}
                      </th>
                      <th className="text-center">
                        {Trans("ACTION", language)}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {bannerList &&
                      bannerList.map((menu, idx) => {
                        return (
                          <>
                            <tr>
                              <td className="text-center">{idx + 1}</td>
                              <td className=" fw-bold">
                                <FeatherIcon
                                  style={{
                                    cursor: "pointer",
                                  }}
                                  icon="arrow-down-circle"
                                  size={13}
                                />
                                {menu?.menuName}
                              </td>
                              <td className=" text-center fw-bold">
                                {menu.menu_type === 1
                                  ? "Category"
                                  : menu.menu_type === 2
                                  ? "Page"
                                  : menu.menu_type === 4
                                  ? "BizServices"
                                  : "Custom Link"}
                              </td>
                              <td className="text-center fw-bold">
                                {menu.menu_link}
                              </td>

                              <td className="text-center fw-bold">
                                <input
                                  type="number"
                                  name=""
                                  id=""
                                  defaultValue={menu.sort_order}
                                  style={{ width: "60px", textAlign: "center" }}
                                  onBlur={(e) => {
                                    UpdateOrderStatus(
                                      menu.menu_id,
                                      e.target.value
                                    );
                                  }}
                                />
                              </td>

                              <td className="text-center">
                                <div className="custom-control custom-switch">
                                  <input
                                    onClick={() =>
                                      ChangeStatusfun(menu.menu_id)
                                    }
                                    type="checkbox"
                                    class="custom-control-input"
                                    id={`section${menu.menu_id}`}
                                    checked={menu.status === 0 ? "" : "checked"}
                                  />
                                  <label
                                    className="custom-control-label"
                                    For={`section${menu.menu_id}`}></label>
                                </div>
                              </td>
                              <td className="text-center">
                                <IconButton
                                  color="primary"
                                  onClick={() => editFunction(menu?.menu_id)}>
                                  <FeatherIcon
                                    icon="edit-2"
                                    fill="white"
                                    onClick={() => editFunction(menu?.menu_id)}
                                  />
                                </IconButton>{" "}
                                {/* <IconButton
                               color="primary"
                               onClick={() =>
                                ChangeStatusfun(menu?.menu_id, "menu")
                               
                              }
                            >
                              <FeatherIcon
                                icon="repeat"
                                fill="white"
                                onClick={() =>
                                  ChangeStatusfun(menu?.menu_id,"menu")
                                }
                              />
                            </IconButton> */}
                                {"  "}
                                <IconButton
                                  color="primary"
                                  onClick={() => deleteItem(menu?.menu_id)}>
                                  <FeatherIcon
                                    icon="x-square"
                                    color="black"
                                    onClick={() => deleteItem(menu?.menu_id)}
                                  />
                                </IconButton>
                                {"  "}
                              </td>
                            </tr>

                            {menu?.sub_menu &&
                              menu?.sub_menu.map((parentdata, index) => {
                                return (
                                  <>
                                    <tr>
                                      <td className="text-center">
                                        {index + 1}
                                      </td>

                                      {parentdata?.menu_details &&
                                        parentdata?.menu_details.map(
                                          (menuDetailsdata, IDX) => {
                                            return (
                                              <td className="">
                                                <FeatherIcon
                                                  style={{
                                                    cursor: "pointer",
                                                  }}
                                                  icon="arrow-right"
                                                  size={13}
                                                />

                                                {menuDetailsdata === ""
                                                  ? ""
                                                  : menuDetailsdata?.menu_name}
                                              </td>
                                            );
                                          }
                                        )}

                                      <td className="text-center">
                                        {parentdata.menu_type === 1
                                          ? "Category"
                                          : parentdata.menu_type === 2
                                          ? "Page"
                                          : parentdata.menu_type === 4
                                          ? "BizServices"
                                          : "Custom Link"}
                                      </td>
                                      <td className="text-center">
                                        {parentdata.menu_link}
                                      </td>

                                      <td className="text-center">
                                        <input
                                          type="number"
                                          name=""
                                          id=""
                                          defaultValue={parentdata.sort_order}
                                          style={{
                                            width: "60px",
                                            textAlign: "center",
                                          }}
                                          onBlur={(e) => {
                                            UpdateOrderStatus(
                                              parentdata.menu_id,
                                              e.target.value
                                            );
                                          }}
                                        />
                                      </td>
                                      <td className="text-center">
                                        <div
                                          className="custom-control custom-switch"
                                          // onClick={() => {
                                          //   ChangeFunction(
                                          //     componentdata.section_id
                                          //   );
                                          //   // filterItem("refresh", "", "");
                                          // }}
                                        >
                                          <input
                                            onClick={() =>
                                              ChangeStatusfun(
                                                parentdata.menu_id
                                              )
                                            }
                                            type="checkbox"
                                            class="custom-control-input"
                                            id={`section${parentdata.menu_id}`}
                                            checked={
                                              parentdata.status === 0
                                                ? ""
                                                : "checked"
                                            }
                                          />
                                          <label
                                            className="custom-control-label"
                                            For={`section${parentdata.menu_id}`}></label>
                                        </div>

                                        {/* <BadgeShow
                                          type={
                                            parentdata.status
                                              ? "active"
                                              : "deactive"
                                          }
                                          content={
                                            parentdata.status
                                              ? "active"
                                              : "deactive"
                                          }
                                        />{" "} */}
                                      </td>
                                      <td className="text-center">
                                        <IconButton
                                          color="primary"
                                          onClick={() =>
                                            editFunction(parentdata?.menu_id)
                                          }>
                                          <FeatherIcon
                                            icon="edit-2"
                                            fill="white"
                                            onClick={() =>
                                              editFunction(parentdata?.menu_id)
                                            }
                                          />
                                        </IconButton>{" "}
                                        {"  "}
                                        <IconButton
                                          color="primary"
                                          onClick={() =>
                                            deleteItem(parentdata?.menu_id)
                                          }>
                                          <FeatherIcon
                                            icon="x-square"
                                            color="white"
                                            onClick={() =>
                                              deleteItem(parentdata?.menu_id)
                                            }
                                          />
                                        </IconButton>
                                        {"  "}
                                      </td>
                                    </tr>

                                    {parentdata?.sub_sub_menu &&
                                      parentdata?.sub_sub_menu.map(
                                        (submenu, IDX) => {
                                          return (
                                            <tr>
                                              <td className="text-center">
                                                {index + 1}
                                              </td>

                                              <td className="text-center">
                                                <FeatherIcon
                                                  style={{
                                                    cursor: "pointer",
                                                  }}
                                                  //  icon="arrow-right"
                                                  size={20}
                                                />

                                                {
                                                  submenu?.sub_sub_menu_details
                                                    ?.menu_name
                                                }
                                              </td>

                                              {/* );
                                            })   } */}

                                              <td className="text-center">
                                                {submenu.menu_type === 1
                                                  ? "Category"
                                                  : submenu.menu_type === 2
                                                  ? "Page"
                                                  : submenu.menu_type === 4
                                                  ? "BizServices"
                                                  : "Custom Link"}
                                              </td>
                                              <td className="text-center">
                                                {submenu.menu_link}
                                              </td>

                                              <td className="text-center">
                                                <input
                                                  type="number"
                                                  name=""
                                                  id=""
                                                  defaultValue={
                                                    submenu.sort_order
                                                  }
                                                  style={{
                                                    width: "60px",
                                                    textAlign: "center",
                                                  }}
                                                  onBlur={(e) => {
                                                    UpdateOrderStatus(
                                                      submenu.menu_id,
                                                      e.target.value
                                                    );
                                                  }}
                                                />
                                              </td>
                                              <td className="text-center">
                                                <div
                                                  className="custom-control custom-switch"
                                                  // onClick={() => {
                                                  //   ChangeFunction(
                                                  //     componentdata.section_id
                                                  //   );
                                                  //   // filterItem("refresh", "", "");
                                                  // }}
                                                >
                                                  <input
                                                    onClick={() =>
                                                      ChangeStatusfun(
                                                        submenu.menu_id
                                                      )
                                                    }
                                                    type="checkbox"
                                                    class="custom-control-input"
                                                    id={`section${submenu.menu_id}`}
                                                    checked={
                                                      submenu.status === 0
                                                        ? ""
                                                        : "checked"
                                                    }
                                                  />
                                                  <label
                                                    className="custom-control-label"
                                                    For={`section${submenu.menu_id}`}></label>
                                                </div>

                                                {/* <BadgeShow
                                      type={
                                        parentdata.status
                                          ? "active"
                                          : "deactive"
                                      }
                                      content={
                                        parentdata.status
                                          ? "active"
                                          : "deactive"
                                      }
                                    />{" "} */}
                                              </td>
                                              <td className="menu-action">
                                                <IconButton
                                                  color="primary"
                                                  onClick={() =>
                                                    editFunction(
                                                      submenu?.menu_id
                                                    )
                                                  }>
                                                  <FeatherIcon
                                                    icon="edit-2"
                                                    fill="white"
                                                    onClick={() =>
                                                      editFunction(
                                                        submenu?.menu_id
                                                      )
                                                    }
                                                  />
                                                </IconButton>{" "}
                                                {"  "}
                                                <IconButton
                                                  color="primary"
                                                  onClick={() =>
                                                    deleteItem(submenu?.menu_id)
                                                  }>
                                                  <FeatherIcon
                                                    icon="x-square"
                                                    color="black"
                                                    onClick={() =>
                                                      deleteItem(
                                                        submenu?.menu_id
                                                      )
                                                    }
                                                  />
                                                </IconButton>
                                                {"  "}
                                              </td>
                                            </tr>
                                          );
                                        }
                                      )}
                                  </>
                                );
                              })}
                          </>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      </CheckPermission>

      {/* add modal */}
      <Modal
        show={show}
        onHide={handleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_MENU", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create
            loadSettingData={findListBanner}
            handleModalClose={handleModalClose}
            filterItem={filterItem}
            menuGroupId={menuGroupId}
            typeName={typeName}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit modal */}
      <Modal
        show={editModalShow}
        onHide={handleEditModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("UPDATE_MENU", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Edit
            editData={editData}
            filterItem={filterItem}
            handleModalClose={handleEditModalClose}
            menuGroupId={menuGroupId}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </Content>
  );
}

export default Menu;
