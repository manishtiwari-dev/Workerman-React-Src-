import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useParams } from "react-router-dom";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useForm, FormProvider } from "react-hook-form";
import { TitleSuffix, PagesUpdateUrl, PagesEditUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Anchor,
  Label,
  StatusSelect,
  IndexSelect,
  TextArea,
} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import WebsiteLink from "config/WebsiteLink";
import { useNavigate, Navigate } from "react-router-dom";
import FeatherIcon from "feather-icons-react";
import { PageSetting, SuperadminUrl } from "config/WebsiteUrl";
import ContentEditor from "component/ContentEditor";

const Edit = () => {
  const { pageId } = useParams();
  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const navigate = useNavigate();

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const [editProAttribute, SetEditProAttribute] = useState();
  const [editLoad, SeteditLoad] = useState(false);
  const [key, setKey] = useState("default_language");

  console.log(PageSetting);
  // const methods = useForm();
  const methods = useForm({});

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    getValues,
  } = methods;

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(PagesUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          Notify(true, Trans(message, language));

          if (userType === "subscriber") {
            navigate(`/pages-setting`);
          } else {
            navigate("/superadmin/pages-setting");
          }
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(false, errObj.msg);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };

  const [langList, SetlangList] = useState([]);
  const [editInfo, SeteditInfo] = useState("");
  const [editName, SeteditName] = useState("");

  // edit info

  const saveValueToField = () => {
    const formData = {
      api_token: apiToken,
      language: language,
      pages_id: pageId,
    };
    POST(PagesEditUrl, formData)
      .then((response) => {
        const { status, data } = response.data;

        if (status) {
          SetloadingStatus(false);
          const { data } = response.data;

          SeteditInfo(data.data_list);

          SetlangList(data.language);

          const fieldList = getValues();

          for (const key in fieldList) {
            setValue(key, data.data_list[key]);
          }

          let page_title = "";
          // display product_name value
          if (data?.data_list.page_description.length > 0) {
            const lang_with_page = data?.data_list.page_description;
            console.log(lang_with_page);
            for (let index = 0; index < lang_with_page.length; index++) {
              page_title = lang_with_page[index].pages_title;
              const pages_content = lang_with_page[index].pages_content;
              //  console.log(pro_desc);
              setValue(
                "pages_title_" + lang_with_page[index].language_id,
                page_title
              );
              SeteditName(page_title);
              //console.log(pro_name);
              setValue(
                "pages_content_" + lang_with_page[index].language_id,
                pages_content
              );

              if (lang_with_page[index].seo !== null) {
                setValue(
                  "seometa_title_" + lang_with_page[index]["language_id"],
                  lang_with_page[index].seo.seometa_title
                );
                setValue(
                  "seometa_desc_" + lang_with_page[index]["language_id"],
                  lang_with_page[index].seo.seometa_desc
                );
              }
            }
          }
          SeteditLoad(true);
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, error.message);
        console.error("There was an error!", error);
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    saveValueToField();
    return () => abortController.abort();
  }, []);

  useEffect(() => {
    document.title = `${editName}` + `${TitleSuffix}`;
    let abortController = new AbortController();

    return () => abortController.abort();
  }, [editLoad]);

  // const myfun =()=>  {

  //   var a = document.getElementById(`slug-source_${language}`).value;

  //     var b = a.toLowerCase().replace(/ /g, '-')
  //     .replace(/[^\w-]+/g, '');

  //     document.getElementById(`slug-target_${language}`).value = b;

  // };

  const myfun = () => {
    var a = document.getElementById("slug-source").value;

    var b = a
      .toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^\w-]+/g, "");

    document.getElementById("slug-target").value = b;
  };

  return (
    <Content>
      {/* <PageHeader
        breadcumbs={[
          { title: Trans("DASHBOARD", language), link: "/", class: "" },
          {
            title: Trans("PRODUCT", language),
            link: WebsiteLink("/products"),
            class: "",
          },
          { title: Trans("EDIT", language), link: "", class: "active" },
        ]}
      /> */}

      <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
          <div
            className="card"
            id="custom-user-list">
            <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
              <h6 className=" tx-semibold mg-b-0">
                {Trans("EDIT_PAGES", language)}
              </h6>
              <div className=" d-md-flex">
                <Anchor
                  className="btn btn-sm btn-bg pd-3"
                  path={WebsiteLink(PageSetting)}>
                  <FeatherIcon
                    //  icon="corner-down-left"
                    className="wd-10 mg-r-5"
                  />
                  {Trans("GO_BACK", language)}
                </Anchor>
              </div>
            </div>
            <div className="card-body">
              <>
                {error.status && (
                  <Alert
                    variant={error.type}
                    onClose={() =>
                      setError({ status: false, msg: "", type: "" })
                    }
                    dismissible>
                    {error.msg}
                  </Alert>
                )}
                <FormProvider {...methods}>
                  <form
                    action="#"
                    onSubmit={handleSubmit(onSubmit)}
                    noValidate>
                    <input
                      type="hidden"
                      {...register("pages_id")}
                    />

                    <Col col={12}>
                      <fieldset className="form-fieldset">
                        <legend>{Trans("PAGE_INFORMATION", language)}</legend>
                        <Row>
                          <Col col={12}>
                            <Tabs
                              id="controlled-tab-example"
                              onSelect={(k) => setKey(k)}
                              className="mb-3">
                              {langList &&
                                langList.map((lang) => {
                                  const {
                                    languages_code,
                                    languages_id,
                                    languages_name,
                                  } = lang;

                                  return (
                                    <Tab
                                      eventKey={languages_code}
                                      key={languages_id}
                                      title={languages_name}>
                                      <Row>
                                        <Col col={12}>
                                          <FormGroup mb="20px">
                                            <Input
                                              id={`slug-source`}
                                              label={`${Trans(
                                                "PAGE_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              placeholder={`${Trans(
                                                "PAGE_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              hint="Enter text" // for bottom hint
                                              className="form-control"
                                              {...register(
                                                `pages_title_${languages_id}`
                                              )}
                                              onKeyUp={() => {
                                                myfun();
                                              }}
                                            />
                                            {/* <span className="required">
                                          <ErrorMessage
                                            errors={errors}
                                            name={`pages_title_${languages_id}`}
                                          />
                                        </span> */}
                                          </FormGroup>
                                        </Col>

                                        {/* <Col col={6}>
                                      <FormGroup mb="20px">
                                        <Input
                                          id={`slug-target_${languages_code}`}
                                          
                                        //  id={`slug-target`}
                                          label={`${Trans(
                                            "PAGE_SLUG",
                                            language
                                          )}`}
                                          placeholder={`${Trans(
                                            "PAGE_SLUG",
                                            language
                                          )} (${languages_code})`}
                                          hint="Enter text" // for bottom hint
                                          className="form-control"
                                          {...register(
                                            `pages_slug`,
                                            {
                                            
                                            }
                                          )}
                                        />
                                      
                                      </FormGroup>
                                    </Col> */}

                                        <Col col={12}>
                                          <FormGroup>
                                            <Label>
                                              {`${Trans(
                                                "PAGES_CONTENT",
                                                language
                                              )} (${languages_code})`}
                                            </Label>

                                            <ContentEditor
                                              className="Editor"
                                              initialValue={
                                                getValues(
                                                  `pages_content_${languages_id}`
                                                ) === null
                                                  ? "<p></p>"
                                                  : getValues(
                                                      `pages_content_${languages_id}`
                                                    )

                                                // getValues(
                                                //   `pages_content_${languages_id}`
                                                // )
                                              }
                                              setKey={`pages_content_${languages_id}`}
                                              updateFun={(Key, Value) => {
                                                setValue(Key, Value);
                                              }}
                                            />

                                            <textarea
                                              {...register(
                                                `pages_content_${languages_id}`
                                              )}
                                              style={{
                                                display: "none",
                                              }}></textarea>
                                          </FormGroup>
                                        </Col>

                                        <Col col={12}>
                                          <FormGroup mb="20px">
                                            <Input
                                              id={`${Trans(
                                                "SEO_META_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              label={`${Trans(
                                                "SEO_META_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              placeholder={`${Trans(
                                                "SEO_META_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              className="form-control"
                                              {...register(
                                                `seometa_title_${languages_id}`
                                              )}
                                              //   value={metaEditorValue}
                                            />
                                          </FormGroup>
                                        </Col>

                                        <Col col={12}>
                                          <FormGroup mb="20px">
                                            <TextArea
                                              // id={`${Trans(
                                              //   "SEO_META_DESCRIPTION",
                                              //   language
                                              // )} (${languages_code})`}
                                              label={`${Trans(
                                                "SEO_META_DESCRIPTION",
                                                language
                                              )} (${languages_code})`}
                                              placeholder={`${Trans(
                                                "SEO_META_DESCRIPTION",
                                                language
                                              )} (${languages_code})`}
                                              hint="Enter text" // for bottom hint
                                              className="form-control"
                                              {...register(
                                                `seometa_desc_${languages_id}`
                                              )}

                                              //    value={metaDescEditorValue}
                                            />
                                          </FormGroup>
                                        </Col>
                                      </Row>
                                    </Tab>
                                  );
                                })}
                            </Tabs>
                          </Col>
                        </Row>
                      </fieldset>
                    </Col>

                    <Col col={12}>
                      <fieldset className="form-fieldset">
                        <legend>{Trans("OTHER_INFORMATION", language)}</legend>
                        <Row>
                          <Col col={12}>
                            <FormGroup mb="20px">
                              <Input
                                label={Trans("PAGE_SLUG", language)}
                                placeholder={Trans("PAGE_SLUG", language)}
                                id={`slug-target`}
                                hint="Enter text" // for bottom hint
                                className="form-control"
                                {...register(`pages_slug`)}
                              />
                            </FormGroup>
                          </Col>
                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                id={Trans("SORT_ORDER", language)}
                                type="number"
                                label={Trans("SORT_ORDER", language)}
                                placeholder={Trans("SORT_ORDER", language)}
                                className="form-control"
                                {...register("sort_order", {
                                  required: Trans(
                                    "SORT_ORDER_REQUIRED",
                                    language
                                  ),
                                })}
                              />
                              <span className="required">
                                <ErrorMessage
                                  errors={errors}
                                  name="sort_order"
                                />
                              </span>
                            </FormGroup>
                          </Col>
                          <Col col={6}>
                            <FormGroup mb="20px">
                              <IndexSelect
                                id={Trans("NOINDEX", language)}
                                label={Trans("NOINDEX", language)}
                                className="form-control"
                                {...register("noindex", {})}
                              />
                              <span className="required">
                                <ErrorMessage
                                  errors={errors}
                                  name="featured"
                                />
                              </span>
                            </FormGroup>
                          </Col>
                          <Col
                            col={4}
                            style={{ marginTop: "10px" }}>
                            <LoaderButton
                              formLoadStatus={formloadingStatus}
                              btnName={Trans("UPDATE", language)}
                              className="btn btn-sm btn-bg btn-block"
                            />
                          </Col>
                        </Row>
                      </fieldset>
                    </Col>
                  </form>
                </FormProvider>
              </>
            </div>
          </div>
        </div>
      </div>
    </Content>
  );
};

export default Edit;
