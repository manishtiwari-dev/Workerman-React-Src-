import React, { useEffect, useState,useRef } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { TemplateDetailUrl, TemplateSettingUrl } from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Col, Row, Anchor } from "component/UIElement/UIElement";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { useParams } from "react-router-dom";
//import Editor from "@monaco-editor/react";
import View from "./view";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";

import {
  PageTemplateSetting,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import SectionGroup from "./SectionGroup";
import { TemplateSetting } from "config/WebsiteUrl";


function ThemeDetail() {
  
  const { themeId } = useParams();

  const { apiToken, language } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [listData, SetlistData] = useState([]);
  const [selectData, SetselectData] = useState([]);

  const [htmlData, SetHtmlData] = useState([]);


  const editorRef = useRef(null);


  function handleEditorDidMount(editor, monaco) {
    editorRef.current = editor;
  }

  function showValue() {
    alert(editorRef.current?.getValue());
  }

  const findListBanner = (id) => {
    const filterData = {
      api_token: apiToken,
      template_id: id,
    };
    POST(TemplateDetailUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetlistData(data);
          SetHtmlData(data?.templates_html)
          loadTemplateSelectedData();
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };



  
//   console.log(htmlData.template_html);



  const loadTemplateSelectedData = () => {
    const filterData = {
      api_token: apiToken,
    };
    POST(TemplateSettingUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetselectData(data);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    document.title = "Template Setting | WorkerMan";

    let abortController = new AbortController();
    findListBanner(themeId);
    return () => abortController.abort();
  }, []);

  const refreshItem = () => {
    findListBanner(themeId);
  };

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);


  return (
    <Content>
      <CheckPermission PageAccess={PageTemplateSetting} PageAction={PreView}>
        <>
         

          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
              <CheckPermission PageAccess={PageTemplateSetting} PageAction={PreView}>
                <div className="card" id="custom-user-list">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {listData?.template_name}
                    </h6>

                    <div className=" d-md-flex">
                     <Anchor
                            path={WebsiteLink(
                              `/themes/code/${listData?.template_id}`
                            )}
                            className="btn btn-sm btn-bg"
                          >
                            
                            {Trans("TEMPLATE_CODE", language)}
                        
                    </Anchor>  
                    </div>
                  </div>

                  {/* <button onClick={showValue}>Show value</button>
                  <Editor
                    height="20vh"
                    defaultLanguage="javascript"
                    defaultValue={htmlData.template_html}
                  //  defaultValue={"df"}

                    onMount={handleEditorDidMount}
                  /> */}





                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Row className="">
                        {listData?.template_sections &&
                          listData?.template_sections.map((section, idx) => (
                            <SectionGroup
                              sectiongroup={section}
                              key={idx}
                              selectData={selectData}
                              refreshItem={refreshItem}
                            />
                          ))}
                      </Row>
                    </div>
                  )}
                </div>
              </CheckPermission>
            </div>
          </div>
        </>
      </CheckPermission>

        {/* add modal */}
        <Modal show={show} onHide={handleModalClose} size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("SHOW_HTML_CODE", language)}</Modal.Title>
          <Button variant="danger" onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <View
            handleModalClose={handleModalClose}
        //    filterItem={filterItem}
         //   htmlCode={htmlData.template_html}
          
          />
        </Modal.Body>
      </Modal>
    </Content>
  );
}

export default ThemeDetail;
