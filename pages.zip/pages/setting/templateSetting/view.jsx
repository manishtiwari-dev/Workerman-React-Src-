import React, { useEffect, useState, useRef } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import {
  EmailTemplateListUrl,
  MenuGroupUrl,
  TemlateSettingHtmlUpdateUrl,
  EmailTemplateDestroyUrl,
  TemlateHtmlUrl,
  TemlateSettingLangUrl
} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  Label,
} from "component/UIElement/UIElement";
import { useForm } from "react-hook-form";

import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { useParams } from "react-router-dom";
import { EmailSetting } from "config/WebsiteUrl";
import ModalAlert from "component/ModalAlert";
import Editor from "@monaco-editor/react";

import {
  PageEmailSetting,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";

import WebsiteLink from "config/WebsiteLink";

function EmailTemplate() {
  const { themeId } = useParams();

  const { apiToken, language, userType } = useSelector((state) => state.login);
  console.log(userType);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const loadSettingData = () => {
    const filterData = {
      api_token: apiToken,
    };
    // POST(TemlateHtmlUrl, filterData)
    //   .then((response) => {
    //     const { status, data, message } = response.data;
    //     if (status) {
    //       SetloadingStatus(false);
    //       SetSectionListing(data.data_list);
    //     } else Notify(true, Trans(message, language));
    //   })

    //   .catch((error) => {
    //     Notify(true, Trans(error.message, language));
    //   });
  };

  useEffect(() => {
    let abortController = new AbortController();
    loadSettingData();
    // findListBanner(themeId);
    return () => abortController.abort();
  }, []);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  // handle change group name
  const [sectionListing, SetSectionListing] = useState([]);
  const [catName, SetCatName] = useState("");

  const [editableData, SetEditableData] = useState("");


  const [templateList, SetTemplateList] = useState([]);

  const getTemplateCodeListBYPageId = (template_page,ID) => {
    SetloadingStatus(true);
    let language_id ='';
    let temp_page ='';
     if(ID !== '' ){ 
      language_id = document.getElementById("lang_id").value;
      temp_page = document.getElementById("temp_page").value;
     }


    const filterData2 = {
      api_token: apiToken,
      template_id: themeId,
      template_page: temp_page,
      languages_id:language_id
    };

    POST(TemlateHtmlUrl, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {

          SetTemplateList(data.templateHtml);

        } else Notify(false, Trans(message, language));
        SetloadingStatus(false);
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

  useEffect(() => {
    document.title = "Template Code | WorkerMan";
    let abortController = new AbortController();
    getTemplateCodeListBYPageId("","");
    return () => abortController.abort(); //getAllData();
  }, []);


  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();
  const [typeData, SetTypeData] = useState("default");

  console.log(typeData);

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };

  //   const filterItem = () => {
  //     findListBanner(menuGroupId);
  //   };


  const viewFunction = (view_id, type) => {
    SetEditData(view_id);
    SetTypeData(type);
    SetViewModalShow(true);
  };
  const [viewModalShow, SetViewModalShow] = useState(false);
  const handleviewClose = () => SetViewModalShow(false);
  const [langList, SetlangList] = useState([]);



  const viewFun = (editId, type) => {
    viewFunction(editId, type);
  };


  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
    getValues
  } = useForm();



  const editorRef = useRef(null);

  function handleEditorDidMount(editor, monaco) {
    editorRef.current = editor;
  }

  function showValue() {
    alert(editorRef.current?.getValue());
  }


  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    formData.api_token = apiToken;
    formData.template_html = changeHtml;
    formData.template_id = themeId;

    POST(TemlateSettingHtmlUpdateUrl, formData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });
          //     props.handleModalClose();
          //    props.filterItem();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              console.log(message[key][0]);
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = Trans(message, language);
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [changeHtml, setChangeHtml] = useState();
  function handleEditorChange(value, event) {
    //console.log("here is the current model value:", value);
    setChangeHtml(value);
  }


  const ModuleLoad = () => {
    const filterData = {
      api_token: apiToken,
    };

    POST(TemlateSettingLangUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {

          SetlangList(data);

        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });

  };
  useEffect(() => {
    let abortController = new AbortController();
    ModuleLoad();
    return () => abortController.abort();
  }, []);

  console.log(langList);

  return (
    <Content>
      <CheckPermission PageAccess={PageEmailSetting} PageAction={PreView}>
        <React.Fragment>


          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
              <CheckPermission PageAccess={PageEmailSetting} PageAction={PreView}>
                <div className="card" id="custom-user-list">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans("TEMPLATE_CODE", language)}
                    </h6>

                    <div className="d-flex">

                      <div className="mx-3 mt-2">
                        <h6>  {Trans("TEMPLATE_PAGE", language)}  </h6>
                      </div>
                      <div className="mr-2">
                        <select
                          {...register("languages_id", {
                          })}
                          className="form-control"
                          id="lang_id"
                          onChange={(e) => getTemplateCodeListBYPageId(e.target.value,"lang_id")} >
                          <option value="">{Trans("SELECT_LANG", language)}</option>
                          {langList &&
                            langList.map((curr, idx) => (
                              <option value={curr.languages_id} key={idx}>
                                {curr.languages_name}
                              </option>
                            ))}

                        </select>
                      </div>{"  "}

                      <div className="">

                        <select
                          {...register("template_page", {

                          })}
                          defaultValue={1}
                          id="temp_page"
                          className="form-control"
                          onChange={(e) => getTemplateCodeListBYPageId(e.target.value,"temp_page")} >
                          <option value="1">
                            {Trans("Home", language)}
                          </option>
                          <option value="2">
                            {Trans("Listing", language)}
                          </option>

                        </select>
                      </div>
                    </div>
                  </div>



                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">

                      <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>


                        <React.Fragment>
                          {contentloadingStatus ? (
                            <Loading />
                          ) : (<React.Fragment>
                            <Col col={12}>
                              <Editor
                                height="80vh"
                                defaultLanguage="html"
                                defaultValue={templateList}
                                onMount={handleEditorDidMount}
                                onChange={handleEditorChange}

                              />
                            </Col>
                          </React.Fragment>
                          )}
                        </React.Fragment>
                        <Col col={4}>
                          <LoaderButton
                            formLoadStatus={formloadingStatus}
                            btnName={Trans("UPDATE", language)}
                            className="btn btn-sm btn-bg btn-block"
                          />
                        </Col>

                      </form>
                    </div>
                  )}
                </div>
              </CheckPermission>
            </div>
          </div>
        </React.Fragment>
      </CheckPermission>


    </Content>

  );
}

export default EmailTemplate;
