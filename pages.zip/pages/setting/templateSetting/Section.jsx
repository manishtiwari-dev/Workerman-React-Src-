import React from "react";
import WebsiteLink from "config/WebsiteLink";
import { Col, Row, Anchor } from "component/UIElement/UIElement";
import {
  BannerListUrl,
  TemplateSettingUrl,
  TemplateUrl,
  TemplateSettingStoreUrl,
} from "config";
import POST from "axios/post";
import Notify from "component/Notify";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import ModalImage from "react-modal-image-responsive";


function Section({ section, section_key, selectData, refreshItem }) {
  const { apiToken, language } = useSelector((state) => state.login);
  let active = "";
  const templateVal = selectData[`default_${section_key}`];
  if (section.section_option_key === templateVal) active = "active-theme";

  // handle choosen
  const changeTemplateTheme = (templateKey, templateValue) => {
    const filterData = {
      api_token: apiToken,
      template_key: templateKey,
      template_value: templateValue,
    };
    POST(TemplateSettingStoreUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        refreshItem();
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };


  return (
    <Col col={4} className= "mt-4">

<div className={`card theme-card ${active}`}>
      {active === "" && (
        <div className="card-header py-1 d-flex justify-content-between         align-items-center " style={{ background: "#e2e1e1a1" }}
        >
          <p className="text-center mb-0">
            <b>{Trans(section.section_option_name, language)}</b>
          </p>
          <div className="d-flex justify-content-between align-items-center">
            <button
              type="button"
              className="btn "
              onClick={() => {
                changeTemplateTheme(
                  `default_${section_key}`,
                  section.section_option_key
                );
              }}
            >
              <label className="custom-control custom-switch">
                <input
                  type="checkbox"
                  className="custom-control-input"
                  id={section.section_option_key}
                  checked={
                    active === "" ? "" : "checked"
                  }
                />
                <label
                  className="custom-control-label"
                  For={section.section_option_key}
                ></label>
              </label>
            </button>


          </div>

        </div>

      )}
      {active != "" ? (
        <div className="card-header py-1 d-flex justify-content-between   align-items-center " style={{ background: "#e2e1e1a1" }}>
          <p className="text-center mb-0">
            <b>{Trans(section.section_option_name, language)}</b>
          </p>
          <div className="d-flex justify-content-between align-items-center"></div>
          <button
            type="button"
            className="btn p-0 m-0 "
          >
            <label className="custom-control custom-switch">
              <input
                // onClick={(e) => {
                //   changeTemplateTheme(
                //     "active-theme",
                //     template?.template_key
                //   );
                // }}
                type="checkbox"
                className="custom-control-input"
                id="customSwitch1"
                disabled
                checked="checked"
              />
              <label
                className="custom-control-label"
                For="customSwitch1"
              ></label>
            </label>
          </button>


        </div>

      ) : (
        ""
      )}
      <div
        className="card-body"

      >
        {/* <p className="text-center">
                                      <b>{template.template_name}</b>
                                    </p> */}
        <div className="">
          <ModalImage
            small={section.image}
            large={section.image}
            alt={section.image}
            className="modalSectImage"
          />
        </div>
        <br />

        {/* <div className="text-center pd-10"></div> */}
      </div>

</div>


      {/* {active === "" && (
        <p className="text-center">
          <button
            type="button"
            className="btn btn-info"
            onClick={() => {
              changeTemplateTheme(
                `default_${section_key}`,
                section.section_option_key
              );
            }}
          >
            {Trans("CHOOSE_THEME", language)}
          </button>
        </p>
      )}
      <p className="text-center">

        <b>{Trans(section.section_option_name, language)}</b>
      </p> */}







      {/* 
      <img
        src={section.image}
        alt=""
        className="theme-card-body-a-img"
        srcSet={section?.image}
        height="100"
      /> */}
    </Col>
  );
}



export default Section;
