import React, { useEffect, useState } from "react";
import POST from "axios/post";
import { Row, Col ,TextArea,Radio} from "component/UIElement/UIElement";
import { useFormContext, useFieldArray } from "react-hook-form";
import { tempUploadFileUrl } from "config/index";
import { useSelector } from "react-redux";
import { useForm } from "react-hook-form";

import Notify from "component/Notify";
import { Trans } from "lang";
import Select from "react-select";
import { ErrorMessage } from "@hookform/error-message";


function SubcriberWebSetting({ fieldKey, HelperData, currKey }) {
  const { currency, language, country, timezone,dateformat,optiontype} = HelperData;
 //  const { currency, language, country, timezone,dateformat} = HelperData;
    
   const [optionType, SetOptionType] = useState("setting_options");
   console.log(optionType);
    
  
   
  


  const { apiToken, userType } = useSelector((state) => state.login);

  const methods = useFormContext();
 
  const { register, control, setValue } = methods;

  const {
   
    formState: { errors },
    
  } = useForm();



  // select condition
  const conditionData = [
    "web_default_language",
    "web_default_currency",
    "contact_country",
    "web_other_supported_currency",
    "web_other_supported_language",
    "time_zone",
    "date_format",
    
  ];
  const verifyKey = (key) => {
    return conditionData.includes(key);
  };

  
  // image show condition
const imageShowList = ["website_logo", "website_favicon", "preloader_image","newsletter_image"];

  const imageKey = (key) => {
    return imageShowList.includes(key);
  };

  // select with only status
  const statusCond = [
    "facebook_status",
    "google_status",
    "twitter_status",
    "linkedin_status",
    "guest_checkout",
    "show_preloader",
    "webreview_autoswitch",
    "newsletter_popup",
    "web_currency_symbol_position",
    "web_currency_decimal_point",
    "mail_mailer",
    "plan_buy_option",
    "plan_appointment",
    "plan_appointment_date",
    "plan_appointment_time",
    "plan_type",
    "plan_guest_checkout",
    "tax_type",
  ];
  
  const statusKey = (key) => {
    return statusCond.includes(key);
  };


  
  // handle logo and other file upload

 
  const [file, setFile] = useState(null);

  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return;

    var readers = new FileReader();
    readers.onload = function (e) {
      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="100" />`;
    };
    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);
    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        setValue(StoreID, response.data.data);
      })
      .catch((error) => {
        Notify(false, error.message);
      });
  };


                                         
                                

 const createSelectLabel = (data, selData = "") => {
  let labelData = [];
  let arrData = data.split(",");
  console.log("arrData", arrData);
  if (selData !== "") {
    for (let idx = 0; idx < selData.length; idx++) {
      const elVal = selData[idx]["value"];
      if (arrData.includes(elVal)) labelData.push(selData[idx]);
    }
  } else {
    for (let index = 0; index < arrData.length; index++) {
      labelData.push({
        label: arrData[index],
        value: arrData[index],
      });
    }
  }
  return labelData;
};

  const handleMultiSelectChange = (id, newValue, actionMeta) => {
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    setValue(id, listArr.join(","));
  };


  return (
    <React.Fragment>
      <Row>
        {fieldKey.map((item, idx) => {
          const imageName = `${item.setting_key}_image`;
          let optionValuesAry = '';
          if(item.setting_options != '' && item.setting_options != null && item.option_type == 'dropdown'){
            let optionString = item.setting_options;
            optionValuesAry = optionString.split(',');
          } else{
            optionValuesAry = '';
          }
          console.log(optionValuesAry);
        
        
          const defaultList = [];
        
          {
            optionValuesAry &&
              optionValuesAry.map((date, index) => {
               console.log(index);
                defaultList.push({
                  label: Trans(date, language),
                  value: index,
                });
              });
          }
        

          return (
            <React.Fragment key={idx}>
              {/* Subscriber */}
              {userType == "subscriber" && (
                <React.Fragment key={idx}>
                  <input
                    type="hidden"
                    {...register(`set_${currKey}.${idx}.setting_id`)}
                    defaultValue={item.setting_id}
                  />
                  <input
                    type="hidden"
                    {...register(`set_${currKey}.${idx}.setting_key`)}
                    defaultValue={item.setting_key}
                  />
                  {verifyKey(item.setting_key) ? (

                    <React.Fragment>
                      <Col col={6}>
                        <div className="form-group">
                          <label htmlFor="">
                            <b> {Trans(item.setting_name, language)} :</b>
                          </label>
                        
                             {/* currency list */}
                             {item.setting_key === "time_zone" && timezone && (
                            <React.Fragment>
                               <Select
                                  name={item.setting_value}
                                  options={timezone}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                   //  console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.value,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />
                          

                             {/* <select
                                {...register(
                                  `set_${currKey}.${idx}.setting_value`
                                )}
                                placeholder="Setting Value"
                                className="form-control"
                                defaultValue={item.setting_value}
                              >
                               
                                {timezone.map((data, idx) => {
                                  return (
                                    <option value={data.value} key={idx}>
                                      {data.label}
                                    </option>
                                  );
                                })}
                              </select> 
                               <input
                                type="hidden"
                                {...register(
                                  `set_${currKey}.${idx}.setting_key`
                                )}
                                defaultValue={item.setting_value}
                              /> */}
                            </React.Fragment>
                          )}
                          
                        


                               {/* currency list */}
                               {item.setting_key === "web_default_currency" && currency && (
                            <React.Fragment>

                                <Select
                                  name={item.setting_value}
                                  options={currency}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                   //  console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.value,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />


              
                               {/* <select
                                {...register(
                                  `set_${currKey}.${idx}.setting_value`
                                )}
                                placeholder="Setting Value"
                                className="form-control"
                                defaultValue={item.setting_value}
                              >
                               
                                {currency.map((data, idx) => {
                                  return (
                                    <option value={data.value} key={idx}>
                                      {data.label}
                                    </option>
                                  );
                                })}
                              </select>
                              <input
                                type="hidden"
                                {...register(
                                  `set_${currKey}.${idx}.setting_key`
                                )}
                                defaultValue={item.setting_value}
                              /> */}
                            </React.Fragment>
                          )}
                        

                          {/* currency list */}
                          {item.setting_key === "web_other_supported_currency" &&
                            currency && (
                              <React.Fragment>
                                <Select
                                  isMulti
                                  name={item.setting_value}
                                  options={currency}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                    handleMultiSelectChange(
                                      `set_${currKey}.${idx}.setting_value`,
                                      newValue,
                                      actionMeta
                                    );
                                  }}
                                  defaultValue={createSelectLabel(
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`
                                  )}
                                  defaultValue={item.setting_value}
                                />
                              </React.Fragment>
                            )}

                          {item.setting_key === "web_other_supported_language" &&
                            currency && (
                              <React.Fragment>
                                <Select
                                  isMulti
                                  name={item.setting_value}
                                  options={language}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                    handleMultiSelectChange(
                                      `set_${currKey}.${idx}.setting_value`,
                                      newValue,
                                      actionMeta
                                    );
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />
                          
                              </React.Fragment>
                            )}


                             


                          {/* language list */}
                          {item.setting_key === "web_default_language" && language && (
                            <React.Fragment>

                                 <Select
                                  name={item.setting_value}
                                  options={language}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                   //  console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.value,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />

                               {/* <select
                                {...register(
                                  `set_${currKey}.${idx}.setting_value`
                                )}
                                placeholder="Setting Value"
                                className="form-control"
                                defaultValue={item.setting_value}
                              >
                               
                                {language.map((data, idx) => {
                                  return (
                                    <option value={data.value} key={idx}>
                                      {data.label}
                                    </option>
                                  );
                                })}
                              </select>
                              <input
                                type="hidden"
                                {...register(
                                  `set_${currKey}.${idx}.setting_key`
                                )}
                                defaultValue={item.setting_value}
                              /> */}
                            </React.Fragment>
                          )}

                              {/* open days */}
                              {/* {item.setting_key === "opening_days" && language && (
                            <React.Fragment>
                              <Select
                                isMulti
                                name={item.setting_value}
                    
                                className="basic-multi-select"
                                classNamePrefix="select"
                                onChange={(newValue, actionMeta) => {
                                  handleMultiSelectChange(
                                    `set_${currKey}.${idx}.setting_value`,
                                    newValue,
                                    actionMeta
                                  );
                                }}
                                defaultValue={createSelectLabel(
                                  item.setting_value,
                                  weekdays
                                )}
                                options={weekdays}/>
                        
                              <input
                                type="hidden"
                                {...register(
                                  `set_${currKey}.${idx}.setting_value`
                                )}
                                defaultValue={item.setting_value}
                              />
                            </React.Fragment>
                          )}  */}

                              {/* date_format  */}
                         {item.setting_key === "date_format" && dateformat && (
                            <React.Fragment>
                             
                                <Select
                                  name={item.setting_value}
                                  options={dateformat}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.value,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />
                          
                               {/* <select
                                {...register(
                                  `set_${currKey}.${idx}.setting_value`
                                )}
                                placeholder="Setting Value"
                                className="form-control"
                                defaultValue={item.setting_value}
                              >


                                {dateformat.map((data, idx) => {
                                  return (
                                    <option value={data.value} key={idx}>
                                      {data.label}
                                    </option>
                                  );
                                })}
                              </select> */}
                              {/* <input
                                type="hidden"
                                {...register(
                                  `set_${currKey}.${idx}.setting_key`
                                )}
                                defaultValue={item.setting_value}
                              /> */}
                            </React.Fragment>
                          )}
                          
                      
                          
                          {/* COUNTRY list */}
                          {item.setting_key === "contact_country" && country && (
                            <React.Fragment>

                           <Select
                                  name={item.setting_value}
                                  options={country}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.value,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />
                          
{/* 
                              <select
                                {...register(
                                  `set_${currKey}.${idx}.setting_value`
                                )}
                                placeholder="Setting Value"
                                className="form-control"
                                defaultValue={item.setting_value}
                              >
                                <option value="">{Trans("SELECT_COUNTRY", language)}</option>
                                {country.map((data, idx) => {
                                  return (
                                    <option value={data.value} key={idx}>
                                      {data.label}
                                    </option>
                                  );
                                })}
                              </select> */}
                            </React.Fragment>
                          )}
                        </div>
                      </Col>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      {statusKey(item.setting_key) ? (
                        <React.Fragment>
                          <Col col={6}>
                            <div className="form-group">
                              <label htmlFor="">
                                <b> {Trans(item.setting_name, language)} :</b>
                              </label>

                              {/* switch case i nreact */}
                              {(() => {
                                switch (item.setting_key) {
                                  case "date_format":
                                    return (
                                      <React.Fragment>
                                        <select
                                          {...register(
                                            `set_${currKey}.${idx}.
                                            `
                                          )}
                                          placeholder="Setting Value"
                                          className="form-control"
                                          defaultValue={item.setting_value}
                                        >
                                          <option value="">{Trans("SELECT", language)}</option>

                                          <option value="DD/MM/YYYY">
                                            DD/MM/YYYY
                                          </option>
                                          <option value="YYYY/MM/DD">
                                            YYYY/MM/DD
                                          </option>
                                          <option value="MM/DD/YYYY">
                                            MM/DD/YYYY
                                          </option>
                                        </select>
                                      </React.Fragment>
                                    );
                                  case "web_currency_decimal_point":
                                    return (
                                      <React.Fragment>
                                 <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />



                                        {/* <select
                                          {...register(
                                            `set_${currKey}.${idx}.setting_value`
                                          )}
                                          placeholder="Setting Value"
                                          className="form-control"
                                          defaultValue={item.setting_value}
                                        >
                                          <option value="">{Trans("SELECT", language)}</option>
                                          { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                            
                                        </select> */}
                                      </React.Fragment>
                                    );

                                
                            
                                    case "mail_mailer":
                                    return (
                                      <React.Fragment>
                               <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />


                                        {/* <select
                                          {...register(
                                            `set_${currKey}.${idx}.setting_value`
                                          )}
                                          placeholder="Setting Value"
                                          className="form-control"
                                          defaultValue={item.setting_value}
                                        >
                                          <option value="">{Trans("SELECT", language)}</option>
                                          { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                                   
                                  
                                        </select> */}
                                      </React.Fragment>
                                    );
                                    case "plan_buy_option":
                                      return (
                               <React.Fragment>
                                <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />

                                          {/* <select
                                            {...register(
                                              `set_${currKey}.${idx}.setting_value`
                                            )}
                                            placeholder="Setting Value"
                                            className="form-control"
                                            defaultValue={item.setting_value}
                                          >
                                            <option value="">{Trans("SELECT", language)}</option>
                                            { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                                     
                                    
                                          </select> */}

                                        </React.Fragment>
                                      );
                                      case "plan_appointment":
                                        return (
                                   <React.Fragment>
                              <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />

                                            {/* <select
                                              {...register(
                                                `set_${currKey}.${idx}.setting_value`
                                              )}
                                              placeholder="Setting Value"
                                              className="form-control"
                                              defaultValue={item.setting_value}
                                            >
                                              <option value="">{Trans("SELECT", language)}</option>
                                              { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                                       
                                      
                                            </select> */}
                                          </React.Fragment>
                                        );
                                        case "plan_appointment_date":
                                          return (
                                            <React.Fragment>
                               <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />

                                              {/* <select
                                                {...register(
                                                  `set_${currKey}.${idx}.setting_value`
                                                )}
                                                placeholder="Setting Value"
                                                className="form-control"
                                                defaultValue={item.setting_value}
                                              >
                                                <option value="">{Trans("SELECT", language)}</option>
                                                { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                                         
                                        
                                              </select> */}
                                            </React.Fragment>
                                          );
                                          case "plan_appointment_time":
                                            return (
                                   <React.Fragment>
                                 <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />

                                                {/* <select
                                                  {...register(
                                                    `set_${currKey}.${idx}.setting_value`
                                                  )}
                                                  placeholder="Setting Value"
                                                  className="form-control"
                                                  defaultValue={item.setting_value}
                                                >
                                                  <option value="">{Trans("SELECT", language)}</option>
                                                  { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                                           
                                          
                                                </select> */}
                                              </React.Fragment>
                                            );


                                            case "plan_type":
                                              return (
                                                <React.Fragment>
                             <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />

                                    {/* 
                                                  <select
                                                    {...register(
                                                      `set_${currKey}.${idx}.setting_value`
                                                    )}
                                                    placeholder="Setting Value"
                                                    className="form-control"
                                                    defaultValue={item.setting_value}
                                                  >
                                                    <option value="">{Trans("SELECT", language)}</option>
                                                    { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                                             
                                            
                                                  </select> */}
                                                </React.Fragment>
                                              );
                                              case "plan_guest_checkout":
                                                return (
                                    <React.Fragment>

                                <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />


                                            {/* 
                                                    <select
                                                      {...register(
                                                        `set_${currKey}.${idx}.setting_value`
                                                      )}
                                                      placeholder="Setting Value"
                                                      className="form-control"
                                                      defaultValue={item.setting_value}
                                                    >
                                                      <option value="">{Trans("SELECT", language)}</option>
                                                      { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                                               
                                              
                                                    </select> */}
                                                  </React.Fragment>
                                                );
                           case "web_currency_symbol_position":
                                    return (
                         <React.Fragment>

                              <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />


                                        {/* <select
                                          {...register(
                                            `set_${currKey}.${idx}.setting_value`
                                          )}
                                          placeholder="Setting Value"
                                          className="form-control"
                                          defaultValue={item.setting_value}
                                        >
                                          <option value=""> {Trans("SELECT", language)}</option>
                                          { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                                   
                                  
                                        </select>  */}
                                      </React.Fragment>
                                    );
                                   
                                 
                                  default:
                                  
                                 return (

                              <React.Fragment>
                                <Select
                                  name={item.setting_value}
                                  options={defaultList}
                                  className="basic-multi-select"
                                  classNamePrefix="select"
                                  onChange={(newValue, actionMeta) => {
                                     console.log(newValue);
                                    setValue(`set_${currKey}.${idx}.setting_value`, newValue.label,actionMeta);
                                  }}
                                  defaultValue={createSelectLabel (
                                    item.setting_value
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`,
                                
                                  )}
                                  defaultValue={item.setting_value}
                                />

                                        {/* <select
                                          {...register(
                                            `set_${currKey}.${idx}.setting_value`
                                          )}
                                          placeholder="Setting Value"
                                          className="form-control"
                                          id="selectNumber"
                                          defaultValue={item.setting_value}
                                        >
                                     <option value="">{Trans("SELECT", language)}</option>
                                     { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                        </select> */}
                                      </React.Fragment>
                                    );
                                
                                }
                                
                              })()}

                              {/* language list */}
                              {/* {item.setting_key === "date_format" ? (
                                
                              ) : (
                                
                              )} */}
                            </div>
                          </Col>
                        </React.Fragment>
                      ) : (
                        <Col col={6}>
                          <div className="form-group">
                            <label htmlFor="">
                              <b> {Trans(item.setting_name, language)} : </b>
                            </label>
                            {imageKey(item.setting_key) ? (

                              <React.Fragment>
                                <input
                                  type="hidden"
                                  {...register(
                                    `set_${currKey}.${idx}.setting_value`
                                  )}
                                  defaultValue={item.setting_value}
                                />

                                <div className="custom-file ">
                                  <input
                                    type="file"
                                    className="custom-file-input"
                                    id="customFile"
                                    onChange={(event) =>
                                      HandleDocumentUpload(
                                        event,
                                        `set_${currKey}.${idx}.fileupload`,
                                        `set_${currKey}.${idx}.setting_value`
                                      )
                                    }
                                  />
                                  <label
                                    className="custom-file-label"
                                    htmlFor="customFile"
                                  >
                                    {Trans("IMAGE", language)}
                                    {"  "}
                                  </label>

                                  <div id={`set_${currKey}.${idx}.fileupload`} className="mt-2">
                                    {item[imageName] !== "" && (
                                      <img
                                        src={item[imageName]}
                                        alt= {Trans("IMAGE", language)}
                                        height={50}
                                      
                                      />
                              )}


                             <div>
                             <span class="d-block tx-11 text-muted">{item.setting_hint}</span>
                            </div> 
                                  </div>
                                </div>
                              </React.Fragment>
           
                          ) : (
                              <React.Fragment>
                                {item.option_type === "textarea" ? (
                                  <React.Fragment>
                                    <TextArea
                                      {...register(
                                        `set_${currKey}.${idx}.setting_value`
                                      )}
                                      placeholder={Trans(
                                        item.setting_name,
                                        language
                                      )}
                                      className="form-control"
                                      defaultValue={item.setting_value}
                                    />
                                  </React.Fragment>
                                )
              
                            
                            : (
                              <input
                                {...register(
                                  `set_${currKey}.${idx}.setting_value`
                                )}
                                placeholder="Setting Value"
                                className="form-control"
                                defaultValue={item.setting_value}
                              />
                              )}
                              </React.Fragment>
                            )}

                          
                          </div>
                           
                        </Col>
                      )}
                    </React.Fragment>
                  )}
                </React.Fragment>
              )}

              {/* Administroot */}

              {userType == "administrator" && (
                <Col col={12} key={idx}>
                  <Row>
                    <input
                      type="hidden"
                      {...register(`set_${currKey}.${idx}.setting_id`)}
                      defaultValue={item.setting_id}
                    />
                    <Col col={6}>
                      <input
                        {...register(`set_${currKey}.${idx}.setting_key`)}
                        placeholder="Setting Key"
                        className="form-control"
                        defaultValue={item.setting_key}
                      />
                    </Col>
                    <Col col={6}>
                      <input
                        {...register(`set_${currKey}.${idx}.setting_name`)}
                        placeholder="Setting Name"
                        className="form-control"
                        defaultValue={item.setting_name}
                      />
                    </Col>
                  </Row>
                </Col>
              )}
            </React.Fragment>
          );
        })}
      </Row>
    </React.Fragment>
  );
}

export default SubcriberWebSetting;
