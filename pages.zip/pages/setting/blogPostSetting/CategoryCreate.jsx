import React, { useState, useEffect } from "react";
import POST from "axios/post";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useForm, FormProvider } from "react-hook-form";
import {
  PostCategoryStoreUrl,
  tempUploadFileUrl,
  PostCategoryCreateUrl,
  
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import MyEditor from "component/MyEditor";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
  Anchor,
  StatusSelect,
  TextArea,
  GalleryImagePreviewWithUpload,
} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import Select from "react-select";
import WebsiteLink from "config/WebsiteLink";

import FeatherIcon from "feather-icons-react";
import { useNavigate } from "react-router-dom";

const CategoryCreate = (props) => {
  const navigate = useNavigate();
  const { apiToken, language } = useSelector((state) => state.login);
  const [key, setKey] = useState("default_language");

  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [editName, SeteditName] = useState("");

  const methods = useForm({});

  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = methods;
  const [field, SetFeature] = useState([]);
  const [finallslug, setfinallslug] = useState("");

  const slugfun = () => {
    var a = document.getElementById("slug-source").value;
    var slugcreate = a
      .toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^\w-]+/g, "");

    setfinallslug(slugcreate);
  };

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    saveFormData.api_token = apiToken;
    var slug_page = document.getElementById("slug-target").value;

    saveFormData.category_slug = slug_page;
    // return "";

    POST(PostCategoryStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, data, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(true, errObj.msg);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };

  const [sectionListing, SetSectionListing] = useState([]);

  const ModuleLoad = () => {
    const filterData = {
      api_token: apiToken,
    };

    POST(PostCategoryCreateUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetSectionListing(data.parent_type);
           SetlangList(data.language);

        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    ModuleLoad();
    return () => abortController.abort();
  }, []);

  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return;

    var readers = new FileReader();
    readers.onload = function (e) {
      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="100" />`;
    };
    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);
    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        setValue(StoreID, response.data.data);
      })
      .catch((error) => {
        Notify(false, error.message);
      });
  };

  const [langList, SetlangList] = useState([]);
  const [categoryList, SetCategoryList] = useState([]);

  // useEffect(() => {
  //   let abortController = new AbortController();
  //   const formData = {
  //     api_token: apiToken,
  //     language: language,
  //   };
  //   POST(createSubCategoryUrl, formData)
  //     .then((response) => {
  //       const { status, data } = response.data;
  //       if (status) {
  //         SetlangList(data.language);
  //       } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
  //     })
  //     .catch((error) => {
  //       Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
  //       console.error("There was an error!", error);
  //     });
  //   return () => abortController.abort();
  // }, []);

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible>
          {error.msg}
        </Alert>
      )}
      <FormProvider {...methods}>
        <form
          action="#"
          onSubmit={handleSubmit(onSubmit)}
          noValidate>
          <Row>
            <Col col={12}>
              <FormGroup mb="20px">
                <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("PARENT_NAME", language)}>
                  {Trans("PARENT_NAME", language)}
                </Label>
                <select
                  id="Status"
                  label={Trans("STATUS", language)}
                  hint="Enter text" // for bottom hint
                  className="form-control form-control-sm"
                  {...register("parent_id", {
                    required: Trans("PARENT_NAME_REQUIRED", language),
                  })}>
                  <option value={0}>---</option>

                  {sectionListing &&
                    sectionListing?.map((curr, idx) => (
                      <option
                        value={curr.category_id}
                        key={idx}>
                        {curr.category_name}
                      </option>
                    ))}
                </select>
                <span className="required">
                  <ErrorMessage
                    errors={errors}
                    name="parent_id"
                  />
                </span>
              </FormGroup>
            </Col>
            <Col col={12}>
              <Tabs
                id="controlled-tab-example"
                onSelect={(k) => setKey(k)}
                className="mb-3">
                {langList &&
                  langList.map((lang) => {
                    const { languages_code, languages_id, languages_name } =
                      lang;
                    return (
                      <Tab
                        eventKey={languages_code}
                        key={languages_id}
                        title={languages_name}>
                        <Row>
                          <Col col={12}>
                            <FormGroup mb="20px">
                              <Input
                                id={`slug-source`}
                                label={`${Trans(
                                  "CATEGORY_NAME",
                                  language
                                )} (${languages_code})`}
                                placeholder={`${Trans(
                                  "CATEGORY_NAME",
                                  language
                                )} (${languages_code})`}
                                hint="Enter text" // for bottom hint
                                className="form-control"
                                {...register(`category_name_${languages_id}`)}
                                onKeyUp={() => {
                                  slugfun();
                                }}
                              />
                              {/* <span className="required">
                              <ErrorMessage
                                errors={errors}
                                name={`categories_name_${languages_id}`}
                              />
                            </span> */}
                            </FormGroup>
                          </Col>

                          <Col col={12}>
                            <FormGroup mb="20px">
                              <Label>
                                {`${Trans(
                                  "CATEGORY_DESCRIPTION",
                                  language
                                )} (${languages_code})`}
                              </Label>
                              <MyEditor
                                setKey={`category_description_${languages_id}`}
                                updateFun={(Key, Value) => {
                                  setValue(Key, Value);
                                }}
                              />
                              <textarea
                                {...register(
                                  `category_description_${languages_id}`
                                )}
                                style={{ display: "none" }}></textarea>
                            </FormGroup>
                          </Col>
                          <Col col={12}>
                            <FormGroup mb="20px">
                              <Input
                                id={`${Trans(
                                  "SEO_META_TITLE",
                                  language
                                )} (${languages_code})`}
                                label={`${Trans(
                                  "SEO_META_TITLE",
                                  language
                                )} (${languages_code})`}
                                placeholder={`${Trans(
                                  "SEO_META_TITLE",
                                  language
                                )} (${languages_code})`}
                                className="form-control"
                                {...register(`seometa_title_${languages_id}`)}
                              />
                            </FormGroup>
                          </Col>
                          <Col col={12}>
                            <FormGroup mb="20px">
                              <TextArea
                                id={`${Trans(
                                  "SEO_META_DESCRIPTION",
                                  language
                                )} (${languages_code})`}
                                label={`${Trans(
                                  "SEO_META_DESCRIPTION",
                                  language
                                )} (${languages_code})`}
                                placeholder={`${Trans(
                                  "SEO_META_DESCRIPTION",
                                  language
                                )} (${languages_code})`}
                                hint="Enter text" // for bottom hint
                                className="form-control"
                                {...register(`seometa_desc_${languages_id}`)}
                              />
                            </FormGroup>
                          </Col>
                        </Row>
                      </Tab>
                    );
                  })}
              </Tabs>
            </Col>
            <Col col={6}>
              <FormGroup mb="20px">
                <Input
                  id={`slug-target`}
                  label={`${Trans("SLUG", language)}`}
                  placeholder={`${Trans("SLUG", language)} `}
                  hint="Enter text" // for bottom hint
                  className="form-control"
                  {...register(`category_slug`)}
                  defaultValue={finallslug}
                />
              </FormGroup>
            </Col>
            <Col
              col={6}
              className="mb-10">
              <label>
                <b>{Trans("IMAGES")}</b>
              </label>
              <input
                type="hidden"
                {...register("image_id")}
              />
              <input
                placeholder="Setting Value"
                className="form-control"
                type="file"
                onChange={(event) =>
                  HandleDocumentUpload(event, `fileupload`, `image_id`)
                }
              />

              <div id={`fileupload`}></div>
            </Col>{" "}
            <br />
            <Col
              col={4}
              className="mt-2">
              <LoaderButton
                formLoadStatus={formloadingStatus}
                btnName={Trans("SUBMIT", language)}
                className="btn btn-sm btn-bg btn-block"
              />
            </Col>
            <br />
          </Row>
        </form>
      </FormProvider>
    </>
  );
};

export default CategoryCreate;
