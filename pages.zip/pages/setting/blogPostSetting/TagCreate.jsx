import React, { useState, useEffect } from "react";
import POST from "axios/post";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useForm, FormProvider } from "react-hook-form";
import { PostTagStoreUrl, PostTagCreateUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
  Anchor,
  TextArea,
  GalleryImagePreviewWithUpload,
} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import Select from "react-select";
import WebsiteLink from "config/WebsiteLink";
import MyEditor from "component/MyEditor";

import FeatherIcon from "feather-icons-react";
import { useNavigate } from "react-router-dom";

const TagCreate = (props) => {
  const navigate = useNavigate();
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [key, setKey] = useState("default_language");

  const methods = useForm({});

  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = methods;
  const [field, SetFeature] = useState([]);
  const [finallslug, setfinallslug] = useState("");

  const slugfun = () => {
    var a = document.getElementById("slug-source").value;
    var slugcreate = a
      .toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^\w-]+/g, "");

    setfinallslug(slugcreate);
  };
  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    var slug_page = document.getElementById("slug-target").value;
    saveFormData.tags_slug = slug_page;
    // return "";

    POST(PostTagStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, data, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(true, errObj.msg);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };

  const [langList, SetlangList] = useState([]);
  const [categoryList, SetCategoryList] = useState([]);

  useEffect(() => {
    let abortController = new AbortController();
    const formData = {
      api_token: apiToken,
      language: language,
    };
    POST(PostTagCreateUrl, formData)
      .then((response) => {
        const { status, data } = response.data;
        if (status) {
          SetlangList(data.language);
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
        console.error("There was an error!", error);
      });
    return () => abortController.abort();
  }, []);

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible>
          {error.msg}
        </Alert>
      )}
      <FormProvider {...methods}>
        <form
          action="#"
          onSubmit={handleSubmit(onSubmit)}
          noValidate>
          <Row>
            {/* <Col col={12}>
              <FormGroup>
                <Input
                  id={Trans("TAG_NAME", language)}
                  label={Trans("TAG_NAME", language)}
                  placeholder={Trans("TAG_NAME", language)}
                  className="form-control form-control-sm"
                  {...register("tags_name", {
                    required: Trans("TAG_NAME_REQUIRED", language),
                  })}
                />
                <span className="required">
                  <ErrorMessage
                    errors={errors}
                    name="tags_name"
                  />
                </span>
              </FormGroup>
            </Col> */}
            <Col col={12}>
              <Tabs
                id="controlled-tab-example"
                onSelect={(k) => setKey(k)}
                className="mb-3">
                {langList &&
                  langList.map((lang) => {
                    const { languages_code, languages_id, languages_name } =
                      lang;
                    return (
                      <Tab
                        eventKey={languages_code}
                        key={languages_id}
                        title={languages_name}>
                        <Row>
                          <Col col={12}>
                            <FormGroup mb="20px">
                              <Input
                                id={`slug-source`}
                                label={`${Trans(
                                  "TAG_NAME",
                                  language
                                )} (${languages_code})`}
                                placeholder={`${Trans(
                                  "TAG_NAME",
                                  language
                                )} (${languages_code})`}
                                hint="Enter text" // for bottom hint
                                className="form-control"
                                {...register(`tags_name_${languages_id}`)}
                                onKeyUp={() => {
                                  slugfun();
                                }}
                              />
                              {/* <span className="required">
                              <ErrorMessage
                                errors={errors}
                                name={`categories_name_${languages_id}`}
                              />
                            </span> */}
                            </FormGroup>
                          </Col>

                          <Col col={12}>
                            <FormGroup mb="20px">
                              <Label>
                                {`${Trans(
                                  "TAG_DESCRIPTION",
                                  language
                                )} (${languages_code})`}
                              </Label>
                              <MyEditor
                                setKey={`tags_description_${languages_id}`}
                                updateFun={(Key, Value) => {
                                  setValue(Key, Value);
                                }}
                              />
                              <textarea
                                {...register(
                                  `tags_description_${languages_id}`
                                )}
                                style={{ display: "none" }}></textarea>
                            </FormGroup>
                          </Col>
                          <Col col={12}>
                            <FormGroup mb="20px">
                              <Input
                                id={`${Trans(
                                  "SEO_META_TITLE",
                                  language
                                )} (${languages_code})`}
                                label={`${Trans(
                                  "SEO_META_TITLE",
                                  language
                                )} (${languages_code})`}
                                placeholder={`${Trans(
                                  "SEO_META_TITLE",
                                  language
                                )} (${languages_code})`}
                                className="form-control"
                                {...register(`seometa_title_${languages_id}`)}
                              />
                            </FormGroup>
                          </Col>
                          <Col col={12}>
                            <FormGroup mb="20px">
                              <TextArea
                                id={`${Trans(
                                  "SEO_META_DESCRIPTION",
                                  language
                                )} (${languages_code})`}
                                label={`${Trans(
                                  "SEO_META_DESCRIPTION",
                                  language
                                )} (${languages_code})`}
                                placeholder={`${Trans(
                                  "SEO_META_DESCRIPTION",
                                  language
                                )} (${languages_code})`}
                                hint="Enter text" // for bottom hint
                                className="form-control"
                                {...register(`seometa_desc_${languages_id}`)}
                              />
                            </FormGroup>
                          </Col>
                        </Row>
                      </Tab>
                    );
                  })}
              </Tabs>
            </Col>
            <Col col={12}>
              <FormGroup mb="20px">
                <Input
                  id={`slug-target`}
                  label={`${Trans("SLUG", language)}`}
                  placeholder={`${Trans("SLUG", language)} `}
                  hint="Enter text" // for bottom hint
                  className="form-control"
                  {...register(`tags_slug`)}
                  defaultValue={finallslug}
                />
              </FormGroup>
            </Col>

            <Col
              col={4}
              className="mt-2">
              <LoaderButton
                formLoadStatus={formloadingStatus}
                btnName={Trans("SUBMIT", language)}
                className="btn btn-sm btn-bg btn-block"
              />
            </Col>
            <br />
          </Row>
        </form>
      </FormProvider>
    </>
  );
};

export default TagCreate;
