import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { PageCategories, PreAdd, PreView } from "config/PermissionName";
import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { useForm } from "react-hook-form";
import { BlogPostSetting } from "config/WebsiteUrl";
import Loading from "component/Loading";

import {
  BlogPostUpdateUrl,
  BlogPostEditUrl,
  TitleSuffix,
  tempUploadFileUrl,
} from "config/index";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  StatusSelect,
  TextArea,
  Label,
} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
import { ErrorMessage } from "@hookform/error-message";
import { useParams } from "react-router-dom";
import ContentEditor from "component/ContentEditor";
import { useNavigate } from "react-router-dom";
import Select from "react-select";

const Edit = () => {
  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const { postId } = useParams();
  const navigate = useNavigate();

  const [key, setKey] = useState("default_language");
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    saveFormData.category_id = MultiSelectCategoryItem;
    //  saveFormData.tags_id = MultiSelectTagItem;


    POST(BlogPostUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          Notify(true, Trans(message, language));
          if (userType === "subscriber") {
            navigate(`/blog-setting`);
          }
          else {
            navigate("/superadmin/blog-setting");
          }

        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(false, errObj.msg);

        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };

  const [langList, SetlangList] = useState([]);

  // input field value set
  const [tempEditorValue, SettempEditorValue] = useState("");

  const [metaEditorValue, SetmetaEditorValue] = useState("");
  const [metaDescEditorValue, SetmetaDescEditorValue] = useState("");

  const [editInfo, SeteditInfo] = useState("");
  const [Showactiveat, Setactiveat] = useState();
  const [catList, SetCatList] = useState([]);

  const [MultiSelectCategoryItem, SetMultiSelectCategoryItem] = useState([]);
  const [MultiSelectTagItem, SetMultiSelectTagItem] = useState([]);

  const handleMultiSelectChange = (newValue, actionMeta) => {
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    SetMultiSelectCategoryItem(listArr);
  };

  // console.log(MultiSelectTagItem);

  const [MultiSelectSupplierItem, SetMultiSelectSupplierItem] = useState("");
  const handleMultiSelectSupplierChange = (newValue, actionMeta) => {
    // alert("sdf");
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    SetMultiSelectSupplierItem(listArr);
  };







  const [selectedCategory, SetSelectedCategory] = useState();
  const [tagList, SetTagList] = useState([]);
  const [selectedtagList, SetSelectedTagList] = useState([]);
  const [authorList, SetauthorList] = useState([]);
  const [editLoad, SeteditLoad] = useState(false);
  const [editName, SeteditName] = useState("");

  const [webfunctionSelected, SetwebfunctionSelected] = useState();
  const [selectedAuthorList, SetselectedAuthorList] = useState("");


  const setValueToField = () => {
    const editInfo = {
      api_token: apiToken,
      post_id: postId,
    };

    POST(BlogPostEditUrl, editInfo)
      .then((response) => {
        SetloadingStatus(false);

        const { data } = response.data;
        SeteditInfo(data.data_list);
        SetlangList(data.language);
        SetCatList(data.postCategory);
        SetTagList(data.postTag);
        SetauthorList(data.postAuthor);
        SettempEditorValue(data.data_list.img);
        const fieldList = getValues();
        for (const key in fieldList) {
          if (key === "created_at") {
            setValue(key, data.data_list[key].split(" ")[0]);
          } else {
            setValue(key, data.data_list[key]);
          }
        }


        SetSelectedCategory(data.data_list.selected_category);
        SetSelectedTagList(data.data_list.selected_tag);
        SetselectedAuthorList(data.data_list.selectedAuthor);


        let listArr = [];
        if (data?.data_list.selected_category?.length > 0) {
          for (
            let index = 0;
            index < data?.data_list.selected_category.length;
            index++
          ) {
            listArr[index] = data?.data_list.selected_category[index].value;
          }
        }

        SetMultiSelectCategoryItem(listArr);

        let post_title = '';
        // convert all array to object
        const { description_details } = data.data_list;
        if (description_details.length > 0) {
          for (let index = 0; index < description_details.length; index++) {
            for (const key in description_details[index]) {
              const keyName =
                key + "_" + description_details[index]["languages_id"];
              const KeyValue = description_details[index][key];

              setValue(keyName, KeyValue);
            }

            post_title = description_details[index].post_title;

            if (description_details[index].seo !== null) {
              setValue(
                "seometa_title_" + description_details[index]["languages_id"],
                description_details[index].seo.seometa_title
              );

              setValue(
                "seometa_desc_" + description_details[index]["languages_id"],
                description_details[index].seo.seometa_desc
              );
            }

            setValue(
              "post_title_" + description_details[index]["languages_id"],
              post_title
            );
            SeteditName(post_title);

            SettempEditorValue(description_details);
            setValue(
              "post_content_" + description_details[index]["languages_id"],
              description_details[index].post_content
            );
            console.log(
              "post_content_" + description_details[index]["languages_id"],
              description_details[index].post_content
            );
          }
        }

        //post tag selected item show
        const post_tags = data.data_list.selected_tag;
        let selectedTagFunc = [];
        let listTagFunc = [];
        if (post_tags.length > 0) {
          for (let index = 0; index < post_tags.length; index++) {
            selectedTagFunc.push({
              label: post_tags[index].tags_name,
              value: post_tags[index].tags_id,
            });
            listTagFunc[index] = post_tags[index].tags_id;
          }
        }
        SetwebfunctionSelected(selectedTagFunc);
        setValue("tags_id", listTagFunc.join(","));
        //  SetMultiSelectTagItem(listTagFunc)
        SeteditLoad(true);
      })

      .catch((error) => {
        SetloadingStatus(false);
        Notify(false, error.message);
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    setValueToField();
    return () => abortController.abort();
  }, []);

  const [tempFile, SettempFile] = useState("");


  const [updateformloadingStatus, SetupdateformloadingStatus] = useState(false);


  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    SetupdateformloadingStatus(true);

    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return;

    var readers = new FileReader();
    readers.onload = function (e) {
      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="100" />`;
    };
    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    // SetupdateformloadingStatus(false);

    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);
    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        SetupdateformloadingStatus(false);

        setValue(StoreID, response.data.data);
        //    SettempFile( response.data.data);
        // SetupdateformloadingStatus(false);


      })
      .catch((error) => {
        SetupdateformloadingStatus(false);

        Notify(false, error.message);
      });
  };

  const [edit, setedit] = useState("");
  const [titleedit, setTitleedit] = useState("");
  const [Descedit, setDescedit] = useState("");

  const handleChangetypeactiveat = (event) => {
    Setactiveat(event.target.value);
  };

  const myfun = () => {
    var a = document.getElementById("slug-source").value;
    var b = a
      .toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^\w-]+/g, "");
    document.getElementById("slug-target").value = b;
  };

  useEffect(() => {
    document.title = (`${editName}`) + (`${TitleSuffix}`);
    let abortController = new AbortController();

    return () => abortController.abort();
  }, [editLoad]);



  return (
    <Content>
      <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
          <div
            className="card"
            id="custom-user-list">
            <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
              <h6 className=" tx-semibold mg-b-0">
                {Trans("EDIT_POST", language)}
              </h6>
              <div className=" d-md-flex">
                <Anchor
                  className="btn btn-sm btn-bg pd-3"
                  path={WebsiteLink(BlogPostSetting)}>
                  <FeatherIcon
                    icon="corner-down-left"
                    className="wd-10 mg-r-5"
                  />
                  {Trans("GO_BACK", language)}
                </Anchor>
              </div>
            </div>
            <div className="card-body">
              <div className="row col-md-12">
                {error.status && (
                  <Alert
                    variant={error.type}
                    onClose={() =>
                      setError({ status: false, msg: "", type: "" })
                    }
                    dismissible>
                    {error.msg}
                  </Alert>
                )}
                <form
                  action="#"
                  onSubmit={handleSubmit(onSubmit)}
                  noValidate>
                  <input
                    type="hidden"
                    {...register("post_id")}
                  />


                  <Col col={12}>
                    <fieldset className="form-fieldset">
                      <legend>
                        {Trans("BLOG_INFORMATION", language)}
                      </legend>
                      <Row>


                        <Col col={12}>
                          <Tabs
                            id="controlled-tab-example"
                            onSelect={(k) => setKey(k)}
                            className="mb-3">
                            {langList &&
                              langList.map((lang, index) => {
                                const {
                                  languages_code,
                                  languages_id,
                                  languages_name,
                                } = lang;
                                return (
                                  <Tab
                                    eventKey={languages_code}
                                    key={languages_id}
                                    title={languages_name}>
                                    <Row>
                                      <Col col={12}>
                                        <FormGroup mb="20px">
                                          <Input
                                            id={`slug-source`}
                                            label={`${Trans(
                                              "POST_TITLE",
                                              language
                                            )} (${languages_code})`}
                                            placeholder={`${Trans(
                                              "POST_TITLE",
                                              language
                                            )} (${languages_code})`}
                                            hint="Enter text" // for bottom hint
                                            className="form-control"
                                            {...register(
                                              `post_title_${languages_id}`
                                            )}
                                            onKeyUp={() => {
                                              myfun();
                                            }}
                                          />
                                        </FormGroup>
                                      </Col>

                                      {/* <Col col={6}>
                                    <FormGroup mb="20px">
                                      <Input
                                        id={`slug-target`}
                                        label={`${Trans(
                                          "POST_SLUG",
                                          language
                                        )}`}
                                        placeholder={`${Trans(
                                          "POST_SLUG",
                                          language
                                        )} (${languages_code})`}
                                        hint="Enter text" // for bottom hint
                                        className="form-control"
                                        {...register(`slug`, {})}
                                      />
                                    </FormGroup>
                                  </Col> */}

                                      <Col col={12}>
                                        <FormGroup>
                                          <Label>
                                            {`${Trans(
                                              "POSTS_CONTENT",
                                              language
                                            )} (${languages_code})`}
                                          </Label>
                                          {/* <MyEditor
                                        setKey={`post_content_${languages_id}`}
                                        setVal={
                                          getValues(
                                            `post_content_${languages_id}`
                                          ) === undefined
                                            ? "<p></p>"
                                            : getValues(
                                                `post_content_${languages_id}`
                                              )
                                        }
                                        updateFun={(Key, Value) => {
                                          setValue(Key, Value);
                                        }}
                                      />
                                      <textarea
                                        {...register(
                                          `post_content_${languages_id}`
                                        )}
                                        style={{ display: "none" }}></textarea> */}

                                          <ContentEditor
                                            className="Editor"
                                            initialValue={

                                              getValues(
                                                `post_content_${languages_id}`
                                              ) === null
                                                ? "<p></p>"
                                                : getValues(
                                                  `post_content_${languages_id}`
                                                )

                                              // getValues(
                                              //   `pages_content_${languages_id}`
                                              // )

                                            }
                                            setKey={`post_content_${languages_id}`}

                                            updateFun={(Key, Value) => {
                                              setValue(Key, Value);
                                            }}
                                          />

                                          <textarea
                                            {...register(
                                              `post_content_${languages_id}`
                                            )}
                                            style={{ display: "none" }}
                                          ></textarea>

                                        </FormGroup>
                                      </Col>

                                      <Col col={12}>
                                        <FormGroup mb="20px">
                                          <Input
                                            id={`${Trans(
                                              "POST_EXCERPT",
                                              language
                                            )} (${languages_code})`}
                                            label={`${Trans(
                                              "POST_EXCERPT",
                                              language
                                            )} (${languages_code})`}
                                            placeholder={`${Trans(
                                              "POST_EXCERPT",
                                              language
                                            )} (${languages_code})`}
                                            className="form-control"
                                            {...register(
                                              `post_excerpt_${languages_id}`
                                            )}
                                          />
                                        </FormGroup>
                                      </Col>
                                      <Col col={12}>
                                        <FormGroup mb="20px">
                                          <Input
                                            id={`${Trans(
                                              "SEO_META_TITLE",
                                              language
                                            )} (${languages_code})`}
                                            label={`${Trans(
                                              "SEO_META_TITLE",
                                              language
                                            )} (${languages_code})`}
                                            placeholder={`${Trans(
                                              "SEO_META_TITLE",
                                              language
                                            )} (${languages_code})`}
                                            className="form-control"
                                            {...register(
                                              `seometa_title_${languages_id}`
                                            )}
                                          />
                                        </FormGroup>
                                      </Col>
                                      <Col col={12}>
                                        <FormGroup mb="20px">
                                          <TextArea
                                            id={`${Trans(
                                              "SEO_META_DESCRIPTION",
                                              language
                                            )} (${languages_code})`}
                                            label={`${Trans(
                                              "SEO_META_DESCRIPTION",
                                              language
                                            )} (${languages_code})`}
                                            placeholder={`${Trans(
                                              "SEO_META_DESCRIPTION",
                                              language
                                            )} (${languages_code})`}
                                            hint="Enter text" // for bottom hint
                                            className="form-control"
                                            {...register(
                                              `seometa_desc_${languages_id}`
                                            )}
                                          />
                                        </FormGroup>
                                      </Col>
                                    </Row>
                                  </Tab>
                                );
                              })}
                          </Tabs>
                        </Col>

                      </Row>
                    </fieldset>
                  </Col>

                  <Col col={12}>
                    <fieldset className="form-fieldset">
                      <legend>
                        {Trans("OTHER_INFORMATION", language)}
                      </legend>
                      <Row>


                        <Col
                          col={6}
                          className="mb-10">
                          <label>
                            <b>
                              {Trans("BANNER_IMAGES")}{" "}
                              <span className="error">*</span>{" "}
                            </b>
                          </label>
                          <input
                            type="hidden"
                            {...register("banner_image", {
                              required: Trans("POST_IMAGE_REQUIRED", language),
                            })}
                          />
                          <input
                            placeholder="Setting Value"
                            className="form-control"
                            type="file"
                            onChange={(event) =>
                              HandleDocumentUpload(
                                event,
                                `fileupload`,
                                `banner_image`
                              )
                            }
                          />

                          <div id={"fileupload"}>
                            <img
                              src={editInfo?.banner_image_url}
                              height="100"
                            />
                          </div>
                          <span className="required">
                            <ErrorMessage
                              errors={errors}
                              name="banner_image"
                            />
                          </span>
                        </Col>
                        <Col
                          col={6}
                          className="mb-10">
                          <label>
                            <b>
                              {Trans("THUMBNAILS_IMAGES")}{" "}
                              <span className="error">*</span>{" "}
                            </b>
                          </label>
                          <input
                            type="hidden"
                            {...register("thumbnail_image", {
                              required: Trans(
                                "THUMBLANE_IMAGES_REQUIRED",
                                language
                              ),
                            })}
                          />
                          <input
                            placeholder="Setting Value"
                            className="form-control"
                            type="file"
                            onChange={(event) =>
                              HandleDocumentUpload(
                                event,
                                `thumbfileupload`,
                                `thumbnail_image`
                              )
                            }
                          />

                          <div id={`thumbfileupload`}>
                            <img
                              src={editInfo?.thumbnail_image_url}
                              height="100"
                            />
                          </div>
                          <span className="required">
                            <ErrorMessage
                              errors={errors}
                              name="thumbnail_image"
                            />
                          </span>
                        </Col>{" "}
                        <br />


                        <Col col={6}>
                          <FormGroup mb="20px">
                            <Input
                              id={`slug-target`}
                              label={Trans("POST_SLUG", language)}
                              placeholder={Trans("POST_SLUG", language)}

                              hint="Enter text" // for bottom hint
                              className="form-control"
                              {...register(`slug`, {})}
                            />
                          </FormGroup>
                        </Col>

                        <Col col={6}>
                          <FormGroup mb="20px">
                            <Label
                              display="block"
                              mb="5px"
                              htmlFor={Trans("POST_CATEGORY", language)}>
                              {Trans("POST_CATEGORY", language)}
                            </Label>

                            {selectedCategory && (
                              <Select
                                isMulti
                                name={Trans("POST_CATEGORY", language)}
                                options={catList}
                                defaultValue={selectedCategory}
                                className="basic-multi-select"
                                classNamePrefix="select"
                                onChange={handleMultiSelectChange}
                              />
                            )}
                          </FormGroup>
                        </Col>
                        <Col col={6}>
                          <FormGroup mb="20px">
                            <Input
                              type="hidden"
                              id={Trans("POST_TAG", language)}
                              label={Trans("POST_TAG", language)}
                              placeholder={Trans("POST_TAG", language)}
                              className="form-control"
                              {...register("tags_id")}
                            />

                            {webfunctionSelected && (
                              <Select
                                isMulti
                                name={Trans("POST_TAG", language)}
                                defaultValue={webfunctionSelected}
                                options={tagList}
                                className="basic-multi-select"
                                classNamePrefix="select"
                                onChange={(newValue, actionMeta) => {
                                  let listArr = [];
                                  for (
                                    let index = 0;
                                    index < newValue.length;
                                    index++
                                  )
                                    listArr[index] = newValue[index].value;

                                  listArr = listArr.join(",");
                                  console.log("listArr", listArr);
                                  setValue("tags_id", listArr);
                                }}
                              />
                            )}

                            {/* <Select
                    isMulti
                    name={Trans("POST_TAG", language)}
                    options={tagList}
                    defaultValue={selectedtagList}
                    className="basic-multi-select"
                    classNamePrefix="select"
                   
                  /> */}
                          </FormGroup>
                        </Col>
                        <Col col={6}>
                          <FormGroup mb="20px">
                          <Label htmlFor="status">
                                  {Trans("STATUS", language)}
                                </Label>
                         <select
                                  {...register("status")}
                                  className="form-control"
                                  defaultValue={editInfo?.status}
                                >
                                  <option value="0">
                                    {Trans("DRAFT", language)}
                                  </option>
                                  <option value="1">
                                    {Trans("ACTIVE", language)}
                                  </option>
                                  <option value="2">
                                    {Trans("INACTIVE", language)}
                                  </option>
                                </select>











                          </FormGroup>
                        </Col>

                        <Col col={6}>
                          <FormGroup mb="20px">
                            <Input
                              type="hidden"
                              id={Trans("POST_AUTHOR", language)}
                              label={Trans("POST_AUTHOR", language)}
                              placeholder={Trans("POST_AUTHOR", language)}
                              className="form-control"
                              {...register("author_id")}
                            />
                            {selectedAuthorList && (
                              <Select
                                name={Trans("POST_AUTHOR", language)}
                                options={Trans(authorList, language)}
                                className="basic-multi-select"
                                classNamePrefix="select"
                                defaultValue={selectedAuthorList}
                                onChange={(newValue, actionMeta) => {
                                  // console.log(newValue);
                                  setValue("author_id", newValue.value);
                                }}
                              />
                            )}
                          </FormGroup>
                        </Col>
                        <Col col={6}>
                          <FormGroup mb="20px">
                            <Input
                              id={Trans("POST_DATE", language)}
                              label={Trans("POST_DATE", language)}
                              placeholder={Trans("POST_DATE", language)}
                              className="form-control"
                              {...register("created_at")}
                              type="date"
                              onChange={handleChangetypeactiveat}
                            />
                          </FormGroup>
                        </Col>


                        {
                          updateformloadingStatus ?
                            <>   <Col col={12}><b>Uploading...</b> </Col>
                            </>
                            :
                            <>
                              <Col
                                col={4}
                                style={{ marginTop: "10px" }}>
                                <LoaderButton
                                  formLoadStatus={formloadingStatus}
                                  btnName={Trans("UPDATE", language)}
                                  className="btn btn-sm btn-bg btn-block"
                                />
                              </Col>


                            </>
                        }









                      </Row>
                    </fieldset>
                  </Col>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Content>
  );
};

export default Edit;
