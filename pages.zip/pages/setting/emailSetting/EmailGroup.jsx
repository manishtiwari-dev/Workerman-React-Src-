import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { EmailGroupUrl, EmailGroupChangeStatusUrl ,EmailGroupSortOrderUrl} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import AddEmailGroup from "./AddEmailGroup";
import { Col, BadgeShow, Anchor ,IconButton} from "component/UIElement/UIElement";
import { useForm } from "react-hook-form";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { EmailSetting } from "config/WebsiteUrl";

import {
  PageEmailSetting,
  PreAdd,
  PreView,
  PreUpdate,
  SuperEmailTemplate
} from "config/PermissionName";

import EditeMailGroup from "./EditeMailGroup";
import WebsiteLink from "config/WebsiteLink";

function EmailGroup() {
  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");

  const [listData, SetlistData] = useState([]);
  const [HelperData, SetHelperData] = useState([]);

  const methods = useForm({
    defaultValues: {
      settingdata: [
        {
          banner_setting_id: 1,
          template_id: 1,
          refrence_id: "asdsad",
          banner_position_id: "",
          images_id: "",
          comment: 1,
        },
      ],
    },
  });

  const {
    register,
    control,
    formState: { errors },
    getValue,
    handleSubmit,
  } = methods;

  const loadSettingData = (sortBys, OrderBy) => {
    const filterData = {
      api_token: apiToken,
      sortBy: sortBys,
      orderBY: OrderBy,
    };
    POST(EmailGroupUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetSectionListing(data.data_list);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    
    document.title = "Email Setting | WorkerMan";
    let abortController = new AbortController();
    loadSettingData();
    return () => abortController.abort();
  }, []);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  useEffect(() => {}, [listData]);

  // handle change group name
  const [sectionListing, SetSectionListing] = useState([]);

  const changeStatus = (id) => {
    const filterData = {
      api_token: apiToken,
      group_id: id,
    };
    POST(EmailGroupChangeStatusUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        loadSettingData();
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };

  
  const UpdateOrderStatus = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      group_id: update_id,
      sort_order: sortOrder,
    };
    POST(EmailGroupSortOrderUrl, editData)
      .then((response) => {
        const { message } = response.data;
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };
  const page_access = userType  == 'subscriber' ? PageEmailSetting :  SuperEmailTemplate ;


  return (
    <Content>
      <CheckPermission  PageAccess={page_access} PageAction={PreView}>
        <>
         

          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
              <CheckPermission  PageAccess={page_access} PageAction={PreView}>
                <div className="card" id="custom-user-list">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans("EMAIL_GROUP_LIST", language)}
                    </h6>
                    <div className=" d-md-flex">
                    <CheckPermission
                    PageAccess={page_access}
                    PageAction={PreAdd}
                  >
                      {userType !== "subscriber" && (
                        <Button
                          variant=""
                          className="btn btn-sm btn-bg"
                          onClick={handleModalShow}
                        >
                          {Trans("ADD_EMAIL_GROUP", language)}
                        </Button>
                      )}
                        </CheckPermission>
                    </div>
                  </div>

                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Col col={12}>
                        <div className="table-responsive">
                          <table className="table">
                            <thead>
                              <tr>
                                <th>{Trans("SL_NO", language)}</th>
                                <th>{Trans("EMAIL_GROUP_NAME", language)}</th>
                                {userType !== "subscriber" && (
                                <th>{Trans("EMAIL_GROUP_KEY", language)}</th>
                                )}
                                {userType !== "subscriber" && (
                         <th>{Trans("EMAIL_GROUP_TYPE", language)}</th>
                     
                         )}
                      {userType !== "subscriber" && (
                         <th>{Trans("NO_OF_TEMPLATE", language)}</th>
                      )}
                                 {userType !== "subscriber" && (
                                <th>{Trans("SORT_ORDER", language)}</th>
                                )}
                               
                                <th className="text-center">
                                  {Trans("ACTION", language)}
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              {sectionListing &&
                                sectionListing.map((email, idx) => {
                                  return (
                                    <tr key={idx}>
                                      <td>{idx + 1}</td>
                                      <td>
                                      {Trans(email.group_name, language)}
                                       </td>
                                      {userType !== "subscriber" && (
                                      <td>{email.group_key}</td>
                                      )}
                                      {userType !== "subscriber" && (        
                           <td>{email.group_type}</td>
                           )}

                  {userType !== "subscriber" && (
                   <>
                     {email.templateCount === 0 ?   <td>{Trans("---", language)}</td> :
                           <td>{email.templateCount}</td>
                    }
                         </>  )}
                                     
                          {userType !== "subscriber" && (
                                       <td >   
                        <input
                            type="number"
                            name=""
                            id=""
                            defaultValue={email.sort_order}

                            style={{ width: "50px" , 'text-align':"center"}}                
                            onBlur={(e) => {
                              UpdateOrderStatus(
                                email.group_id,
                              e.target.value
                            );
                         }}
                         />
                  </td>
                  )}
                                 
                  <td className="text-center">
                         <Anchor
                               path={WebsiteLink(
                                `${EmailSetting}/${email?.group_id}`
                              )}
                              className="btn btn-primary btn-xs btn-icon"
                            >
                              <FeatherIcon icon="eye" />
                            </Anchor>
                            {"  "}

                              {userType !== "subscriber" && (
                                <CheckPermission
                                PageAccess={page_access}
                                PageAction={PreUpdate}
                                >        
                
                                  <IconButton
                                          color="primary"
                                        onClick={() =>
                                          editFunction(email?.group_id)
                                        }
                                        >
                                        <FeatherIcon
                                          icon="edit-2"
                                                                        
                                          fill="white"
                                              onClick={() =>
                                              editFunction(email?.group_id)
                                          }
                                        />
                                        </IconButton>
                                  </CheckPermission>
                                      )}
                                </td>
                                      </tr>
                                          );
                                        })}
                                          {sectionListing.length === 0 ? (
                                                      <tr>
                                  <td colSpan={6} className="text-center">
                                    {Trans("NO_RECORD_AVAILABLE", language)}
                                  </td>
                                </tr>
                              ) : null}
                            </tbody>
                          </table>
                        </div>
                      </Col>
                    </div>
                  )}
                </div>
              </CheckPermission>
            </div>
          </div>
        </>
      </CheckPermission>

      {/* add modal */}
      <Modal show={show} onHide={handleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_EMAIL_GROUP", language)}</Modal.Title>
          <Button variant="danger" onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <AddEmailGroup
            loadSettingData={loadSettingData}
            handleModalClose={handleModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit modal */}
      <Modal show={editModalShow} onHide={handleEditModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("UPDATE_EMAIL_GROUP", language)}</Modal.Title>
          <Button variant="danger" onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <EditeMailGroup
            editData={editData}
            loadSettingData={loadSettingData}
            handleModalClose={handleEditModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
    </Content>
  );
}

export default EmailGroup;
