import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import {
  EmailTemplateListUrl,
  MenuGroupUrl,
  EmailTemplateChangeStatusUrl,
  EmailTemplateDestroyUrl,
} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Create from "./Create";
import View from "./view";

import { Col, BadgeShow, IconButton } from "component/UIElement/UIElement";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { useParams } from "react-router-dom";
import { EmailSetting } from "config/WebsiteUrl";
import ModalAlert from "component/ModalAlert";

import {
  PageEmailSetting,
  PreAdd,
  PreView,
  PreUpdate,
  SuperEmailTemplate,
} from "config/PermissionName";

import Edit from "./Edit";
import WebsiteLink from "config/WebsiteLink";

function EmailTemplate() {
  const { menuGroupId } = useParams();

  const { apiToken, language, userType } = useSelector((state) => state.login);
  console.log(userType);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  // handle change group name
  const [sectionListing, SetSectionListing] = useState([]);
  const [catName, SetCatName] = useState("");

  const [editableData, SetEditableData] = useState("");

  const [templateList, SetTemplateList] = useState([]);

  const findListBanner = (id, sortBys, OrderBy) => {
    const filterData = {
      api_token: apiToken,
      group_id: id,
      sortBy: sortBys,
      orderBY: OrderBy,
    };
    POST(EmailTemplateListUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        console.log("Banner list", data);
        if (status) {
          SetloadingStatus(false);
          SetTemplateList(data.data_list);
          //   SetEditableData(data.data_list.editable);
          console.log(SetEditableData);
          SetCatName(data.group_name);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    //  loadSettingData();
    findListBanner(menuGroupId, sortByS, orderByS);
    return () => abortController.abort();
  }, []);

  const destroyItem = (id) => {
    const filterData = {
      api_token: apiToken,
      template_id: id,
    };
    POST(EmailTemplateDestroyUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(menuGroupId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const changeStatus = (id) => {
    const filterData = {
      api_token: apiToken,
      template_id: id,
    };
    POST(EmailTemplateChangeStatusUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(menuGroupId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();
  const [typeData, SetTypeData] = useState("default");

  console.log(typeData);

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };

  const filterItem = () => {
    findListBanner(menuGroupId);
  };

  const viewFunction = (view_id, type) => {
    SetEditData(view_id);
    SetTypeData(type);
    SetViewModalShow(true);
  };
  const [viewModalShow, SetViewModalShow] = useState(false);
  const handleviewClose = () => SetViewModalShow(false);

  const viewFun = (editId, type) => {
    viewFunction(editId, type);
  };

  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });
  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: destroyItem,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const page_access =
    userType == "subscriber" ? PageEmailSetting : SuperEmailTemplate;

  return (
    <Content>
      <CheckPermission
        PageAccess={page_access}
        PageAction={PreView}>
        <React.Fragment>
          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
              <CheckPermission
                PageAccess={page_access}
                PageAction={PreView}>
                <div
                  className="card"
                  id="custom-user-list">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans(catName, language)}
                    </h6>
                    <div className="d-md-flex">
                      <CheckPermission
                        PageAccess={page_access}
                        PageAction={PreAdd}>
                        <Button
                          variant=""
                          className="btn-sm btn-bg"
                          onClick={handleModalShow}>
                          <FeatherIcon
                            icon="plus"
                            // fill="white"
                            className="wd-10 mg-r-5"
                          />
                          {Trans("ADD_EMAIL_TEMPLATE", language)}
                        </Button>
                      </CheckPermission>
                    </div>
                  </div>

                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Col col={12}>
                        <div className="table-responsive">
                          <table className="table">
                            <thead>
                              <tr>
                                <th>{Trans("SL_NO", language)}</th>
                                <th>{Trans("template_subject", language)}</th>
                                <th>{Trans("LANGUAGE", language)}</th>
                                <th>{Trans("STATUS", language)}</th>
                                <th className="text-center">
                                  {Trans("ACTION", language)}
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              <>
                                {templateList &&
                                  templateList.map((template, idx) => {
                                    return (
                                      <tr key={idx}>
                                        <td>{idx + 1}</td>
                                        <td>{template.template_subject}</td>
                                        <td>
                                          {template?.lang_list.languages_name}
                                        </td>

                                        <td>
                                          <BadgeShow
                                            type={
                                              template.status
                                                ? "active"
                                                : "deactive"
                                            }
                                            content={
                                              template.status
                                                ? "active"
                                                : "deactive"
                                            }
                                          />{" "}
                                        </td>
                                        <td className="text-center">
                                          {template.editable === 0 && (
                                            <IconButton
                                              color="primary"
                                              onClick={() =>
                                                viewFun(
                                                  template?.template_id,
                                                  "default"
                                                )
                                              }>
                                              <FeatherIcon
                                                icon="eye"
                                                size={20}
                                                onClick={() =>
                                                  viewFun(
                                                    template?.template_id,
                                                    "default"
                                                  )
                                                }
                                              />
                                            </IconButton>
                                          )}
                                          {template.editable === 1 && (
                                            <IconButton
                                              color="primary"
                                              onClick={() =>
                                                viewFun(
                                                  template?.template_id,
                                                  ""
                                                )
                                              }>
                                              <FeatherIcon
                                                icon="eye"
                                                size={20}
                                                onClick={() =>
                                                  viewFun(
                                                    template?.template_id,
                                                    ""
                                                  )
                                                }
                                              />
                                            </IconButton>
                                          )}
                                          {/* <IconButton
                                  color="primary"
                                  onClick={() => viewFun(template?.template_id)}

                            >
                              <FeatherIcon
                                icon="eye"
                                size={20}
                                onClick={() => viewFun(template?.template_id)}
                              />
                            </IconButton>{" "} */}
                                          {template.editable === 1 && (
                                            <CheckPermission
                                              PageAccess={page_access}
                                              PageAction={PreUpdate}>
                                              <IconButton
                                                color="primary"
                                                onClick={() =>
                                                  editFunction(
                                                    template?.template_id
                                                  )
                                                }>
                                                <FeatherIcon
                                                  icon="edit-2"
                                                  fill="white"
                                                  onClick={() =>
                                                    editFunction(
                                                      template?.template_id
                                                    )
                                                  }
                                                />
                                              </IconButton>
                                            </CheckPermission>
                                          )}{" "}
                                          {"  "}
                                          {template.editable === 1 && (
                                            <IconButton
                                              color="primary"
                                              onClick={() =>
                                                changeStatus(
                                                  template?.template_id
                                                )
                                              }>
                                              <FeatherIcon
                                                icon="repeat"
                                                fill="white"
                                                onClick={() =>
                                                  changeStatus(
                                                    template?.template_id
                                                  )
                                                }
                                              />
                                            </IconButton>
                                          )}
                                          {"  "}
                                          {template.editable === 1 && (
                                            <IconButton
                                              color="primary"
                                              onClick={() =>
                                                deleteItem(
                                                  template?.template_id
                                                )
                                              }>
                                              <FeatherIcon
                                                icon="x-square"
                                                color="white"
                                                onClick={() =>
                                                  deleteItem(
                                                    template?.template_id
                                                  )
                                                }
                                              />
                                            </IconButton>
                                          )}
                                        </td>
                                      </tr>
                                    );
                                  })}
                              </>

                              {templateList.length === 0 ? (
                                <tr>
                                  <td
                                    colSpan={6}
                                    className="text-center">
                                    {Trans("NO_RECORD_AVAILABLE", language)}
                                  </td>
                                </tr>
                              ) : null}
                            </tbody>
                          </table>
                        </div>
                      </Col>
                    </div>
                  )}
                </div>
              </CheckPermission>
            </div>
          </div>
        </React.Fragment>
      </CheckPermission>

      {/* add modal */}
      <Modal
        show={show}
        onHide={handleModalClose}
        size="xl">
        <Modal.Header>
          <Modal.Title>{Trans("ADD_EMAIL_TEMPLATE", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create
            handleModalClose={handleModalClose}
            filterItem={filterItem}
            groupId={menuGroupId}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit modal */}
      <Modal
        show={editModalShow}
        onHide={handleEditModalClose}
        size="xl">
        <Modal.Header>
          <Modal.Title>{Trans("UPDATE_EMAIL_TEMPLATE", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Edit
            editData={editData}
            filterItem={filterItem}
            handleModalClose={handleEditModalClose}
            groupId={menuGroupId}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
      <Modal
        show={viewModalShow}
        onHide={handleviewClose}
        size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("EMAIL_TEMPLATE_INFO", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleviewClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <View
            editData={editData}
            typeData={typeData}
            filterItem={filterItem}
            menuGroupId={menuGroupId}
            handleModalClose={handleviewClose}
          />
        </Modal.Body>
      </Modal>

      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </Content>
  );
}

export default EmailTemplate;
