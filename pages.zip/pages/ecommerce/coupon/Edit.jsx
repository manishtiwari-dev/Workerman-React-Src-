import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm, FormProvider } from "react-hook-form";
import {
  leadUpdateUrl,
  leadEditUrl,
  leadCreateUrl,
  couponeditUrl,
  couponupdateUrl,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
  StatusSelect
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message";

const Edit = (props) => {
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const [contactFill, SetContactFill] = useState([
    { contact_name: "", contact_email: "" },
  ]);

  const [socialLinkFill, SetSocialLinkFill] = useState([
    { social_type: "", social_link: "" },
  ]);

  const methods = useForm();

  const [ShowType, SetType] = useState();
  const [Showfirst_time, Setfirst_time] = useState();
  const [ShowGuestCheckout, SetGuestCheckout] = useState();

  const [Showmultiple_show, Setmultiple_show] = useState();
  const [Showexpiryat, Setexpiryat] = useState();
  const [Showactiveat, Setactiveat] = useState();
  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = methods;

  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const { editData, source, industry, status, agent, country } = props;

  const onSubmit = (formData) => {
    // SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(couponupdateUrl, saveFormData)
      .then((response) => {
        // SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }

        SetformloadingStatus(false);
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [selectedstartdate, Setselectedstartdate] = useState("");
  const [selectedIndustry, SetSelectedIndustry] = useState("");
  const [selectedStatus, SetSelectedStatus] = useState("");
  const [selectedAgent, SetSelectedAgent] = useState("");
  const [selectedCountry, SetSelectedCountry] = useState("");

  const [selectedData, SetSelectedData] = useState([]);

  function setValueToField() {
    const editInfo = {
      api_token: apiToken,
      coupon_id: editData,
    };
    POST(couponeditUrl, editInfo)
      .then((response) => {
        SetloadingStatus(false);
        SetSelectedData(response.data);
        const { data } = response.data;
        const fieldList = getValues();
        for (const key in fieldList) {
          if (key === "discount_type") {
            SetType(data[key]);
          } else if (key === "first_purchase_only") {
            Setfirst_time(data[key]);
          }
          else if (key === "guest_checkout") {
            SetGuestCheckout(data[key]);
          }

          else if (key === "multiple_use") {
            Setmultiple_show(data[key]);

          } else if (key === "expire_at") {
            setValue(key, data[key].split(" ")[0]);
          } else if (key === "active_at") {
            setValue(key, data[key].split(" ")[0]);
          } else {
            setValue(key, data[key]);
          }
        }
      })
      .catch((error) => {
        SetloadingStatus(false);
        alert(error.message);
      });
  }
  useEffect(() => {
    setValueToField();
    return () => {
      setValueToField();
    };
  }, []);



  const handleChange = (event) => {
    SetType(event.target.value);
  };
  const handleChangemultiple_show = (event) => {
    Setmultiple_show(event.target.value);
  };
  const handleChangefirst_time = (event) => {
    Setfirst_time(event.target.value);
  };
  const handleChangetypeexpiryat = (event) => {
    Setexpiryat(event.target.value);
  };
  const handleChangetypeactiveat = (event) => {
    Setactiveat(event.target.value);
  };

  const handleChangeGuestCheckout = (event) => {
    SetGuestCheckout(event.target.value);
  };

  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible
            >
              {error.msg}
            </Alert>
          )}

          <FormProvider {...methods}>
            <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
              {" "}
              <input type="hidden" value="" {...register("coupon_id")} />
              <Row>
                <Col col={6}>
                  <FormGroup mb="20px">
                    <Input
                      id={Trans("COUPON_NAME", language)}
                      label={Trans("COUPON_NAME", language)}
                      placeholder={Trans("COUPON_NAME", language)}
                      className="form-control"
                      {...register("coupon_name", {
                        required: Trans("COUPON_NAME_REQUIRED", language),
                      })}
                    />
                    <span className="required">
                      <ErrorMessage errors={errors} name="coupon_name" />
                    </span>
                  </FormGroup>
                </Col>

                <Col col={6}>
                  <FormGroup mb="20px">
                    <Input
                      id={Trans("COUPON_CODE", language)}
                      label={Trans("COUPON_CODE", language)}
                      placeholder={Trans("COUPON_CODE", language)}
                      className="form-control"
                      {...register("coupon_code", {
                        required: Trans("COUPON_CODE_REQUIRED", language),
                      })}
                    />

                    <span className="required">
                      <ErrorMessage errors={errors} name="coupon_code" />
                    </span>
                  </FormGroup>
                </Col>

                <Col col={6}>
                  <FormGroup mb="20px">
                    <Label
                      display="block"
                      mb="5px"
                      htmlFor={Trans("TYPE", language)}
                    >
                      {Trans("DISCOUNT_TYPE", language)}
                    </Label>
                    <div className="d-flex">
                      <label htmlFor="price">
                        <input
                          type="radio"
                          id="price"
                          name="discount_type"
                          value={0}
                          checked={ShowType == 0}
                          onClick={handleChange}
                          {...register("discount_type")}
                        />{" "}
                        &nbsp;
                        {Trans("PRICE", language)}
                      </label>{" "}
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <label htmlFor="percent">
                        {" "}
                        <input
                          type="radio"
                          id="percent"
                          name="discount_type"
                          value={1}
                          checked={ShowType == 1}
                          onClick={handleChange}
                          {...register("discount_type")}
                        />
                        &nbsp;
                        {Trans("PERCENT", language)}
                      </label>
                    </div>
                  </FormGroup>
                </Col>

                <Col col={6}>
                  <FormGroup mb="20px">
                    <Input
                      id={Trans("", language)}
                      label={Trans("LIMIT_PER_PERSON", language)}
                      placeholder={Trans("LIMIT_PER_PERSON", language)}
                      className="form-control"
                      defaultValue="1"
                      {...register("coupon_limit", {
                        required: Trans("LIMIT_REQUIRED", language),
                      })}
                      type="number"
                    />
                    <span className="required">
                      <ErrorMessage errors={errors} name="coupon_limit" />
                    </span>
                  </FormGroup>
                </Col>

                <Col col={6}>
                  <FormGroup mb="20px">
                    <Label
                      display="block"
                      mb="5px"
                      htmlFor={Trans("TYPE", language)}
                    >
                      {Trans("MULTIPLE_USE", language)}
                    </Label>
                    <div className="d-flex">
                      <label htmlFor="yes">
                        {" "}
                        <input
                          type="radio"
                          id="yes"
                          name="multiple_use"
                          value={1}
                          checked={Showmultiple_show == 1}
                          onClick={handleChangemultiple_show}
                          {...register("multiple_use")}
                        />
                        &nbsp;{Trans("YES", language)}
                      </label>{" "}
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <label htmlFor="no">
                        {" "}
                        <input
                          type="radio"
                          id="no"
                          name="multiple_use"
                          value={0}
                          checked={Showmultiple_show == 0}
                          onClick={handleChangemultiple_show}
                          {...register("multiple_use")}
                        />{" "}
                        &nbsp;{Trans("NO", language)}
                      </label>
                    </div>
                  </FormGroup>
                </Col>

                <Col col={6}>
                  <FormGroup mb="20px">
                    <Input
                      id={Trans("ACTIVE_AT", language)}
                      label={Trans("ACTIVE_AT", language)}
                      placeholder={Trans("ACTIVE_AT", language)}
                      className="form-control"
                      {...register("active_at")}
                      type="date"
                      onChange={handleChangetypeactiveat}
                    />
                  </FormGroup>
                </Col>
                <Col col={6}>
                  <FormGroup mb="20px">
                    <Input
                      id={Trans("VALID_UPTO", language)}
                      label={Trans("VALID_UPTO", language)}
                      className="form-control"
                      {...register("expire_at")}
                      type="date"
                      onChange={handleChangetypeexpiryat}
                    />
                  </FormGroup>
                </Col>

                <Col col={6}>
                  <FormGroup mb="20px">
                    <Input
                      id={Trans("MINIMUM_PURCHASE_AMT", language)}
                      label={Trans("MINIMUM_PURCHASE_AMT", language)}
                      placeholder={Trans("MINIMUM_PURCHASE_AMT", language)}
                      className="form-control"
                      {...register("minimum_purchase")}
                      type="text"
                    />
                  </FormGroup>
                </Col>

                <Col col={6}>
                  <FormGroup mb="20px">
                    <Input
                      id={Trans("MAXIMUM_DISCOUNT", language)}
                      label={Trans("MAXIMUM_DISCOUNT", language)}
                      placeholder={Trans("MAXIMUM_DISCOUNT", language)}
                      className="form-control"
                      {...register("maximum_discount")}
                      type="text"
                    />
                  </FormGroup>
                </Col>

                <Col col={6}>
                  <FormGroup mb="20px">
                    <Label
                      display="block"
                      mb="5px"
                      htmlFor={Trans("TYPE", language)}
                    >
                      {Trans("FIRST_TIME_PURCHASE_ONLY", language)}
                    </Label>
                    <div className="d-flex">
                      <label htmlFor="yess">
                        {" "}
                        <input
                          type="radio"
                          id="yess"
                          name="first_purchase_only"
                          value={1}
                          checked={Showfirst_time == 1}
                          onClick={handleChangefirst_time}
                          {...register("first_purchase_only")}
                        />{" "}
                        &nbsp;{Trans("YES", language)}
                      </label>{" "}
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <label htmlFor="noo">
                        {" "}
                        <input
                          type="radio"
                          id="noo"
                          name="first_purchase_only"
                          value={0}
                          checked={Showfirst_time == 0}
                          onClick={handleChangefirst_time}
                          {...register("first_purchase_only")}
                        />{" "}
                        &nbsp;{Trans("NO", language)}
                      </label>
                    </div>
                  </FormGroup>
                </Col>


                <Col col={6}>
                  <FormGroup mb="20px">
                    <Label display="block" mb="5px" htmlFor={Trans("TYPE", language)}>
                      {Trans("guest_checkout", language)}
                    </Label>
                    <div className="d-flex">
                      <label htmlFor="yess">
                        <input
                          type="radio"
                          id="yess"
                          name="guest_checkout"
                          value={1}
                          checked={ShowGuestCheckout == 1}
                          onClick={handleChangeGuestCheckout}
                          {...register("guest_checkout")}
                        />
                        &nbsp;
                        {Trans("YES", language)}
                      </label>{" "}
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <label htmlFor="noo">
                        <input
                          type="radio"
                          id="noo"
                          name="guest_checkout"
                          value={0}
                          checked={ShowGuestCheckout == 0}
                          onClick={handleChangeGuestCheckout}
                          {...register("guest_checkout")}
                        />
                        &nbsp;
                        {Trans("NO", language)}
                      </label>
                    </div>
                  </FormGroup>
                </Col>


                {/* <Col col={6}>
                  <FormGroup mb="20px" className="d-flex">
                    <Label
                      display="block"
                      mb="5px"
                      htmlFor={Trans("STATUS", language)}
                    >
                      {Trans("STATUS", language)}
                    </Label>

                    <div
                      className="custom-control custom-switch"
                      style={{ marginLeft: "20px" }}
                    >
                      <input
                        type="checkbox"
                        class="custom-control-input"
                        id={`customSwitchmodule`}
                        {...register("status")}
                      />
                      <label
                        className="custom-control-label"
                        For={`customSwitchmodule`}
                      ></label>
                    </div>
                  </FormGroup>
                </Col> */}
                <Col col={6} className="mb-1">
                  <FormGroup mb="20px">
                    <StatusSelect
                      id="Status"
                      label={Trans("STATUS", language)}
                      hint="Enter text" // for bottom hint
                      className="form-control"
                      {...register("status", {
                      })}
                    />

                  </FormGroup>
                </Col>



                <Col col={12}>
                  <LoaderButton
                    formLoadStatus={formloadingStatus}
                    btnName={Trans("SUBMIT", language)}
                    className="btn  btn-sm btn-bg btn-block"
                  />
                </Col>
              </Row>
            </form>
          </FormProvider>
        </>
      )}
    </>
  );
};

export default Edit;
