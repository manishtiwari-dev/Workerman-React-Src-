import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useFormContext } from "react-hook-form";
import { Card, Button } from "react-bootstrap";
import { useFieldArray } from "react-hook-form";
import { Trans } from "lang";
import { Row, Col, FormGroup, Label,Input } from "component/UIElement/UIElement";
import FeatherIcon from "feather-icons-react";
import { ErrorMessage } from "@hookform/error-message";
import Notify from "component/Notify";

function BulkPrice({calculateSellprice,}) {
  const { language } = useSelector((state) => state.login);
  const methods = useFormContext();

  const {
    register,
    control,
    setValue,
    getValues,
    
    formState: { errors },
  } = methods;


  const bulkPrice = useFieldArray({
    control,
    name: "bulkPrice",
  });

  const item_cost_calc = (index, type, price) => {

    let priceProduct = parseFloat(getValues(`bulkPrice.${index}.stock_price`));
    let percentage =getValues(`bulkPrice.${index}.profit_percent`);

    if (priceProduct === NaN || percentage === NaN) return false;
    

    let per = (percentage / 100) * priceProduct;

    let marketPrice =priceProduct +per;
    setValue(`bulkPrice.${index}.max_sale_price`, marketPrice);




       



     let discount = getValues(`bulkPrice.${index}.discount_percent`);

    // if (qty === "") qty = 0;
    if (priceProduct === "") priceProduct = 0;
     if (discount === "") discount = 0;

 
     


    let extrper = (discount / 100) * marketPrice;
      
     let finalCost = parseFloat(marketPrice) - parseFloat(extrper).toFixed(2);
     setValue(`bulkPrice.${index}.sale_price`, finalCost);


    // let unit_cost = parseFloat(
    //  parseFloat(marketPrice) - parseFloat(discount)
    // ).toFixed(2);
    // setValue(`bulkPrice.${index}.final_cost_show`, unit_cost);


  };

 



  return (
    <Col col={12}>
      <Card className="mb-3">
        <Card.Header as="h6">
          {Trans("WHOLESALE_PRICE", language)}
          <span style={{ float: "right" }}>
            <button
              type="button"
              className="btn btn-xs btn-dark"
              onClick={() => {
                bulkPrice.prepend({});
              }}
            >
              <FeatherIcon icon="plus" fill="white" />
              {Trans("ADD_MORE", language)}
            </button>
          </span>
        </Card.Header>
        <Row className="mt-4 pb-0">
           <Col col={2}>
              <h6 className="ml-3 text-center"> {Trans("QTY", language)}</h6>
            </Col>            
            <Col col={2}> 
            <h6 className=" text-center"> {Trans("INVENTORY_PRICE", language)}</h6>  
            </Col>
            <Col col={2}>
            <h6 className=" text-center"> {Trans("PROFIT_PERCENT", language)}</h6> 
           
            </Col>
            <Col col={2}>
            <h6 className=" text-center"> {Trans("MAX_SALE_PRICE", language)}</h6>      
            </Col>
            <Col col={2}>
            <h6 className=" text-center"> {Trans("DISCOUNT_PERCENT", language)}</h6> 
            </Col>
            <Col col={2}>
            <h6 className=" text-center"> {Trans("FINAL_SALE_PRICE", language)}</h6>        
            </Col>
          </Row>
        {bulkPrice.fields && (
          <Card.Body>
            {bulkPrice.fields.map((item, index) => {
              return (
                <Row key={item.id}>
                <Col col={2}>
                  <FormGroup>

                  <Input
                      id={`bulkPrice.${index}.product_qty`}
                      type="number"
                 //     label={Trans("QTY", language)}
                      placeholder={Trans("QTY", language)}
                      className="form-control"
                      {...register(`bulkPrice.${index}.product_qty`, 
                       
                      )}
                   
                    
                    />    
                
                    
                  </FormGroup>
                </Col>

                <Col col={2}>
                  <FormGroup>

                  <Input
                      id={`bulkPrice.${index}.stock_price`}
                      type="number"
                 //     label={Trans("INVENTORY_PRICE", language)}
                      placeholder={Trans("INVENTORY_PRICE", language)}
                      className="form-control"
                      {...register(`bulkPrice.${index}.stock_price`,)}
                    
                      onKeyUp={(e) => {
                        item_cost_calc(index, "qty", e.target.value);
                      }}
                    
                    />      
                   
                  
                  </FormGroup>
                </Col>

                <Col col={2}>
                  <FormGroup>  
                     <Input
                      id={`bulkPrice.${index}.profit_percent`}
                      type="number"
                   //   label={Trans("PROFIT_PERCENT", language)}
                      placeholder={Trans("PROFIT_PERCENT", language)}
                      className="form-control"
                      {...register(`bulkPrice.${index}.profit_percent`, 
                       
                      )}
                      defaultValue={0}
                      onKeyUp={(e) => {
                        item_cost_calc(index, "qty", e.target.value);
                      }}
                    
                    />              
                  </FormGroup>
                </Col>
                <Col col={2}>

                  
                  <FormGroup>

                  <Input
                     id={`bulkPrice.${index}.max_sale_price`}
                      type="number"
                   //   label={Trans("MAX_SALE_PRICE", language)}
                      placeholder={Trans("MAX_SALE_PRICE", language)}
                      className="form-control"
                       {...register(`bulkPrice.${index}.max_sale_price`, 
                       
                      )}
                    
                    />

                 
                    
                  </FormGroup>
                </Col>
                
                <Col col={2}>
                  <FormGroup>
                     
                  <Input
                      id={Trans("DISCOUNT_PERCENT", language)}
                      type="number"
                //      label={Trans("DISCOUNT_PERCENT", language)}
                      placeholder={Trans("DISCOUNT_PERCENT", language)}
                      className="form-control"
                      {...register(`bulkPrice.${index}.discount_percent`, 
                       
                      )}
                      onKeyUp={(e) => {
                        item_cost_calc(index, "qty", e.target.value);
                      }}
                    />
                    
                  </FormGroup>
                </Col>

           
                           
                           

                <Col col={2}>
             
                   <Input
                        id={Trans("FINAL_SALE_PRICE", language)}
                        type="number"
                    //    label={Trans("FINAL_SALE_PRICE", language)}
                        placeholder={Trans("FINAL_SALE_PRICE", language)}
                        className="form-control"
                        
                        {...register(`bulkPrice.${index}.sale_price`, 
                         
                        )}
                      />

                 
                </Col>


                <Col col={1}>
                  <span style={{ lineHeight: "42px" }}>
                    <FeatherIcon
                      icon="x-square"
                      color="red"
                      onClick={() => bulkPrice.remove(index)}
                      size={20}
                    />
                  </span>
                </Col>
              </Row>
              );
            })}
          </Card.Body>
        )}
      </Card>
    </Col>
  );
}

export default BulkPrice;
