import React, { useState } from "react";
import POST from "axios/post";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
// import EditOptionValue from "./EditOptionValue";
import CheckPermission from "helper";
import SalesDashboardModel from "./SubModuleEdit";
import { useSelector, useDispatch } from "react-redux";
import { updateModuleListState } from "redux/slice/loginSlice";
import { PreUpdate, PageProductOption } from "config/PermissionName";

import { Trans } from "lang/index";
import { Modal, Button } from "react-bootstrap";
import {
  paymentTypeChangeStatusUrl,
  moduleUpdateSortOrderUrl,
  fieldsgroupChangeStatusUrl,
} from "config/index";
import Headingcomponent from "./Headingcomponent";
import "./style.css";
import Editoption from "./EditOption";
function TreeComponent({ dataList, filterItem }) {
  const dispatch = useDispatch();
  const { apiToken, language } = useSelector((state) => state.login);
  const AccessColor = ["#ff8d00", "#001737", "#7a00ff"];

  const [editId, SetEditId] = useState();
  const [addModuleShow, setAddModuleShow] = useState(false);
  const [addSubModuleShow, setSubAddModuleShow] = useState(false);
  const [addFieldGroupModuleShow, setFieldGroupModuleShow] = useState(false);

  const [editoption, seteditoption] = useState("");

  const ModuleEditData = (edit_id, type) => {
    SetEditId(edit_id);
    if (type === "module") seteditoption(true);
    // else if (type === "fieldGroup") setAddModuleShow(true);
    // else setSubAddModuleShow(true);
  };

  const RefreshList = () => {
    filterItem("refresh", "", "");
  };

  const StatusChnageFun = (edit_id, type) => {
    const editData = { api_token: apiToken };
    let ajaxurl = "";

    switch (type) {
      case "module":
        editData.products_options_id = edit_id;
        ajaxurl = paymentTypeChangeStatusUrl;
        break;
      case "fieldGroup":
        editData.products_options_values_id = edit_id;
        ajaxurl = fieldsgroupChangeStatusUrl;
        break;
    }

    POST(ajaxurl, editData)
      .then((response) => {
        const { message, data } = response.data;
        RefreshList();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const SortOrderUpdate = (e, edit_id, type) => {
    const editData = {
      api_token: apiToken,
      update_id: edit_id,
      sort_order: e.target.value,
      type: type,
    };
    POST(moduleUpdateSortOrderUrl, editData)
      .then((response) => {
        const { message, data } = response.data;

        // update side module and section
        dispatch(updateModuleListState(data));
        // RefreshList();
        // Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };
  let ans = new Array();
  {
    dataList.map((e) => {
      let id = e.products_options_id;
      let temp = new Array();
      e?.products_options_values.map((val) => {
        if (val.products_options_id == id) {
          temp.push(val.products_options_values_name);
        }
      });
      ans.push(temp);
    });
  }
  let newa = new Array();
  function arr() {
    let m = 0;
    let n = 0;
    for (let i = 0; i < ans.length; i++) {
      for (let j = 0; j < ans.length; j++) {
      }
    }
  }
  let newans = new Array();

  const [compData, SetcompData] = useState();
  const compFun = (editId) => {
    setFieldGroupModuleShow(true);
    SetcompData(editId);
  };

  const [producttypename, setproducttypename] = useState();
  return (
    <>
      <div className="col-lg-12 mx-auto">
              <div className="table-responsive">
                <table
                  className="module_details mb-4   products_details"
                  cellSpacing="0"
                  rules="all"
                  border="1px"
                  id=""
                  style={{ borderCollapse: "collapse" }}
                >
                  <thead>
                    {dataList &&
                      dataList.map((productType, index) => {
                        const {
                          No_of_categories,
                          No_of_products,
                          No_of_reviews,
                          total_customer_list,
                          total_enquiry_list,
                          total_order_list,
                          total_quatations,
                          total_users,
                        } = productType;
                        return (
                          <tr>
                            <th
                              className="text-center"
                              style={{ width: "3%", position: "relative" }}
                            >
                                <span>

                                {productType.products_options_name}{" "}
                                </span>
                             
                                <CheckPermission
                                PageAccess={PageProductOption}
                                PageAction={PreUpdate}
                                 >
                            
                                <button
                                  type="button"
                                  class="btn btn-primary btn-xs btn-icon"
                                  onClick={() => {
                                    ModuleEditData(
                                      productType.products_options_id,
                                      "module"
                                    );
                                  }}
                                  style={{
                                    position: "absolute",
                                    right: "0",
                                    top: "0",
                                  }}
                                >
                                  <svg
                                    width="20"
                                    height="20"
                                    viewBox="0 0 24 24"
                                    fill="white"
                                    stroke="currentColor"
                                    stroke-width="2"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    class="feather feather-edit-2 "
                                  >
                                    <g>
                                      <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                                    </g>
                                  </svg>
                                </button>
                            
                               </CheckPermission>


                            </th>
                            <td style={{ padding: "10px" }}>
                              <ul>
                                {productType?.products_options_values.map(
                                  (e) => {
                                    return e.status != 0 ? (
                                      <li>{e.products_options_values_name} </li>
                                    ) : (
                                      ""
                                    );
                                  }
                                )}
                                <li>
                                <CheckPermission
                                PageAccess={PageProductOption}
                                PageAction={PreUpdate}
                                 >
                            
                                  <button
                                    type="button"
                                    class="btn btn-primary btn-xs btn-icon ml-1"
                                   
                                    onClick={() => {
                                      compFun(JSON.stringify(productType));
                                      setproducttypename(productType);
                                      SetEditId(
                                        productType.products_options_id
                                      );
                                    }}
                                  >
                                    <svg
                                      width="20"
                                      height="20"
                                      viewBox="0 0 24 24"
                                      fill="white"
                                      stroke="currentColor"
                                      stroke-width="2"
                                      stroke-linecap="round"
                                      stroke-linejoin="round"
                                      class="feather feather-edit-2 "
                                    >
                                      <g>
                                        <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                                      </g>
                                    </svg>
                                  </button>
                                  </CheckPermission>
                                </li>
                              </ul>
                            </td>
                          </tr>
                        );
                      })}
                  </thead>
                </table>
              </div>
       
      </div>

      {/* Module Edit modal */}
      <Modal
        show={editoption}
        onHide={() => {
          seteditoption(false);
        }}
      >
        <Modal.Header>
          <Modal.Title>
            {Trans("EDIT_PRODUCT_OPTION_VALUE", language)}
          </Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              seteditoption(false);
            }}
          >
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Editoption
            editId={editId}
            RefreshList={RefreshList}
            // optionList={dataList}
            handleModalClose={() => {
              seteditoption(false);
            }}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* Sub fileld Type Edit modal */}
      <Modal
        show={addFieldGroupModuleShow}
        onHide={() => {
          setFieldGroupModuleShow(false);
        }}
      >
        <Modal.Header>
          <Modal.Title>
            <Headingcomponent dashboardcontent={compData} />
          </Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              setFieldGroupModuleShow(false);
              filterItem("refresh", "", "");
            }}
          >
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <SalesDashboardModel
            editId={editId}
            dashboardcontent={compData}
            filterItem={filterItem}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
    </>
  );
}

export default TreeComponent;
