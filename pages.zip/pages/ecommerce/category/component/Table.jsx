import React from "react";
import CheckPermission from "helper";
import FeatherIcon from "feather-icons-react";
import {
  BadgeShow,
  Col,
  IconButton,
  Anchor,
} from "component/UIElement/UIElement";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import ModalAlert from "component/ModalAlert";
import { useState } from "react";
import { PreUpdate } from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import { useEffect } from "react";


function Table({
  showColumn,
  dataList,
  deleteFun,
  pageName,
  sortBy,
  orderBy,
  filterItem,
  editFun,
  updateStatusFunction,
  updateIsfeatureFunction,
  UpdateSortOrder,
  mainKey,
  perPage,
  curPage
}) {
  const { apiToken, language } = useSelector((state) => state.login);
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: deleteFun,
      param: deleteId,
      closeModal: closeModal,
    });
  };
  // change Status function
  const ChangeStatus = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: updateStatusFunction,
      param: deleteId,
      closeModal: closeModal,
    });
  };



  const editFunction = (editId) => {
    editFun(editId);
  };
  // filter order by id,email etc...
  const searchItem = (value, ord) => {
    filterItem("sortby", value, ord);
  };

  useEffect(() => {
  }, []);

  const statusColor = ["danger",  "success", ];

  const StatusChange = (quoteId, statusId) => {
    updateIsfeatureFunction(quoteId, statusId);
  };

  let rowId = (curPage>1)? (curPage-1)* perPage : 0;

  return (
    <React.Fragment>
      <Col col={12}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>{Trans("SL_NO", language)}</th>
                <th>{Trans("CATEGORY_IMAGE", language)}</th>
                <th>{Trans("CATEGORY_NAME", language)}</th>
                <th>{Trans("SORT_ORDER")}</th>
                <th>{Trans("STATUS", language)}</th>
                <th>{Trans("IS_FEATURED", language)}</th>
                <CheckPermission PageAccess={pageName} PageAction={PreUpdate}>
                  <th>{Trans("ACTION", language)}</th>
                </CheckPermission>
              </tr>
            </thead>
            <tbody>
              {dataList.length > 0 &&
                dataList.map((cat, idx) => {
                  const {
                    categories_id,
                    categories_image,
                    category_name,
                    categorydescription,
                    sort_order,
                    status,
                    is_featured,
                  } = cat;

                  rowId++;
                  return (
                    <React.Fragment key={idx}>
                      <tr>
                        <td>{rowId}</td>
                        <td>
                          <img
                            src={categories_image}
                          
                            height="30"
                          />
                        </td>
                        <td>
                         {category_name}
                        </td>
                        <td>
                        <input
                            type="number"
                            name=""
                            id=""
                            defaultValue={sort_order}
                          

                            style={{ width: "50px" , 'text-align':"center"}}                
                            onBlur={(e) => {
                              UpdateSortOrder(
                                categories_id,
                              e.target.value
                            );
                         }}
                         />
                      
                        </td>
                     

                        <td>     
                          <div
                          className="custom-control custom-switch "
                           >
                        <input
                                onClick={() => {
                                  updateStatusFunction(
                                    categories_id
                                  );
                                }}
                                type="checkbox"
                                class="custom-control-input"
                              //  id="customSwitch1"
                                id={`customSwitch${categories_id}`}
                                checked={
                                  status === 0
                                    ? ""
                                    : "checked"
                                }
                         />
                            <label
                              className="custom-control-label"
                              For={`customSwitch${categories_id}`}
                            ></label>
                          </div>
                        </td>

                        <td>

                        <select
                           className={`badge badge-${statusColor[is_featured]}`}
                           value={is_featured}
                           
                            onChange={(e) => {
                              StatusChange(categories_id, e.target.value);
                            }}
                          >
                            <option value={0}>
                              {Trans("No", language)}
                            </option>
                            <option value={1}>
                              {Trans("Yes", language)}
                            </option>
                          
                          </select>
                        
                        </td>
                        <td>
                        <a
                          variant="primary"
                         href={WebsiteLink(`/products/${categories_id}`)}
                        target="_blank"
                        >
                       <FeatherIcon
                        icon="external-link"
                        size="18"
                       />
                        </a>{" "}
                          <CheckPermission
                            PageAccess={pageName}
                            PageAction={PreUpdate}
                          >
                            <Anchor
                              path={WebsiteLink(`/categories/${categories_id}`)}
                              className="btn btn-primary btn-xs btn-icon"
                              
                            >
                              <FeatherIcon icon="eye" />
                            </Anchor>
                            {"  "}
                            <IconButton
                              color="primary"
                              onClick={() => editFunction(categories_id)}
                            >
                              <FeatherIcon
                                icon="edit-2"
                                                               
                                fill="white"
                                onClick={() => editFunction(categories_id)}
                              />
                            </IconButton>{" "}
                           
                           
                          </CheckPermission>
                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })}
              {dataList.length == 0 && (
                <React.Fragment>
                  <tr>
                    <td  className="text-center">
                      {Trans("NO_ROCORDS", language)}
                    </td>
                  </tr>
                </React.Fragment>
              )}
            </tbody>
          </table>
        </div>
      </Col>
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </React.Fragment>
  );
}

export default Table;
