import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { FeaturedGroupUpdateUrl, FeaturedGroupEditUrl ,TemlateSettingLangUrl} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  StatusSelect,
  Input,
  Label,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message";

const EditGroup = (props) => {
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = useForm();
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const { editData } = props;

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    POST(FeaturedGroupUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(false, Trans(errObj.msg, language));

        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, Trans(error.message, language));


      });
  };
  const [editInfo, SeteditInfo] = useState("");

  useEffect(() => {
    let abortController = new AbortController();
    function setValueToField() {
      const formdata = {
        api_token: apiToken,
        featured_group_id: editData,
      };

      POST(FeaturedGroupEditUrl, formdata)
        .then((response) => {
          SetloadingStatus(false);
          const { data } = response.data;
          SeteditInfo(data);

          const fieldList = getValues();
          for (const key in fieldList) {
            setValue(key, data[key]);
          }

          const { group_contents } = data;
          if (group_contents.length > 0) {
            for (let index = 0; index < group_contents.length; index++) {

              for (const key in group_contents[index]) {

                const KeyValue = group_contents[index][key];
              }

              setValue(
                "group_name_" + group_contents[index]["languages_id"],
                group_contents[index].group_name
              );


              setValue(
                "group_title_" + group_contents[index]["languages_id"],
                group_contents[index].group_title
              );


            }
          }
        })
        .catch((error) => {
          SetloadingStatus(false);
          alert(error.message);
        });
    }
    setValueToField();
    return () => abortController.abort();
  }, []);



  const [langList, SetlangList] = useState([]);

  const ModuleLoad = () => {
    const filterData = {
      api_token: apiToken,
    };

    POST(TemlateSettingLangUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {

          SetlangList(data);

        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });

  };
  useEffect(() => {
    let abortController = new AbortController();
    ModuleLoad();
    return () => abortController.abort();
  }, []);







  return (
    <React.Fragment>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <React.Fragment>
          {/* {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible
            >
              {error.msg}
            </Alert>
          )} */}
          <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
            <input type="hidden" {...register("featured_group_id")} />
            <Row>

            {langList &&
            langList.map((lang) => {
              const {
                languages_code,
                languages_id,
                languages_name,
              } = lang;
              return (
                <>
                  <Col col={6}>
                    <FormGroup mb="20px">
                    <Input
                        id={Trans("GROUP_NAME", language)}
                        label={`${Trans(
                          "GROUP_NAME",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "GROUP_NAME",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(
                          `group_name_${languages_id}`,
                         )}

                      />
                    
                    

                    </FormGroup>
                  </Col>
                  <Col col={6}>
                    <FormGroup mb="20px">
                    <Input
                        id={Trans("GROUP_TITLE", language)}
                        label={`${Trans(
                          "GROUP_TITLE",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "GROUP_TITLE",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(
                          `group_title_${languages_id}`,
                        
                          )}

                      />
                    
          
                    </FormGroup>
                  </Col>
                </>
              );
            })}

              <Col col={12}>
                <FormGroup mb="20px">
                  <Input
                    id={Trans("SORT_ORDER", language)}
                    type="number"
                    label={Trans("SORT_ORDER", language)}
                    placeholder={Trans("SORT_ORDER", language)}
                    className="form-control"
                    {...register("sort_order", {
                      required: Trans("SORT_ORDER_REQUIRED", language),
                    })}
                  />
                  <span className="required">
                    <ErrorMessage errors={errors} name="sort_order" />
                  </span>
                </FormGroup>
              </Col>

              <Col col={4}>
                <LoaderButton
                  formLoadStatus={formloadingStatus}
                  btnName={Trans("UPDATE", language)}
                  className="btn  btn-sm btn-bg  btn-block"
                />
              </Col>
            </Row>
          </form>
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default EditGroup;
