import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { FeaturedGroupStoreUrl, TemlateSettingLangUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  StatusSelect,
  Col,
  Input,
  Label,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";

const AddGroup = (props) => {
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    POST(FeaturedGroupStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.handleModalClose();
          Notify(true, Trans(message, language));
          props.filterItem("refresh", "", "");
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          Notify(false, Trans(message, language));

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(false, Trans(errObj.msg, language));

        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, Trans(error.message, language));

      });
  };



  const [langList, SetlangList] = useState([]);

  const ModuleLoad = () => {
    const filterData = {
      api_token: apiToken,
    };

    POST(TemlateSettingLangUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {

          SetlangList(data);

        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });

  };
  useEffect(() => {
    let abortController = new AbortController();
    ModuleLoad();
    return () => abortController.abort();
  }, []);




  return (
    <>
      {/* {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )} */}
      <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        <Row>
       

          {langList &&
            langList.map((lang) => {
              const {
                languages_code,
                languages_id,
                languages_name,
              } = lang;
              return (
                <>
                  <Col col={6}>
                    <FormGroup mb="20px">
                    <Input
                        id={Trans("GROUP_NAME", language)}
                        label={`${Trans(
                          "GROUP_NAME",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "GROUP_NAME",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(
                          `group_name_${languages_id}`,
                        
                          
                          )}

                      />
                    
                   

                    </FormGroup>
                  </Col>
                  <Col col={6}>
                    <FormGroup mb="20px">
                    <Input
                        id={Trans("GROUP_TITLE", language)}
                        label={`${Trans(
                          "GROUP_TITLE",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "GROUP_TITLE",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(
                          `group_title_${languages_id}`,
                          )}

                      />
                    
    
                    </FormGroup>
                  </Col>
                </>
              );
            })}

        

          <Col col={4}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("SUBMIT", language)}
              className="btn  btn-sm btn-bg  btn-block"
            />
          </Col>
        </Row>
      </form>
    </>
  );
};

export default AddGroup;
