import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import {
  ServicePlanFeatureStoreUrl,
  ServicePlanFeatureCreateUrl,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import { ErrorMessage } from "@hookform/error-message";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  StatusSelect,
  IsFeatured,
  Label,
} from "component/UIElement/UIElement";
import Select from "react-select";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";

const Create = (props) => {
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [moduleList, SetmoduleList] = useState([]);
  const [sectionListing, SetSectionListing] = useState([]);

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    // saveFormData.industry_id = MultiSelectItem;

    POST(ServicePlanFeatureStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [groupList, SetgrpList] = useState([]);

  const ModuleLoad = () => {
    const filterData = {
      api_token: apiToken,
    };

    POST(ServicePlanFeatureCreateUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetSectionListing(data.parent_feature);
          SetgrpList(data.grp_data);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    ModuleLoad();
    return () => abortController.abort();
  }, []);

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible>
          {error.msg}
        </Alert>
      )}
      <form
        action="#"
        onSubmit={handleSubmit(onSubmit)}
        noValidate>
        <Row>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                type="hidden"
                id={Trans("PLAN_GROUP", language)}
                label={Trans("PLAN_GROUP", language)}
                placeholder={Trans("PLAN_GROUP", language)}
                className="form-control"
                {...register("group_id", {})}
              />

              <Select
                isMulti
                name={Trans("PLAN_GROUP", language)}
                options={groupList}
                // defaultValue={quick}
                className="basic-multi-select"
                classNamePrefix="select"
                onChange={(newValue, actionMeta) => {
                  let listArr = [];
                  for (let index = 0; index < newValue.length; index++)
                    listArr[index] = newValue[index].value;

                  listArr = listArr.join(",");
                  //console.log("listArr", listArr);
                  setValue("group_id", listArr);
                }}
              />
            </FormGroup>
          </Col>

          <Col col={6}>
            <FormGroup mb="20px">
              <Label
                display="block"
                mb="5px"
                htmlFor={Trans("PARENT_NAME", language)}>
                {Trans("PARENT_NAME", language)}
              </Label>
              <select
                id="PARENT_NAME"
                label={Trans("PARENT_NAME", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register("parent_id", {})}>
                <option value={0}>---</option>

                {sectionListing &&
                  sectionListing?.map((curr, idx) => (
                    <option
                      value={curr.feature_id}
                      key={idx}>
                      {curr.feature_title}
                    </option>
                  ))}
              </select>
            </FormGroup>
          </Col>

          {/* <Col col={12}>
            <FormGroup mb="20px">
              <Label
                display="block"
                mb="5px"
                htmlFor={Trans("PLAN_GROUP", language)}
              >
                {Trans("PLAN_GROUP", language)}
              </Label>
              <select
                id={Trans("PLAN_GROUP", language)}
                placeholder={Trans("PLAN_GROUP", language)}
                className="form-control"
                {...register("group_id", 
                  
                )}
               
               
              >
                <option value="">{Trans("SELECT_PLAN_GROUP", language)}</option>
                {groupList?.grp_data &&
                    groupList?.grp_data.map((curr, idx) => (
                      
                     
                      <option value={curr.group_id} key={idx}>
                        {curr.group_name}
                      </option>

               ))}

              </select>
            
            </FormGroup>
          </Col> */}

          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("FEATURE_TITLE", language)}
                label={Trans("FEATURE_TITLE", language)}
                placeholder={Trans("FEATURE_TITLE", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register("feature_title", {
                  required: Trans("FEATURE_TITLE_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage
                  errors={errors}
                  name="feature_title"
                />
              </span>
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("FEATURE_DETAIL", language)}
                label={Trans("FEATURE_DETAIL", language)}
                placeholder={Trans("FEATURE_DETAIL", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register("feature_details", {})}
              />
            </FormGroup>
          </Col>

          <Col col={4}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("SUBMIT", language)}
              className="btn btn-sm btn-bg btn-block"
            />
          </Col>
        </Row>
      </form>
    </>
  );
};

export default Create;
