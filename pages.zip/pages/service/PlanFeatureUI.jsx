import React, { useState } from "react";
import {
  LoaderButton,
  FormGroup,
  Label,
  Col,
} from "component/UIElement/UIElement";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import { useForm, FormProvider } from "react-hook-form";
import POST from "axios/post";
import {
  ServiceplanToFeatureStoreUrl,
  ServiceplanToFeatureUrl,
  ServicePlanFeatureSortOrderUrl,
  ServicePlanFeatureStatusUrl,
  ServicePlanFeatureMenuUrl,
} from "config";
import Alert from "component/UIElement/Alert";
import Notify from "component/Notify";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useEffect } from "react";
import Loading from "component/Loading";
import CheckPermission from "helper";
import { useParams } from "react-router-dom";

import {
  PageServicePlanToFeature,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";
import { Modal, Button } from "react-bootstrap";
import Create from "./FeatureCreate";
import Edit from "./FeatureEdit";
import WebsiteLink from "config/WebsiteLink";
import { Anchor } from "component/UIElement/UIElement";
import FeatherIcon from "feather-icons-react";

function PlanFeatureUI(props) {
  const { language, apiToken, userType } = useSelector((state) => state.login);
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const { grpId } = useParams();
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");

  const methods = useForm();

  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = methods;

  const [msgType, setMsgType] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    formData.api_token = apiToken;
    POST(ServiceplanToFeatureStoreUrl, formData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });

          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              console.log(message[key][0]);
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = Trans(message, language);
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [selectType, SetSelectType] = useState(1);
  const [grpName, SetGroupName] = useState("");

  const [permissionList, setPermissionList] = useState([]);
  const [sectionList, SetSectionList] = useState([]);
  const [moduleList, SetModuleList] = useState([]);
  const [contentloadingStatus, SetloadingStatus] = useState(false);
  const [statuslist, SetStatuslist] = useState("");

  const [planList, SetplanList] = useState([]);

  const findListBanner = (id, sortBys, orderByS) => {
    const filterData = {
      api_token: apiToken,
      language: language,
      group_id: id,
      sortBy: sortBys,
      orderBY: orderByS,
      userType: userType,
      language: language,
    };
    POST(ServiceplanToFeatureUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;

        if (status) {
          SetloadingStatus(false);
          SetplanList(data.plan_data);
          SetSectionList(data.feature_list);
          SetModuleList(data.feature_list);
          SetGroupName(data.group_name);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();

    findListBanner(grpId, sortByS, orderByS);
    return () => abortController.abort();
  }, []);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  //   const editPlan = (feature_id) => {
  //     setEditModalShow(true);
  //     SetEditData(feature_id);
  //   };
  const editFun = (editId) => {
    setEditModalShow(true);
    SetEditData(editId);
  };

  const [editPermission, SetEditPermission] = useState();

  const editFunction = (editId) => {
    editFun(editId);
  };

  var set2 = new Set();
  {
    sectionList &&
      sectionList.map((template, idx) => {
        set2.add(template.featureGroup);
      });
  }
  let arrayhead = [...set2];

  let ar1;
  let bigar = new Set();
  {
    for (let i = 0; i < arrayhead.length; i++) {
      ar1 = [];

      for (let j = 0; j < sectionList.length; j++) {
        if (sectionList[j].featureGroup == arrayhead[i]) {
          ar1.push(sectionList[j]);
        }
      }
      bigar.add(ar1);
    }
    console.log(bigar);
  }
  let arraylist = [...bigar];

  const filterItem = () => {
    findListBanner(grpId);
  };

  const ChangeFunction = (quoteId) => {
    const editData = {
      api_token: apiToken,
      feature_id: quoteId,
      //  status: statusId,
    };
    POST(ServicePlanFeatureStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;
        findListBanner(grpId);

        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };

  const statusColor = ["danger", "success"];

  const StatusChange = (quoteId) => {
    ChangeFunction(quoteId);
  };

  const UpdateSortOrder = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      feature_id: update_id,
      sort_order: sortOrder,
    };
    POST(ServicePlanFeatureSortOrderUrl, editData)
      .then((response) => {
        const { message } = response.data;
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };

  const ChangeMenuCollapseFunction = (quoteId) => {
    const editData = {
      api_token: apiToken,
      feature_id: quoteId,
      //  status: statusId,
    };
    POST(ServicePlanFeatureMenuUrl, editData)
      .then((response) => {
        const { message } = response.data;
        findListBanner(grpId);

        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };

  return (
    <Content>
      <CheckPermission
        PageAccess={PageServicePlanToFeature}
        PageAction={PreView}>
        <React.Fragment>
          {msgType.length > 2 &&
            (msgType === "success" ? (
              <Alert type="success">{errorMsg}</Alert>
            ) : (
              <Alert type="danger">{errorMsg}</Alert>
            ))}
          <FormProvider {...methods}>
            <form
              action="#"
              onSubmit={handleSubmit(onSubmit)}
              noValidate>
              {/* 
                            <FormGroup mb="20px">
                              <Label
                                display="block"
                                mb="5px"
                                htmlFor={Trans("INDUSTRY", language)}
                              >
                                {Trans("INDUSTRY", language)}
                              </Label>
                              <select
                                {...register("industry_id", {
                                 
                                })}
                                classNameName="form-control"
                                 onChange={(e) => getPlanListBYIndustryId(e.target.value)}

                                // onChange={(event) => {
                                //   SetSelectType(event.target.value);
                                // }}
                              
                              >
                               <option value="" >
                               {Trans("PLEASE_SELECT", language)}
                                      </option>

                                {industryList &&
                                  industryList.map((industry, idx) => {
                                    return (
                                      <option value={industry.industry_id} key={idx}>
                                        {industry.industry_name}
                                      </option>
                                    );
                                  })}
                              </select>
                            </FormGroup> */}

              <FormGroup mb="20px">
                <Label
                  display="block"
                  mb="5px"
                  htmlFor="permissionList">
                  <b>{grpName} </b>
                </Label>
                <div className="d-none d-md-flex justify-content-end mb-1">
                  <CheckPermission
                    PageAccess={PageServicePlanToFeature}
                    PageAction={PreAdd}>
                    <Button
                      variant=""
                      className="btn-sm btn-bg"
                      onClick={handleModalShow}>
                      <FeatherIcon
                        icon="plus"
                        fill="white"
                        //   classNameName="wd-10 mg-r-5"
                      />
                      {Trans("ADD_PLAN_FEATURE", language)}
                    </Button>
                  </CheckPermission>
                  <Anchor
                    className="btn btn-sm btn-bg btn-xs btn-icon py-2"
                    path={WebsiteLink(`/service-plan-group/${grpId}`)}>
                    <FeatherIcon
                      icon=""
                      className="wd-10 mg-r-5"
                    />
                    {Trans("GO_BACK", language)}
                  </Anchor>
                </div>
                <React.Fragment>
                  <React.Fragment>
                    <div className="table-responsive shadow rounded ">
                      <table className="table table-center bg-white mb-0 border">
                        <thead>
                          <tr>
                            <th
                              className=""
                              style={{ minWidth: "200px" }}>
                              <b>{Trans("PLAN_FEATURE_LIST", language)}</b>
                            </th>

                            <td>
                              <table className="border-0">
                                <tbody>
                                  <tr className="border-0">
                                    {planList &&
                                      planList.map((plan, chid) => {
                                        return (
                                          <React.Fragment key={chid}>
                                            <th
                                              className=" text-center border-0"
                                              style={{ minWidth: "150px" }}>
                                              {" "}
                                              <b>{plan?.plan_name}</b>
                                            </th>
                                          </React.Fragment>
                                        );
                                      })}
                                  </tr>
                                </tbody>
                              </table>
                            </td>

                            <th
                              className="text-center border-bottom"
                              style={{ minWidth: "150px" }}>
                              {Trans("STATUS", language)}
                            </th>
                            <th
                              className="text-center border-bottom"
                              style={{ minWidth: "150px" }}>
                              {Trans("MENU_COLLAPSE", language)}
                            </th>
                            <th
                              className="text-center border-bottom"
                              style={{ minWidth: "150px" }}>
                              {Trans("SORT_ORDER", language)}
                            </th>
                            <th
                              className="text-center border-bottom"
                              style={{ minWidth: "100px" }}>
                              {Trans("ACTION", language)}
                            </th>
                          </tr>
                        </thead>
                      </table>
                      {arrayhead &&
                        arrayhead.map((head, index) => {
                          return (
                            <fieldset className="form-fieldset m-3">
                              <legend> {Trans(head, language)}</legend>
                              {arraylist &&
                                arraylist.map((e, idx) => {
                                  return e.map((Feature) => {
                                    const {
                                      feature_id,
                                      menu_collapse,
                                      feature_title,
                                      feature_details,
                                      featureGroup,
                                      featureStatus,
                                      status,
                                      sort_order,
                                    } = Feature;
                                    console.log(Feature);

                                    return featureGroup == head ? (
                                      <>
                                        <table className="table table-center bg-white ">
                                          <tbody>
                                            <tr>
                                              <th
                                                className=""
                                                style={{
                                                  minWidth: "200px",
                                                }}></th>
                                              <th
                                                className="text-center"
                                                style={{
                                                  minWidth: "150px",
                                                }}></th>
                                              <th
                                                className="text-center"
                                                style={{
                                                  minWidth: "150px",
                                                }}></th>
                                              <th
                                                className="text-center"
                                                style={{
                                                  minWidth: "150px",
                                                }}></th>
                                              <th
                                                className="text-center"
                                                style={{
                                                  minWidth: "200px",
                                                }}></th>
                                              <th
                                                className="text-center "
                                                style={{
                                                  minWidth: "150px",
                                                }}></th>
                                              <th
                                                className="text-center "
                                                style={{ minWidth: "100px" }}>
                                                <div className=" custom-switch  d-inline-block pl-4 ">
                                                  <input
                                                    style={{
                                                      height: "30px",
                                                      width: "50px",
                                                    }}
                                                    onClick={() => {
                                                      StatusChange(
                                                        Feature.feature_id
                                                      );
                                                    }}
                                                    type="checkbox"
                                                    class="custom-control-input  custom-control custom-switch"
                                                    id={`customSwitch${Feature.feature_id}`}
                                                    checked={
                                                      status === 0
                                                        ? ""
                                                        : "checked"
                                                    }
                                                  />
                                                  <label
                                                    className="custom-control-label"
                                                    For={`customSwitch${Feature.feature_id}`}></label>
                                                </div>
                                              </th>
                                              <th
                                                className="text-center "
                                                style={{ minWidth: "150px" }}>
                                                <div className=" custom-switch  d-inline-block pl-6 ">
                                                  <input
                                                    style={{
                                                      height: "30px",
                                                      width: "50px",
                                                    }}
                                                    onClick={() => {
                                                      ChangeMenuCollapseFunction(
                                                        Feature.feature_id
                                                      );
                                                    }}
                                                    type="checkbox"
                                                    class="custom-control-input  custom-control custom-switch"
                                                    id={`customSwitch1${Feature.feature_id}`}
                                                    checked={
                                                      menu_collapse === 0
                                                        ? ""
                                                        : "checked"
                                                    }
                                                  />
                                                  <label
                                                    className="custom-control-label"
                                                    For={`customSwitch1${Feature.feature_id}`}></label>
                                                </div>
                                              </th>
                                              <th
                                                className="text-center "
                                                style={{ minWidth: "150px" }}>
                                                <input
                                                  style={{
                                                    height: "35px",
                                                    width: "40px",
                                                    "text-align": "left",
                                                  }}
                                                  type="number"
                                                  name=""
                                                  id=""
                                                  defaultValue={sort_order}
                                                  onBlur={(e) => {
                                                    UpdateSortOrder(
                                                      Feature.feature_id,
                                                      e.target.value
                                                    );
                                                  }}
                                                />
                                              </th>
                                              <th
                                                className="text-center "
                                                style={{ minWidth: "100px" }}>
                                                <Button
                                                  variant="primary"
                                                  onClick={() =>
                                                    editFunction(
                                                      Feature.feature_id
                                                    )
                                                  }
                                                  className="btn btn-primary btn-xs btn-icon ml-2 ">
                                                  <FeatherIcon
                                                    icon="edit-2"
                                                    fill="white"
                                                    size={20}
                                                    onClick={() =>
                                                      editFunction(
                                                        Feature.feature_id
                                                      )
                                                    }
                                                  />
                                                </Button>
                                              </th>
                                            </tr>
                                          </tbody>
                                        </table>

                                        <table className="table table-center bg-white mb-0 border rounded">
                                          <thead>
                                            {/* <tr>
                                    <th className="border-bottom " style="min-width:200px;">Sl. No.</th>
                                    <th className="border-bottom text-center" style="min-width: 150px;"></th>
                                    <th className="text-center border-bottom" style="min-width: 200px;">Company Phone</th>
                                    <th className="text-center border-bottom" style="min-width: 100px;">Priority</th>
                                    <th className="text-center border-bottom" style="min-width: 100px;">Follow Up</th>
                                    <th className="text-center border-bottom" style="min-width: 150px;">Follow Date</th>
                                    <th className="text-center border-bottom" style="min-width: 100px;"> Follow Up Status
                                    </th>
                                    <th className="text-center border-bottom" style="min-width: 100px;"> Action</th>

                                </tr>  */}
                                          </thead>
                                          <tbody>
                                            {Feature?.sub_feature &&
                                              Feature?.sub_feature.map(
                                                (parentdata, index) => {
                                                  const {
                                                    feature_id,
                                                    feature_title,
                                                    feature_details,
                                                    featureGroup,
                                                    featureStatus,
                                                    status,
                                                    sort_order,
                                                    menu_collapse,
                                                  } = parentdata;
                                                  console.log(parentdata);
                                                  return (
                                                    <>
                                                      <tr>
                                                        <td
                                                          className="text-center"
                                                          style={{
                                                            minWidth: "200px",
                                                          }}>
                                                          {" "}
                                                          <h6>
                                                            {
                                                              parentdata.feature_title
                                                            }
                                                          </h6>
                                                        </td>
                                                        {planList &&
                                                          planList.map(
                                                            (ch, chid) => {
                                                              const {
                                                                features,
                                                                limits,
                                                                status,
                                                              } = ch;
                                                              return (
                                                                <>
                                                                  <td>
                                                                    <table className="border-0">
                                                                      <tbody>
                                                                        <tr className="border-0">
                                                                          <div className="d-flex">
                                                                            <select
                                                                              {...register(
                                                                                `status_${ch.plan_id}_${parentdata.feature_id}`
                                                                              )}
                                                                              className=""
                                                                              defaultValue={
                                                                                features[
                                                                                  parentdata
                                                                                    .feature_id
                                                                                ] ===
                                                                                undefined
                                                                                  ? "no"
                                                                                  : features[
                                                                                      parentdata
                                                                                        .feature_id
                                                                                    ]
                                                                              }>
                                                                              <option>
                                                                                {Trans(
                                                                                  "SELECT",
                                                                                  language
                                                                                )}
                                                                              </option>

                                                                              <option
                                                                                className="text-success"
                                                                                value="yes">
                                                                                {" "}
                                                                                {Trans(
                                                                                  "yes",
                                                                                  language
                                                                                )}{" "}
                                                                              </option>
                                                                              <option
                                                                                className="text-danger"
                                                                                value="no">
                                                                                {" "}
                                                                                {Trans(
                                                                                  "no",
                                                                                  language
                                                                                )}{" "}
                                                                              </option>
                                                                            </select>

                                                                            <FormGroup className="mb-0 ml-2">
                                                                              <input
                                                                                id="name"
                                                                                style={{
                                                                                  width:
                                                                                    "50px",
                                                                                  "text-align":
                                                                                    "center",
                                                                                }}
                                                                                type="text"
                                                                                className="form-controls"
                                                                                placeholder="Limit"
                                                                                defaultValue={
                                                                                  limits[
                                                                                    parentdata
                                                                                      .feature_id
                                                                                  ] ===
                                                                                  undefined
                                                                                    ? ""
                                                                                    : limits[
                                                                                        parentdata
                                                                                          .feature_id
                                                                                      ]
                                                                                }
                                                                                {...register(
                                                                                  `feature_limit_${ch.plan_id}_${parentdata.feature_id}`
                                                                                )}
                                                                              />
                                                                            </FormGroup>
                                                                          </div>
                                                                        </tr>
                                                                      </tbody>
                                                                    </table>
                                                                  </td>

                                                                  {/* 
            <td className="" style={{minWidth: "150px"}}>
              <div className="d-flex" >
              
            <select
              {...register(

                `status_${ch.plan_id}_${parentdata.feature_id}`
              )}
              className=""
              defaultValue={
                features[parentdata.feature_id] === undefined
                  ? 'no'
                  : features[parentdata.feature_id]
              }
            >

              <option >
                {Trans("SELECT", language)}
              </option>
              
      <option className="text-success" value="yes"> {Trans("yes", language)} </option>
      <option  className="text-danger"  value="no"> {Trans("no", language)} </option>
          
            </select>

            <FormGroup  className="mb-0 ml-2">
                <input
                  id="name"
                  style={{ width: "50px" , 'text-align':"center"}}                

                  type="text"
                  className="form-controls"
                  placeholder="LIMIT"
                  defaultValue={
                    limits[parentdata.feature_id] === undefined
                      ? ''
                      : limits[parentdata.feature_id]
                  }
                

                  {...register(

                    `feature_limit_${ch.plan_id}_${parentdata.feature_id}`
                  
                  )}
                
                />
              
              </FormGroup>
              </div>
           </td> */}
                                                                </>
                                                              );
                                                            }
                                                          )}

                                                        <td
                                                          style={{
                                                            minWidth: "150px",
                                                          }}>
                                                          <div className=" custom-switch  ">
                                                            <input
                                                              style={{
                                                                height: "30px",
                                                                width: "50px",
                                                                "text-align":
                                                                  "center",
                                                              }}
                                                              onClick={() => {
                                                                StatusChange(
                                                                  parentdata.feature_id
                                                                );
                                                              }}
                                                              type="checkbox"
                                                              class="custom-control-input  custom-control custom-switch"
                                                              id={`customSwitch${parentdata.feature_id}`}
                                                              checked={
                                                                status === 0
                                                                  ? ""
                                                                  : "checked"
                                                              }
                                                            />
                                                            <label
                                                              className="custom-control-label"
                                                              For={`customSwitch${parentdata.feature_id}`}></label>
                                                          </div>
                                                        </td>

                                                        <td
                                                          style={{
                                                            minWidth: "150px",
                                                          }}>
                                                          <div className=" custom-switch  ml-4 ">
                                                            <input
                                                              style={{
                                                                height: "30px",
                                                                width: "50px",
                                                              }}
                                                              onClick={() => {
                                                                ChangeMenuCollapseFunction(
                                                                  parentdata.feature_id
                                                                );
                                                              }}
                                                              type="checkbox"
                                                              class="custom-control-input  custom-control custom-switch"
                                                              id={`customSwitch1${parentdata.feature_id}`}
                                                              checked={
                                                                menu_collapse ===
                                                                0
                                                                  ? ""
                                                                  : "checked"
                                                              }
                                                            />
                                                            <label
                                                              className="custom-control-label"
                                                              For={`customSwitch1${parentdata.feature_id}`}></label>
                                                          </div>
                                                        </td>
                                                        <td
                                                          style={{
                                                            minWidth: "150px",
                                                          }}>
                                                          {" "}
                                                          <input
                                                            style={{
                                                              height: "30px",
                                                              width: "50px",
                                                              "text-align":
                                                                "center",
                                                            }}
                                                            type="number"
                                                            name=""
                                                            id=""
                                                            defaultValue={
                                                              sort_order
                                                            }
                                                            onBlur={(e) => {
                                                              UpdateSortOrder(
                                                                parentdata.feature_id,
                                                                e.target.value
                                                              );
                                                            }}
                                                          />
                                                        </td>
                                                        <td
                                                          style={{
                                                            minWidth: "100px",
                                                          }}>
                                                          <Button
                                                            variant="primary"
                                                            onClick={() =>
                                                              editFunction(
                                                                parentdata.feature_id
                                                              )
                                                            }
                                                            className="btn btn-primary btn-xs btn-icon">
                                                            <FeatherIcon
                                                              icon="edit-2"
                                                              fill="white"
                                                              size={20}
                                                              onClick={() =>
                                                                editFunction(
                                                                  parentdata.feature_id
                                                                )
                                                              }
                                                            />
                                                          </Button>
                                                        </td>
                                                      </tr>
                                                    </>
                                                  );
                                                }
                                              )}
                                          </tbody>
                                        </table>
                                      </>
                                    ) : (
                                      ""
                                    );
                                  });
                                })}
                            </fieldset>
                          );
                        })}
                    </div>
                  </React.Fragment>
                </React.Fragment>
              </FormGroup>

              <Col col={4}>
                <LoaderButton
                  formLoadStatus={formloadingStatus}
                  btnName={Trans("UPDATE", language)}
                  className="btn btn-sm btn-bg btn-block"
                />
              </Col>
            </form>
          </FormProvider>
        </React.Fragment>
      </CheckPermission>

      {/* add modal */}
      <Modal
        show={show}
        onHide={handleModalClose}
        size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("ADD_PLAN_FEATURE", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create
            handleModalClose={handleModalClose}
            filterItem={filterItem}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
      {/* edit modal */}
      <Modal
        show={editModalShow}
        onHide={handleEditModalClose}
        size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_PLAN_FEATURE", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Edit
            editData={editData}
            filterItem={filterItem}
            handleModalClose={handleEditModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
    </Content>
  );
}

export default PlanFeatureUI;
