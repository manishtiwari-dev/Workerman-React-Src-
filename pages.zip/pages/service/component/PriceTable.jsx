import React from "react";
import CheckPermission from "helper";
import FeatherIcon from "feather-icons-react";
import {
  BadgeShow,
  Col,
  IconButton,
  Anchor,
} from "component/UIElement/UIElement";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import ModalAlert from "component/ModalAlert";
import { useState } from "react";
import { PreUpdate, PreRemove, PreView } from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import { SettingGroup } from "config/WebsiteUrl";
import { useForm } from "react-hook-form";

function Table({
  dataList,
  deleteFun,
  pageName,
  filterItem,
  editFun,
  viewFunction,
  updateStatusFunction,
  UpdateSortOrder,
  perPage,
  curPage
}) {
  const { apiToken, language } = useSelector((state) => state.login);
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: deleteFun,
      param: deleteId,
      closeModal: closeModal,
    });
  };
  // change Status function
  const ChangeStatus = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: updateStatusFunction,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const editFunction = (editId) => {
    editFun(editId);
  };

  const viewFun = (editId) => {
    viewFunction(editId);
  };
  
  const UpdateOrderStatus = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      group_id: update_id,
      sort_order: sortOrder,
    };
  };

  let rowId = (curPage>1)? (curPage-1)* perPage : 0;

  return (
    <>
      <Col col={12}>
        <div className="table-responsive">
      
          <table className="table">
            <thead>
              <tr>
                <th>{Trans("SL_NO", language)}</th>
                <th>{Trans("PLAN_DURATION", language)}</th>
                <th>{Trans("PLAN_AMOUNT", language)}</th>
                <th>{Trans("DISCOUNT", language)}</th>
                <th>{Trans("DISCOUNT_TYPE", language)}</th>
                <th>{Trans("SETUP_FEES", language)}</th>
                <th>{Trans("SETUP_FEES_DISCOUNT", language)}</th>

                <th>{Trans("STATUS", language)}</th>
                <th className="text-center">{Trans("ACTION", language)}</th>
              </tr>
            </thead>

            <tbody>
              {dataList.length > 0 &&
                dataList.map((cat, IDX) => {
                  const {
                    id,
                    plan_duration,
                    plan_price,
                    discount_type,
                    status,
                    setup_fee,
                    setup_fee_discount,
                    plan_discount
                  } = cat;
                  rowId++;
                  return (
                    <React.Fragment key={IDX}>
                      <tr>
                        <td>{rowId}</td>

                        <td>{plan_duration}</td>
                        <td>{plan_price}</td>
                        <td>{plan_discount} 
                          
                          </td>
                        <td>{discount_type} 
                          
                          </td>
                          <td>{setup_fee} 
                          
                          </td>
                          <td>{setup_fee_discount} 
                          
                          </td>

                        <td>
                        <div
                          className="custom-control custom-switch "

                           >
                        <input
                                onClick={() => {
                                  updateStatusFunction(
                                    id
                                  );
                                }}
                                type="checkbox"
                                class="custom-control-input"
                                id={`customSwitch${id}`}

                                checked={
                                  status === 0
                                    ? ""
                                    : "checked"
                                }
                         />
                            <label
                              className="custom-control-label"
                              For={`customSwitch${id}`}
                            ></label>
                          </div>
                        </td>
                        <td className="text-center">
                         
                          <CheckPermission
                            PageAccess={pageName}
                            PageAction={PreUpdate}
                          >
                           
                               <button  className="btn btn-primary btn-xs btn-icon">
                              <FeatherIcon
                                icon="edit-2"
                                fill="white"
                                size={20}
                                onClick={() =>editFunction(id)}
                              />
                              </button>
                          
                          </CheckPermission>
                         
                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })}
            </tbody>

          </table>
        
        </div>
      </Col>
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </>
  );
}

export default Table;
