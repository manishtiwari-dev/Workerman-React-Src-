import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import {
  ServiceplanPriceUpdateUrl,
  ServiceplanPriceEditUrl,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  StatusSelect,
  Label,
  IsFeatured,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Select from "react-select";
import Loading from "component/Preloader";
import MyEditor from "component/MyEditor";
import { ErrorMessage } from "@hookform/error-message";

const Edit = (props) => {
  const { editData } = props;

  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
  } = useForm();

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(ServiceplanPriceUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [moduleList, SetmoduleList] = useState([]);
  const [defaultSelectValue, SetDefaultSelectValue] = useState();
  const [planList, SetplanList] = useState([]);
  const [editInfo, SeteditInfo] = useState("");

  const setValueToField = () => {
    const editInfo = {
      api_token: apiToken,
      id: editData,
    };
    POST(ServiceplanPriceEditUrl, editInfo)
      .then((response) => {
        SetloadingStatus(false);
        const { data } = response.data;
        const fieldList = getValues();
        SetplanList(data.plan_list);

        for (const key in fieldList) {
          setValue(key, data.data_list[key]);
        }
        //setting edit info to show select value
      })
      .catch((error) => {
        SetloadingStatus(false);
        alert(error.message);
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    setValueToField();
    return () => abortController.abort();
  }, []);

  const [MultiSelectItem, SetMultiSelectItem] = useState("");
  const handleMultiSelectChange = (newValue, actionMeta) => {
    console.log("newValue", newValue);
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    listArr = listArr.join(",");
    console.log("listArr", listArr);
    SetMultiSelectItem(listArr);
    console.log("actionMeta", actionMeta);
  };

  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible>
              {error.msg}
            </Alert>
          )}
          <form
            action="#"
            onSubmit={handleSubmit(onSubmit)}
            noValidate>
            <input
              type="hidden"
              {...register("id")}
            />
            <input
              type="hidden"
              {...register("plan_id")}
              value={planList?.plan_id}
            />

            <Row>
              {/* <Col col={12}>
                <FormGroup mb="20px">
                  <Label
                    display="block"
                    mb="5px"
                    htmlFor={Trans("PLAN_NAME", language)}
                  >
                    {Trans("PLAN_NAME", language)}
                  </Label>
                  <select
                    {...register("plan_id", {
                      required: Trans("INDUSTRY_REQUIRED", language),
                    })}
                    className="form-control"
                 
                  >
                    <option>{Trans("SELECT_PLAN_NAME")}</option>
                    {planList &&
                      planList.map((plan, idx) => {
                        return (
                          <option value={plan.plan_id} key={idx}>
                            {plan.plan_name}
                          </option>
                        );
                      })}
                  </select>
                </FormGroup>
              </Col> */}
              <Col col={6}>
                <FormGroup mb="20px">
                  <Input
                    id={Trans("DURATION", language)}
                    type="number"
                    label={Trans("DURATION", language)}
                    placeholder={Trans("DURATION", language)}
                    className="form-control"
                    {...register("plan_duration", {
                      required: Trans("DURATION_REQUIRED", language),
                    })}
                  />
                </FormGroup>
              </Col>
              <Col col={6}>
                <FormGroup mb="20px">
                  <Input
                    id={Trans("PLAN_PRICE", language)}
                    type="number"
                    label={Trans("PLAN_PRICE", language)}
                    placeholder={Trans("PLAN_PRICE", language)}
                    className="form-control"
                    {...register("plan_price", {
                      required: Trans("PLAN_PRICE_REQUIRED", language),
                    })}
                  />
                </FormGroup>
              </Col>

              <Col col={6}>
                <FormGroup mb="20px">
                  <Label
                    display="block"
                    mb="5px"
                    htmlFor={Trans("DISCOUNT_TYPE", language)}>
                    {Trans("DISCOUNT_TYPE", language)}
                  </Label>
                  <select
                    {...register("discount_type")}
                    defaultValue={0}
                    className="form-control">
                    <option value="">{Trans("SELECT_DISCOUNT_TYPE")}</option>
                    <option value={0}>{Trans("NO")}</option>
                    <option value={1}>{Trans("FIXED")}</option>
                    <option value={2}>{Trans("PERCENTAGE")}</option>
                  </select>
                </FormGroup>
              </Col>
              <Col col={6}>
                <FormGroup mb="20px">
                  <Input
                    id={Trans("PLAN_DISCOUNT", language)}
                    type="number"
                    label={Trans("PLAN_DISCOUNT", language)}
                    placeholder={Trans("PLAN_DISCOUNT", language)}
                    className="form-control"
                    {...register("plan_discount")}
                  />
                </FormGroup>
              </Col>
              <Col col={6}>
                <FormGroup mb="20px">
                  <Input
                    id={Trans("SET_UP_FEES", language)}
                    type="number"
                    label={Trans("SET_UP_FEES", language)}
                    placeholder={Trans("SET_UP_FEES", language)}
                    className="form-control"
                    {...register("setup_fee", {})}
                  />
                </FormGroup>
              </Col>

              <Col col={6}>
                <FormGroup mb="20px">
                  <Label
                    display="block"
                    mb="5px"
                    htmlFor={Trans("SET_UP_DISCOUNT", language)}>
                    {Trans("SET_UP_DISCOUNT", language)}
                  </Label>
                  <select
                    {...register("setup_fee_discount")}
                    defaultValue={0}
                    className="form-control">
                    <option value="">{Trans("SELECT_SET_UP_DISCOUNT")}</option>
                    <option value={0}>{Trans("NO")}</option>
                    <option value={1}>{Trans("YES")}</option>
                  </select>
                </FormGroup>
              </Col>

              <Col col={4}>
                <LoaderButton
                  formLoadStatus={formloadingStatus}
                  btnName={Trans("UPDATE", language)}
                  className="btn btn-sm btn-bg btn-block"
                />
              </Col>
            </Row>
          </form>
        </>
      )}
    </>
  );
};

export default Edit;
